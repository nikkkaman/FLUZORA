"use client";
import React from "react";
import { motion } from "framer-motion";
import { FaMedal, FaFire, FaUserPlus } from "react-icons/fa";

const badges = [
  { id: 1, label: "Rookie", desc: "First upload", icon: <FaMedal className="text-yellow-400 text-2xl" /> },
  { id: 2, label: "Contributor", desc: "5 uploads", icon: <FaMedal className="text-blue-400 text-2xl" /> },
  { id: 3, label: "Vault Master", desc: "10 uploads", icon: <FaMedal className="text-purple-400 text-2xl" /> },
];
const streaks = [
  { id: 1, days: 5, bonus: 50 },
  { id: 2, days: 10, bonus: 120 },
];
const referrals = [
  { id: 1, users: 3, bonus: 300 },
];

export default function RewardsPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg">Rewards</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">Track your badges, streaks, and referral bonuses. Earn more by contributing and inviting friends!</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full max-w-4xl grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 mb-12"
      >
        {badges.map((b, i) => (
          <motion.div
            key={b.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i, duration: 0.5 }}
            className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col items-center gap-3 border border-yellow-400"
          >
            {b.icon}
            <div className="font-orbitron text-xl text-neon mb-1">{b.label}</div>
            <div className="font-inter text-white/80 text-center text-sm">{b.desc}</div>
          </motion.div>
        ))}
      </motion.div>
      <div className="w-full max-w-4xl grid grid-cols-1 sm:grid-cols-2 gap-8 mb-12">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.5 }}
          className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col items-center gap-3 border border-pink-400"
        >
          <FaFire className="text-pink-400 text-2xl" />
          <div className="font-orbitron text-xl text-neon mb-1">Streaks</div>
          {streaks.map(s => (
            <div key={s.id} className="font-inter text-white/80 text-center text-sm">{s.days} days: +{s.bonus} FLZ</div>
          ))}
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col items-center gap-3 border border-green-400"
        >
          <FaUserPlus className="text-green-400 text-2xl" />
          <div className="font-orbitron text-xl text-neon mb-1">Referrals</div>
          {referrals.map(r => (
            <div key={r.id} className="font-inter text-white/80 text-center text-sm">{r.users} users: +{r.bonus} FLZ</div>
          ))}
        </motion.div>
      </div>
    </main>
  );
} 