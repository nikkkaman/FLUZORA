import React from 'react';

export default function GlassButton({ children, onClick, type = 'button', disabled = false, className = '' }: React.PropsWithChildren<{ onClick?: () => void; type?: 'button' | 'submit'; disabled?: boolean; className?: string; }>) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`px-6 py-2 rounded-lg glassmorphic font-orbitron font-bold focus:outline-none disabled:opacity-50 ${className}`}
      aria-disabled={disabled}
    >
      {children}
    </button>
  );
} 