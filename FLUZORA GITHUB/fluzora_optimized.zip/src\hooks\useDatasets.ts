import { useState, useEffect } from 'react';
import { individualDatasets } from '@/data/individual';
import { subscriptionDatasets } from '@/data/subscription';

export type Dataset = {
    id: string;
    name: string;
    domain: string;
    description: string;
    size: string;
    price: number | null;
    pack?: "starter" | "pro" | "premium";
    addToCart?: boolean;
    isPremiumVault?: boolean;
    badges?: string[];
    lastUpdated?: string;
    licenseType?: string;
    version?: string;
    aiPrompt?: string;
    previewText?: string | { q: string; a: string }[];
    tags?: string[];
  };

export function useDatasets(activeTab: string) {
  const [datasets, setDatasets] = useState<Dataset[]>([]);

  useEffect(() => {
    let data: Dataset[] = [];
    switch (activeTab) {
      case 'individual':
        data = individualDatasets;
        break;
      case 'subscription':
        data = subscriptionDatasets.filter((d) => !d.isPremiumVault);
        break;
      case 'premium':
        data = subscriptionDatasets.filter((d) => d.isPremiumVault);
        break;
      case 'all':
        data = [...individualDatasets, ...subscriptionDatasets];
        break;
      default:
        data = [];
    }
    setDatasets(data);
  }, [activeTab]);

  return datasets;
} 