"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { ArrowLeft } from "lucide-react";

const features = [
  {
    title: "The Pioneer's Path",
    description: "As the first AI dataset marketplace, we're writing the opening chapter of a new era in AI development, crafting a story of innovation that begins with you.",
  },
  {
    title: "A World of Knowledge",
    description: "Journey through our vast collection of datasets spanning finance, healthcare, technology, and education - each telling its own unique story.",
  },
  {
    title: "The Guardian's Promise",
    description: "Like master storytellers, we carefully validate and verify each dataset, ensuring every piece of data tells a true and meaningful tale.",
  },
  {
    title: "Seamless Symphony",
    description: "Our APIs and SDKs work in perfect harmony with your AI models, creating a seamless blend of data and innovation.",
  },
  {
    title: "Choose Your Adventure",
    description: "Whether you're starting your journey or leading an enterprise expedition, our flexible pricing adapts to your quest.",
  },
  {
    title: "Guiding Light",
    description: "Our team of AI and data experts stand ready as your trusted guides, illuminating the path to development success.",
  },
];

const stats = [
  { number: "50+", label: "Chapters of Innovation" },
  { number: "12+", label: "Realms of Data" },
  { number: "1000+", label: "Fellow Adventurers" },
  { number: "99.9%", label: "Journey Reliability" },
];

export default function AboutPage() {
  const router = useRouter();
  const { user } = useAuth ? useAuth() : { user: null };
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const seen = localStorage.getItem('aboutOnboardingSeen');
      if (!seen) setShowOnboarding(true);
    }
  }, []);

  const handleDismiss = () => {
    setShowOnboarding(false);
    if (typeof window !== 'undefined') {
      localStorage.setItem('aboutOnboardingSeen', 'true');
    }
  };

  const handleBeginJourney = () => {
    if (!user) {
      router.push("/login");
    } else {
      // You can redirect to home or another page if needed
      router.push("/home");
    }
  };
  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-900 p-8 flex flex-col items-center">
      <button
        onClick={() => router.back()}
        className="absolute left-8 top-20 flex items-center gap-2 px-3 py-2 rounded-full bg-transparent border border-white/30 hover:bg-white/10 hover:border-white/80 text-white transition shadow"
        style={{ zIndex: 10 }}
        aria-label="Back"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="hidden md:inline">Back</span>
      </button>
      {showOnboarding && (
        <div className="w-full max-w-2xl bg-gradient-to-r from-purple-700 to-purple-500 rounded-xl p-6 shadow-lg mb-8 flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Welcome to Fluzora!</h2>
            <p className="text-purple-100 mb-2">Our mission is to empower everyone with accessible, powerful AI and data tools. Learn more about our vision, our team, and how we're building the future of AI for all.</p>
          </div>
          <button onClick={handleDismiss} className="px-4 py-2 rounded bg-white/20 hover:bg-white/40 text-white font-semibold transition">Dismiss</button>
        </div>
      )}
      <div className="min-h-screen bg-black text-white">
        {/* Hero Section */}
        <section className="py-20 px-4 bg-gradient-to-b from-purple-900 to-black">
          <div className="container mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">The FLUZORA Story</h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto">
              In a world where data shapes reality, we craft the narratives that empower AI to understand, learn, and grow. Welcome to our story.
            </p>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl">
            <h2 className="text-3xl font-bold mb-6">Our Epic Journey</h2>
            <p className="text-lg text-gray-300 mb-8">
              Once upon a digital frontier, FLUZORA emerged from a simple yet powerful vision: to democratize the magic of AI development. We believed that every developer, every researcher, and every dreamer deserved access to the finest training data the world could offer.
            </p>
            <p className="text-lg text-gray-300">
              Today, we stand as guardians of quality, shepherds of innovation, and storytellers of the digital age. Each dataset in our collection is a chapter in the grand narrative of AI evolution, carefully curated and validated to ensure your story of success.
            </p>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 px-4 bg-gray-900">
          <div className="container mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-4xl font-bold text-purple-400 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-16 px-4">
          <div className="container mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center">
              Chapters of Excellence
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="bg-gray-800 rounded-lg p-6 hover:bg-gray-700 transition"
                >
                  <h3 className="text-xl font-semibold mb-4 text-purple-400">{feature.title}</h3>
                  <p className="text-gray-300">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Game Zone Coming Soon */}
        <section className="py-16 px-4 bg-gradient-to-b from-black to-purple-900">
          <div className="container mx-auto text-center">
            <div className="inline-block px-6 py-2 bg-purple-600 rounded-full text-sm font-semibold mb-4">
              A New Chapter Awaits
            </div>
            <h2 className="text-4xl font-bold mb-6">The Game Zone Saga</h2>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              On the horizon lies a new adventure - where AI meets play, and learning becomes an epic quest. 
              The Game Zone will transform how you interact with AI, making every discovery a thrilling experience.
            </p>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-16 px-4">
          <div className="container mx-auto max-w-4xl text-center">
            <h2 className="text-3xl font-bold mb-6" style={{ fontFamily: 'Orbitron, Inter, sans-serif' }}>Join Our Tale</h2>
            <p className="text-xl text-gray-300 mb-8" style={{ fontFamily: 'Inter, sans-serif' }}>
              Every great story needs its heroes. Whether you're just beginning your journey or ready to write your next chapter, 
              we're here to help you craft your AI development saga.
            </p>
            <button className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-lg font-semibold transition" onClick={handleBeginJourney}>
              Begin Your Journey
            </button>
          </div>
        </section>
      </div>
    </main>
  );
}
