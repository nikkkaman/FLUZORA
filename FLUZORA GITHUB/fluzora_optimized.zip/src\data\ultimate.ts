export const ultimateDatasets = [
  {
    id: "ult-1",
    name: "Enterprise Financial Analytics Suite",
    domain: "Finance",
    description: "Comprehensive financial data including market trends, trading patterns, and economic indicators spanning 10 years. Perfect for building advanced trading algorithms and financial forecasting models.",
    size: "8.5GB",
    price: 999,
    previewText: [
      { q: "How do financial experts predict market trends?", a: "This suite offers a decade of market data and trading records, perfect for building advanced trading bots and financial forecasting models." },
      { q: "Can I build a predictive trading model?", a: "Absolutely—use this data to train and test your own trading algorithms." },
      { q: "What insights can I gain from economic indicators?", a: "Spot trends, forecast market movements, and optimize investment strategies with real data." },
      { q: "Is this data suitable for advanced users?", a: "Yes! It's designed for professionals and researchers in finance and data science." },
      { q: "How can I impress in a finance interview?", a: "Showcase your skills by building a financial forecasting tool using this dataset!" }
    ]
  },
  {
    id: "ult-2",
    name: "Healthcare Research Megapack",
    domain: "Healthcare",
    description: "Extensive medical research data including patient records, treatment outcomes, and clinical trials from leading institutions. Ideal for developing diagnostic AI and treatment prediction models.",
    size: "10GB",
    price: 1299,
    previewText: [
      { q: "What can we learn from global medical research?", a: "Access comprehensive patient records, clinical trial results, and treatment outcomes for advanced medical research and AI diagnostics." },
      { q: "Can I build a diagnostic AI model?", a: "Yes! Use this data to train and validate your own healthcare AI models." },
      { q: "How can I improve patient outcomes?", a: "Analyze treatment effectiveness and optimize care strategies with real data." },
      { q: "Is this data suitable for healthcare professionals?", a: "Absolutely—it's designed for advanced research and application in healthcare." },
      { q: "How can I impress in a medical research interview?", a: "Showcase your skills by building a clinical trial analysis tool using this dataset!" }
    ]
  },
  {
    id: "ult-3",
    name: "Global E-commerce Intelligence",
    domain: "Retail",
    description: "Complete e-commerce dataset with consumer behavior, purchase patterns, and market trends from major global marketplaces. Essential for building recommendation systems and demand forecasting models.",
    size: "7.8GB",
    price: 899,
    previewText: [
      { q: "How do shopping habits differ around the world?", a: "Analyze worldwide shopping trends, customer purchase histories, and product analytics for global e-commerce insights." },
      { q: "Can I build a recommendation system?", a: "Absolutely—use this data to train and test your own recommendation algorithms." },
      { q: "What insights can I gain from market trends?", a: "Identify trends, forecast market movements, and optimize sales strategies with real data." },
      { q: "Is this data suitable for retail professionals?", a: "Yes! It's designed for professionals and researchers in retail and data science." },
      { q: "How can I impress in a retail interview?", a: "Showcase your skills by building a recommendation tool using this dataset!" }
    ]
  },
  {
    id: "ult-4",
    name: "Advanced NLP Training Corpus",
    domain: "Natural Language",
    description: "Massive collection of multilingual text data, including news articles, academic papers, and social media content. Perfect for training large language models and sentiment analysis systems.",
    size: "9.2GB",
    price: 1199,
    previewText: [
      { q: "How do you train a language model?", a: "Use millions of text samples in multiple languages, including news, research, and social media, for NLP and AI training." },
      { q: "Can I build a sentiment analysis model?", a: "Yes! Use this data to train and validate your own sentiment analysis algorithms." },
      { q: "What insights can I gain from text data?", a: "Identify trends, analyze sentiment, and optimize content strategies with real data." },
      { q: "Is this data suitable for NLP professionals?", a: "Yes! It's designed for professionals and researchers in natural language processing and AI." },
      { q: "How can I impress in an NLP interview?", a: "Showcase your skills by building a sentiment analysis tool using this dataset!" }
    ]
  },
  {
    id: "ult-5",
    name: "Industrial IoT Analytics Bundle",
    domain: "Industrial",
    description: "Comprehensive IoT sensor data from manufacturing plants, including equipment performance, maintenance records, and environmental readings. Ideal for predictive maintenance and optimization models.",
    size: "6.5GB",
    price: 799,
    previewText: [
      { q: "How can factories predict equipment failures?", a: "Analyze sensor readings, equipment logs, and maintenance records for predictive maintenance and industrial optimization." },
      { q: "Can I build a predictive maintenance model?", a: "Absolutely—use this data to train and test your own maintenance algorithms." },
      { q: "What insights can I gain from industrial data?", a: "Identify trends, optimize processes, and reduce downtime with real data." },
      { q: "Is this data suitable for industrial professionals?", a: "Yes! It's designed for professionals and researchers in industrial and data science." },
      { q: "How can I impress in an industrial interview?", a: "Showcase your skills by building a predictive maintenance tool using this dataset!" }
    ]
  },
  {
    id: "ult-6",
    name: "Autonomous Vehicle Vision Dataset",
    domain: "Automotive",
    description: "High-resolution image and video data from autonomous vehicle testing, including object detection, traffic patterns, and environmental conditions. Essential for training self-driving AI systems.",
    size: "12GB",
    price: 1499,
    previewText: [
      { q: "What do self-driving cars see on the road?", a: "Access thousands of images and videos from self-driving car tests, with object detection and traffic scenarios for computer vision AI." },
      { q: "Can I build a self-driving AI model?", a: "Absolutely—use this data to train and test your own self-driving algorithms." },
      { q: "What insights can I gain from vehicle data?", a: "Identify trends, optimize routes, and reduce accidents with real data." },
      { q: "Is this data suitable for automotive professionals?", a: "Yes! It's designed for professionals and researchers in automotive and data science." },
      { q: "How can I impress in an automotive interview?", a: "Showcase your skills by building a self-driving tool using this dataset!" }
    ]
  },
  {
    id: "ult-7",
    name: "Climate Science Research Pack",
    domain: "Environmental",
    description: "Extensive climate and environmental data including satellite imagery, weather patterns, and ecological indicators. Perfect for climate modeling and environmental impact prediction.",
    size: "8.8GB",
    price: 999,
    previewText: [
      { q: "How is climate change measured globally?", a: "Use satellite images, weather records, and ecological data for climate modeling and environmental research." },
      { q: "Can I build a climate modeling model?", a: "Yes! Use this data to train and validate your own climate models." },
      { q: "What insights can I gain from environmental data?", a: "Identify trends, forecast climate changes, and optimize environmental strategies with real data." },
      { q: "Is this data suitable for environmental professionals?", a: "Yes! It's designed for professionals and researchers in environmental and data science." },
      { q: "How can I impress in an environmental interview?", a: "Showcase your skills by building a climate modeling tool using this dataset!" }
    ]
  },
  {
    id: "ult-8",
    name: "Cybersecurity Threat Database",
    domain: "Security",
    description: "Comprehensive cybersecurity dataset including threat patterns, attack signatures, and vulnerability data. Essential for developing AI-powered security systems and threat detection models.",
    size: "7.2GB",
    price: 899,
    previewText: [
      { q: "How do experts detect cyber threats?", a: "Analyze threat signatures, attack logs, and vulnerability reports from real-world incidents for AI-powered cybersecurity." },
      { q: "Can I build a cybersecurity AI model?", a: "Yes! Use this data to train and validate your own cybersecurity algorithms." },
      { q: "What insights can I gain from cybersecurity data?", a: "Identify threats, optimize defenses, and protect digital assets with real data." },
      { q: "Is this data suitable for cybersecurity professionals?", a: "Yes! It's designed for professionals and researchers in cybersecurity and data science." },
      { q: "How can I impress in a cybersecurity interview?", a: "Showcase your skills by building a cybersecurity tool using this dataset!" }
    ]
  },
  {
    id: "ult-9",
    name: "Quantum Computing Research Vault",
    domain: "Quantum Technology",
    description: "Quantum algorithms, simulation results, and hardware benchmarks for next-gen computing research.",
    size: "6.8GB",
    price: 1499,
    previewText: [
      { q: "What quantum topics are covered?", a: "Algorithms, error correction, and quantum hardware performance." },
      { q: "Is this data suitable for simulation?", a: "Yes, includes simulation results and real device benchmarks." },
      { q: "Can I use this for quantum AI?", a: "Perfect for hybrid quantum-classical model research." },
      { q: "What makes this vault unique?", a: "Depth, accuracy, and real-world quantum hardware data." },
      { q: "Is this for advanced users?", a: "Yes, ideal for researchers and PhD students." }
    ]
  },
  {
    id: "ult-10",
    name: "Global Social Media Sentiment Pack",
    domain: "Social Media",
    description: "Billions of posts, comments, and reactions from major platforms for sentiment analysis and trend prediction.",
    size: "12GB",
    price: 1399,
    previewText: [
      { q: "Which platforms are included?", a: "Twitter, Facebook, Instagram, Reddit, and more." },
      { q: "Is the data labeled for sentiment?", a: "Yes, with positive, negative, and neutral tags." },
      { q: "Can I use this for trend prediction?", a: "Ideal for real-time trend and topic analysis." },
      { q: "How is privacy handled?", a: "All user data is anonymized and compliant." },
      { q: "What makes this pack unique?", a: "Scale, diversity, and up-to-date global coverage." }
    ]
  }
];
