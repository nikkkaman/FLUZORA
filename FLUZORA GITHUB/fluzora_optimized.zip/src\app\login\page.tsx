"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { Database, Lock, ArrowRight, Github } from "lucide-react";
import Image from "next/image";

export default function LoginPage() {
  const [email, setEmail] = useState("demo@fluzora.com");
  const [password, setPassword] = useState("demo123");
  const [error, setError] = useState("");
  const router = useRouter();
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      const success = await login(email, password);
      if (success) {
        router.push("/home");
      } else {
        setError("Invalid credentials. Please try again.");
      }
    } catch (err) {
      setError("An error occurred during login.");
    }
  };

  const handleGoogleLogin = () => {
    // For demo purposes, we'll just use the demo account
    login("demo@fluzora.com", "demo123").then((success) => {
      if (success) {
        router.push("/home");
      }
    });
  };

  const handleGithubLogin = () => {
    // For demo purposes, we'll just use the demo account
    // For demo purposes, we'll just use the demo account
    // For demo purposes, we'll just use the demo account
    login("demo@fluzora.com", "demo123").then((success) => {
      if (success) {
        router.push("/home");
      }
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-black flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-sm"
      >
        <div className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-4 border border-purple-500/20">
          <div className="text-center mb-6">
            <Link href="/" className="inline-block">
              <h1 className="text-5xl font-extrabold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
                FLUZORA
              </h1>
            </Link>
            <p className="mt-2 text-gray-400">Welcome back to the future of AI</p>
          </div>

          {/* Social Login Buttons */}
          <div className="space-y-4 mb-6">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleGoogleLogin}
              className="w-full bg-white text-gray-800 py-2 rounded-lg font-semibold shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all duration-300 flex items-center justify-center gap-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="24px" height="24px">
                <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z" />
                <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z" />
                <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z" />
                <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z" />
              </svg>
              Sign in with Google
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleGithubLogin}
              className="w-full bg-gray-800 text-white py-2 rounded-lg font-semibold shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all duration-300 flex items-center justify-center gap-2"
            >
              <Github size={24} />
              Sign in with GitHub
            </motion.button>
          </div>

          <div className="relative flex items-center justify-center mb-6">
            <div className="border-t border-gray-600 flex-grow"></div>
            <span className="mx-4 text-gray-400 text-sm">or sign in with email</span>
            <div className="border-t border-gray-600 flex-grow"></div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="mb-8 z-20 relative">
              <label className="block text-base font-semibold text-purple-200 mb-2 tracking-wide">
                Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-purple-900/30 border border-purple-500/50 rounded-lg px-4 py-2 text-white font-medium focus:outline-none focus:border-purple-400 pl-10 text-base shadow-md"
                  placeholder="Enter your email"
                  required
                />
                <Database className="absolute left-3 top-3.5 h-5 w-5 text-purple-400" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-purple-900/30 border border-purple-500/50 rounded-lg px-4 py-2 text-white font-medium focus:outline-none focus:border-purple-400 pl-10 text-base shadow-md"
                  placeholder="Enter your password"
                  required
                />
                <Lock className="absolute left-3 top-3.5 h-5 w-5 text-purple-400" />
              </div>
            </div>

            {error && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-red-400 text-sm mt-2"
              >
                {error}
              </motion.p>
            )}

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 rounded-lg font-semibold shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 transition-all duration-300 flex items-center justify-center gap-2"
            >
              Sign In <ArrowRight size={18} />
            </motion.button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-400">
              Don&apos;t have an account?{" "}
              <Link
                href="/signup"
                className="text-purple-400 hover:text-purple-300 font-medium"
              >
                Create one
              </Link>
            </p>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-700">
            {/* You can add additional info or links here if needed, or leave this div empty */}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
