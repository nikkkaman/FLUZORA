"use client";
import React, { useRef, useState } from "react";
import { motion } from "framer-motion";
import { FaUpload, FaCheckCircle, FaTimesCircle } from "react-icons/fa";

export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<null | "success" | "error" | "validating">(null);
  const [message, setMessage] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setStatus("validating");
      setTimeout(() => {
        // Mock OpenAPI validation
        if (e.target.files[0].name.endsWith(".csv") || e.target.files[0].name.endsWith(".json")) {
          setStatus("success");
          setMessage("Upload successful! +120 FLZ awarded.");
        } else {
          setStatus("error");
          setMessage("File rejected: Only .csv or .json allowed.");
        }
      }, 1200);
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg">Upload Dataset</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">Contribute your dataset and earn FLZ tokens. Only .csv or .json files are accepted. Quality and metadata matter for higher rewards!</p>
      </motion.div>
      <motion.form
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="bg-black/60 border-2 border-neon/40 rounded-2xl p-8 shadow-lg flex flex-col items-center gap-6 w-full max-w-md backdrop-blur-md"
        onSubmit={e => e.preventDefault()}
      >
        <input
          type="file"
          accept=".csv,.json"
          ref={inputRef}
          onChange={handleFile}
          className="block w-full text-white file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-neon/20 file:text-neon hover:file:bg-neon/40 transition mb-4"
        />
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="px-8 py-3 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 text-white font-orbitron font-bold shadow-lg hover:scale-105 transition-all"
        >
          <FaUpload className="inline mr-2" /> Select File
        </button>
        {status === "validating" && <div className="text-yellow-400 font-inter animate-pulse">Validating...</div>}
        {status === "success" && <div className="text-green-400 font-inter flex items-center gap-2"><FaCheckCircle /> {message}</div>}
        {status === "error" && <div className="text-red-400 font-inter flex items-center gap-2"><FaTimesCircle /> {message}</div>}
      </motion.form>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-10 text-center"
      >
        <div className="font-orbitron text-xl text-neon mb-2">FLZ Rewards</div>
        <div className="font-inter text-white/80">Earn more FLZ for high-quality, well-documented, and unique datasets. Bonus for metadata and domain relevance!</div>
      </motion.div>
    </main>
  );
} 