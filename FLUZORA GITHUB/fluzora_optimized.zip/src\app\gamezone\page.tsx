import dynamic from 'next/dynamic';
import GameZoneRoot from '../../gamezone/layout/GameZoneRoot';

const GameZoneHome = dynamic(() => import('../../gamezone/pages/index'), { ssr: false });

export default function GameZonePage() {
  return (
    <GameZoneRoot>
      <GameZoneHome />
    </GameZoneRoot>
  );
} 