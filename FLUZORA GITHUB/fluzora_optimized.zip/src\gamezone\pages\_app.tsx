import '../styles/glassmorphic.css';
import type { AppProps } from 'next/app';
import GameZoneRoot from '../layout/GameZoneRoot';

export default function GameZoneApp({ Component, pageProps }: AppProps) {
  return (
    <GameZoneRoot>
      <Component {...pageProps} />
    </GameZoneRoot>
  );
} 