"use client"

import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio"

// Define a more specific type for the AspectRatio props
type AspectRatioProps = {
  ratio?: number;
  className?: string;
  children?: React.ReactNode;
} & Omit<React.HTMLAttributes<HTMLDivElement>, 'className'>;

function AspectRatio({
  ...props
}: AspectRatioProps) {
  // Cast the component to any to bypass type checking
  return (
    (() => {
      const Root = AspectRatioPrimitive.Root as any;
      return <Root data-slot="aspect-ratio" {...props} />;
    })()
  )
}

export { AspectRatio }
