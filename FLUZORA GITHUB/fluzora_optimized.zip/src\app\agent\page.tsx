"use client";

import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Brain, Bot, Activity, Shield, Sparkles, Send } from "lucide-react";

const aiAgents = [
  {
    id: "financial",
    name: "Financial Assistant",
    icon: Activity,
    description: "Advanced AI for financial analysis and market predictions",
    capabilities: [
      "Real-time market analysis",
      "Investment strategies",
      "Risk assessment",
      "Portfolio optimization"
    ],
    gradient: "from-blue-500 to-purple-600"
  },
  {
    id: "healthcare",
    name: "Healthcare Assistant",
    icon: Shield,
    description: "Intelligent healthcare analysis and diagnostics support",
    capabilities: [
      "Medical data analysis",
      "Treatment recommendations",
      "Health monitoring",
      "Research assistance"
    ],
    gradient: "from-purple-500 to-pink-600"
  },
  {
    id: "ultimate",
    name: "Ultimate Assistant",
    icon: Brain,
    description: "Comprehensive AI assistant for all domains",
    capabilities: [
      "Multi-domain expertise",
      "Advanced reasoning",
      "Complex problem solving",
      "Adaptive learning"
    ],
    gradient: "from-pink-500 to-red-600"
  }
];

export default function AgentPage() {
  const [selectedAgent, setSelectedAgent] = useState(aiAgents[0]);
  const [message, setMessage] = useState("");
  const [conversation, setConversation] = useState<Array<{ role: string; content: string }>>([]);
  const [realTalkMode, setRealTalkMode] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const seen = localStorage.getItem('agentOnboardingSeen');
      if (!seen) setShowOnboarding(true);
    }
  }, []);

  const handleDismiss = () => {
    setShowOnboarding(false);
    if (typeof window !== 'undefined') {
      localStorage.setItem('agentOnboardingSeen', 'true');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    // Add user message
    setConversation([...conversation, { role: "user", content: message }]);
    
    // Simulate AI response
    setTimeout(() => {
      setConversation(prev => [...prev, {
        role: "assistant",
        content: `This is a response from ${selectedAgent.name}. In the full version, you'll get intelligent responses based on your query.`
      }]);
    }, 1000);

    setMessage("");
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-900 p-8 flex flex-col items-center">
      {showOnboarding && (
        <div className="w-full max-w-2xl bg-gradient-to-r from-purple-700 to-purple-500 rounded-xl p-6 shadow-lg mb-8 flex flex-col md:flex-row items-center justify-between gap-4 animate-fade-in">
          <div>
            <h2 className="text-2xl font-bold text-white mb-1">Welcome to Agents!</h2>
            <p className="text-purple-100 mb-2">Agents are your AI-powered assistants. Create, customize, and deploy agents to automate tasks, answer questions, and more. Get started by clicking 'Create Agent' below.</p>
          </div>
          <button onClick={handleDismiss} className="px-4 py-2 rounded bg-white/20 hover:bg-white/40 text-white font-semibold transition">Dismiss</button>
        </div>
      )}
      <div className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 mb-4">
            FLUZORA Assistant
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            This assistant is powered by FLUZORA datasets and built to showcase how real-world AI agents think, plan, and respond.
          </p>
        </motion.div>
        
        <div className="flex justify-center mb-8">
          <div className="flex items-center bg-purple-900/30 backdrop-blur-sm rounded-lg px-4 py-2 border border-purple-500/30">
            <span className="mr-3 text-gray-300">Real Talk Mode</span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                className="sr-only peer" 
                checked={realTalkMode}
                onChange={() => setRealTalkMode(!realTalkMode)}
              />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
            </label>
          </div>
        </div>
        
        {realTalkMode && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-4 mb-8 max-w-2xl mx-auto"
          >
            <p className="text-yellow-300 flex items-center">
              <span className="text-2xl mr-2">⚠️</span> 
              This assistant gives brutally honest advice. It may challenge your thinking or point out hard truths. If you're okay with that, continue.
            </p>
          </motion.div>
        )}

        {/* AI Agents Selection */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {aiAgents.map((agent) => (
            <motion.div
              key={agent.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedAgent(agent)}
              className={`cursor-pointer p-6 rounded-lg border ${
                selectedAgent.id === agent.id
                  ? "border-purple-500 bg-purple-900/30"
                  : "border-purple-500/20 bg-purple-900/20"
              } backdrop-blur-sm transition-all duration-300`}
            >
              <div className="flex items-center gap-4 mb-4">
                <div className={`p-2 rounded-lg bg-gradient-to-r ${agent.gradient}`}>
                  <agent.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold">{agent.name}</h3>
              </div>
              <p className="text-gray-300 mb-4">{agent.description}</p>
              <ul className="space-y-2">
                {agent.capabilities.map((capability, index) => (
                  <li key={index} className="flex items-center gap-2 text-sm text-gray-400">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    {capability}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Chat Interface */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-purple-900/20 backdrop-blur-sm rounded-lg border border-purple-500/20 p-6"
        >
          <div className="flex items-center gap-3 border-b border-purple-500/20 pb-4 mb-6">
            <Bot className="w-6 h-6 text-purple-400" />
            <h2 className="text-xl font-semibold">Chat with {selectedAgent.name}</h2>
          </div>

          {/* Conversation Area */}
          <div className="h-[400px] overflow-y-auto mb-6 space-y-4 scrollbar-thin scrollbar-thumb-purple-500/20 scrollbar-track-transparent">
            {conversation.map((msg, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex ${
                  msg.role === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-4 ${
                    msg.role === "user"
                      ? "bg-purple-600/40 text-white"
                      : "bg-gray-800/40 text-gray-200"
                  }`}
                >
                  {msg.content}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Input Area */}
          <form onSubmit={handleSubmit} className="flex gap-4">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={`Ask ${selectedAgent.name} anything...`}
              className="flex-1 bg-purple-900/30 border border-purple-500/30 rounded-lg px-4 py-3 text-gray-100 focus:outline-none focus:border-purple-500"
            />
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              type="submit"
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg font-semibold flex items-center gap-2"
            >
              Send <Send className="w-4 h-4" />
            </motion.button>
          </form>
        </motion.div>
      </div>
    </main>
  );
}