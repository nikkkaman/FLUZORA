'use client';
import React, { createContext, useContext, useState } from 'react';

const mockUser = {
  id: 'user1',
  name: 'DataNinja',
  avatar: '/default-avatar.svg',
  flz: 1250,
  streak: 5,
  milestones: ["First Upload", "10 Datasets"],
};

const mockChallenges = [
  { id: 'c1', title: 'Medical Imaging', domain: 'Health', bonus: 200, deadline: '2024-07-10' },
  { id: 'c2', title: 'Climate Data', domain: 'Environment', bonus: 150, deadline: '2024-07-15' },
];

const mockLeaderboard = [
  { id: 'user1', name: 'DataNinja', avatar: '/default-avatar.svg', flz: 1250, uploads: 12 },
  { id: 'user2', name: 'QuantumQueen', avatar: '/default-avatar.svg', flz: 1100, uploads: 10 },
  { id: 'user3', name: 'StatSamurai', avatar: '/default-avatar.svg', flz: 950, uploads: 8 },
];

const mockVault = [
  { id: 'd1', title: 'Genomics 2024', price: 500, preview: 'genomics.csv' },
  { id: 'd2', title: 'Satellite Images', price: 700, preview: 'satellite.csv' },
];

const mockAvatars = [
  { id: 'a1', src: '/default-avatar.svg', price: 200, owned: true },
  { id: 'a2', src: '/default-avatar.svg', price: 300, owned: false },
];

const mockBilling = [
  { id: 'b1', type: 'earn', amount: 200, date: '2024-06-01', desc: 'Challenge Bonus' },
  { id: 'b2', type: 'spend', amount: 500, date: '2024-06-02', desc: 'Vault Redemption' },
];

const GameZoneContext = createContext<any>(null);

export function GameZoneProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState(mockUser);
  const [challenges, setChallenges] = useState(mockChallenges);
  const [leaderboard, setLeaderboard] = useState(mockLeaderboard);
  const [vault, setVault] = useState(mockVault);
  const [avatars, setAvatars] = useState(mockAvatars);
  const [billing, setBilling] = useState(mockBilling);

  return (
    <GameZoneContext.Provider value={{ user, setUser, challenges, setChallenges, leaderboard, setLeaderboard, vault, setVault, avatars, setAvatars, billing, setBilling }}>
      {children}
    </GameZoneContext.Provider>
  );
}

export function useGameZoneContext() {
  return useContext(GameZoneContext);
} 