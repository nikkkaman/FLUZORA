'use client';
import React from 'react';
import { useGameZoneContext } from '../context/GameZoneContext';
import GlassCard from './ui/GlassCard';

const trophyColors = [
  'bg-gradient-to-r from-yellow-400 to-yellow-200',
  'bg-gradient-to-r from-gray-400 to-gray-200',
  'bg-gradient-to-r from-orange-400 to-orange-200',
];

export default function Leaderboard() {
  const { leaderboard } = useGameZoneContext();
  return (
    <GlassCard>
      <div className="font-orbitron text-neon text-xl mb-4">Leaderboard</div>
      <div className="mb-2 text-white/60 font-inter">Top 10 contributors. Auto-refreshes every 30s.</div>
      <div className="overflow-x-auto">
        <table className="min-w-full text-left">
          <thead>
            <tr className="text-neon font-orbitron text-lg">
              <th className="py-2">#</th>
              <th className="py-2">Avatar</th>
              <th className="py-2">Name</th>
              <th className="py-2">FLZ</th>
              <th className="py-2">Uploads</th>
            </tr>
          </thead>
          <tbody>
            {leaderboard.map((u: any, i: number) => (
              <tr key={u.id} className="border-b border-white/10 hover:bg-neon/5 transition-all">
                <td className="py-2 font-bold">
                  {i < 3 ? (
                    <span className={`inline-block w-8 h-8 rounded-full flex items-center justify-center animate-bounce ${trophyColors[i]}`}>🏆</span>
                  ) : (
                    <span>{i + 1}</span>
                  )}
                </td>
                <td className="py-2">
                  <img src={u.avatar} alt={u.name} className="w-10 h-10 rounded-full border-2 border-neon" />
                </td>
                <td className="py-2 font-orbitron text-white/90">{u.name}</td>
                <td className="py-2 text-neon font-bold">{u.flz}</td>
                <td className="py-2 text-white/80">{u.uploads}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </GlassCard>
  );
}
 