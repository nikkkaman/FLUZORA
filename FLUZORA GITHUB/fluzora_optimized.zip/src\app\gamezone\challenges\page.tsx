"use client";
import React from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { FaTrophy } from "react-icons/fa";

const challenges = [
  { id: 1, title: "Medical Imaging", domain: "Health", bonus: 200, deadline: "2024-07-10" },
  { id: 2, title: "Climate Data", domain: "Environment", bonus: 150, deadline: "2024-07-15" },
  { id: 3, title: "Finance Friday", domain: "Finance", bonus: 300, deadline: "2024-07-12" },
];

export default function ChallengesPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg">Challenges</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">Compete in themed events for bonus FLZ and badges. Submit your best datasets to win!</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full max-w-4xl grid grid-cols-1 sm:grid-cols-2 gap-8"
      >
        {challenges.map((c, i) => (
          <motion.div
            key={c.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i, duration: 0.5 }}
            className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col gap-3 border border-yellow-500"
          >
            <div className="flex items-center gap-2 mb-2">
              <FaTrophy className="text-yellow-400 text-2xl" />
              <span className="font-orbitron text-xl text-neon">{c.title}</span>
              <span className="ml-auto px-3 py-1 rounded-full bg-yellow-400/10 text-yellow-400 font-bold text-xs">{c.domain}</span>
            </div>
            <div className="flex items-center gap-4 text-white/80 font-inter">
              <span>Bonus: <span className="text-neon font-bold">+{c.bonus} FLZ</span></span>
              <span className="ml-auto">Deadline: <span className="text-neon">{c.deadline}</span></span>
            </div>
            <Link href="/gamezone/upload" className="mt-4 px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform text-center">Upload</Link>
          </motion.div>
        ))}
      </motion.div>
    </main>
  );
} 