"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { showSuccess } from "@/components/ui/sonner";
import { Skeleton } from "@/components/ui/skeleton";

export default function SettingsPage() {
  const router = useRouter();
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [notifications, setNotifications] = useState({
    dataset: true,
    updates: false,
  });
  const [twoFA, setTwoFA] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const timeout = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timeout);
  }, []);

  const handlePassword = () => setShowPasswordModal(true);
  const handleClosePassword = () => setShowPasswordModal(false);
  const handleDelete = () => setShowDeleteModal(true);
  const handleCloseDelete = () => setShowDeleteModal(false);
  const handleToggle = (key: string) => {
    setNotifications((prev) => ({ ...prev, [key]: !prev[key as keyof typeof prev] }));
  };
  const handleToggle2FA = () => setTwoFA((prev) => !prev);

  // Dummy user data
  const user = {
    name: "Demo User",
    email: "demo@fluzora.com",
    avatar: "/default-avatar.svg",
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-900 p-8 flex flex-col items-center">
      <button
        onClick={() => router.back()}
        className="absolute left-8 top-8 flex items-center gap-2 px-3 py-2 rounded-full bg-transparent border border-white/30 hover:bg-white/10 hover:border-white/80 text-white transition shadow"
        style={{ zIndex: 10 }}
        aria-label="Back"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="hidden md:inline">Back</span>
      </button>
      {loading ? (
        <Skeleton className="w-full max-w-2xl h-[600px] rounded-xl mb-8" />
      ) : (
      <div className="w-full max-w-2xl bg-gray-800/80 rounded-xl p-8 shadow-xl">
        <h1 className="text-3xl font-bold text-white mb-8">Settings</h1>
        {/* Profile Section */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-purple-300 mb-2">Profile</h2>
          <div className="flex items-center justify-between bg-black/30 rounded-lg p-4 text-white/90">
            <div className="flex items-center gap-4">
              <img src={user.avatar} alt="avatar" className="w-14 h-14 rounded-full border-2 border-purple-500" />
              <div>
                <div className="mb-1">Name: <span className="font-semibold">{user.name}</span></div>
                <div>Email: <span className="font-semibold">{user.email}</span></div>
              </div>
            </div>
            <Link href="/settings/edit-profile">
              <button className="ml-4 px-4 py-2 rounded bg-purple-600 text-white hover:bg-purple-700 transition font-semibold shadow">Edit Profile</button>
            </Link>
          </div>
        </section>
        {/* Security Section */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-purple-300 mb-2">Security</h2>
          <div className="flex items-center justify-between bg-black/30 rounded-lg p-4 text-white/90 mb-3">
            <span>Password: <span className="font-semibold">********</span></span>
            <button className="ml-4 px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 transition font-semibold shadow" onClick={handlePassword}>Change Password</button>
          </div>
          <div className="flex items-center justify-between bg-black/30 rounded-lg p-4 text-white/90">
            <span>Two-Factor Authentication</span>
            <button className={`ml-4 px-4 py-2 rounded font-semibold shadow ${twoFA ? 'bg-green-600 text-white' : 'bg-gray-600 text-white'}`} onClick={handleToggle2FA}>{twoFA ? 'Enabled' : 'Enable 2FA'}</button>
          </div>
        </section>
        {/* Notification Preferences */}
        <section className="mb-8">
          <h2 className="text-xl font-bold text-purple-300 mb-2">Notification Preferences</h2>
          <div className="bg-black/30 rounded-lg p-4 text-white/90 flex flex-col gap-3">
            <label className="flex items-center gap-3">
              <input type="checkbox" className="accent-purple-500" checked={notifications.dataset} onChange={() => handleToggle('dataset')} />
              Email me about new datasets
            </label>
            <label className="flex items-center gap-3">
              <input type="checkbox" className="accent-purple-500" checked={notifications.updates} onChange={() => handleToggle('updates')} />
              Product updates
            </label>
          </div>
        </section>
        {/* Danger Zone */}
        <section>
          <h2 className="text-xl font-bold text-red-400 mb-2">Danger Zone</h2>
          <div className="flex items-center justify-between bg-black/30 rounded-lg p-4 text-white/90">
            <span>Delete Account</span>
            <button className="ml-4 px-4 py-2 rounded bg-red-600 text-white hover:bg-red-700 transition font-semibold shadow" onClick={handleDelete}>Delete</button>
          </div>
        </section>
      </div>
      )}
      {/* Password Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full shadow-lg flex flex-col items-center">
            <h3 className="text-2xl font-bold mb-4 text-blue-700">Change Password</h3>
            <p className="mb-6 text-gray-700">Password change coming soon.</p>
            <button className="px-6 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 font-semibold shadow" onClick={() => { showSuccess('Password changed!'); handleClosePassword(); }}>Close</button>
          </div>
        </div>
      )}
      {/* Delete Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full shadow-lg flex flex-col items-center">
            <h3 className="text-2xl font-bold mb-4 text-red-700">Delete Account</h3>
            <p className="mb-6 text-gray-700">Are you sure you want to delete your account? This action cannot be undone.</p>
            <div className="flex gap-4">
              <button className="px-6 py-2 rounded bg-gray-300 text-gray-800 font-semibold shadow" onClick={handleCloseDelete}>Cancel</button>
              <button className="px-6 py-2 rounded bg-red-600 text-white hover:bg-red-700 font-semibold shadow" onClick={() => { showSuccess('Account deleted!'); handleCloseDelete(); }}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
} 