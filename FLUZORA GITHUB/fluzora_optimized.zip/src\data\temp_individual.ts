export const individualDatasets = [
  // Original datasets
  {
    id: "ind-1",
    name: "Financial Analytics Fundamentals",
    domain: "Finance",
    description: "Essential financial metrics, market indicators, and investment patterns for building basic trading models and portfolio analysis systems.",
    size: "350MB",
    price: 20,
    addToCart: true,
    previewText: [
      { q: "How can I spot winning stocks before others?", a: "Leverage daily price trends and market signals to identify high-potential stocks early." },
      { q: "Can I build my own trading strategy?", a: "Yes! Use this data to test and refine your trading ideas with real market numbers." },
      { q: "What drives market movements?", a: "Analyze key financial indicators and investment patterns to understand what moves the market." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of financial analysis and portfolio building." },
      { q: "How can I impress in a finance interview?", a: "Showcase your skills by building a mini trading model using this dataset!" }
    ]
  },
  {
    id: "ind-2",
    name: "Healthcare Diagnostics Starter",
    domain: "Healthcare",
    description: "Curated medical data including patient symptoms, diagnostic outcomes, and treatment effectiveness metrics for basic healthcare AI models.",
    size: "320MB",
    price: 45,
    addToCart: true,
    previewText: [
      { q: "Can I predict diseases from symptoms?", a: "Train simple AI models to forecast diagnoses based on real patient data." },
      { q: "How do treatments impact outcomes?", a: "Explore the effectiveness of different treatments and improve care strategies." },
      { q: "Is this data privacy-safe?", a: "Yes, all records are anonymized for safe research and learning." },
      { q: "Can I use this for a health app prototype?", a: "Definitely—jumpstart your healthcare app with real-world data." },
      { q: "What makes this dataset unique?", a: "It combines symptoms, outcomes, and treatments for a holistic view of patient journeys." }
    ]
  },
  {
    id: "ind-3",
    name: "E-commerce Intelligence Basic",
    domain: "Retail",
    description: "Core e-commerce metrics including customer behavior, product performance, and basic market trends for entry-level recommendation systems.",
    size: "280MB",
    price: 52,
    addToCart: true,
    previewText: [
      { q: "What products do customers love most?", a: "Analyze shopping habits and product sales to create your own recommendation engine or sales dashboard." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of e-commerce analytics and product recommendation." },
      { q: "How can I use this data for marketing?", a: "Leverage customer behavior data to target ads and personalize shopping experiences." },
      { q: "Can I use this for a retail app prototype?", a: "Definitely—jumpstart your retail app with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes customer behavior, product performance, and basic market trends for comprehensive analysis." }
    ]
  },
  {
    id: "ind-4",
    name: "Autonomous Vehicle Navigation Pack",
    domain: "Automotive",
    description: "Comprehensive dataset for training autonomous vehicle navigation systems, including road conditions, traffic patterns, and obstacle detection scenarios.",
    size: "950MB",
    price: 135,
    addToCart: true,
    previewText: [
      { q: "How do self-driving cars see the road?", a: "Explore detailed driving scenarios, road conditions, and traffic data to experiment with autonomous vehicle algorithms." },
      { q: "Can I use this for a self-driving car prototype?", a: "Definitely—jumpstart your self-driving car project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes road conditions, traffic patterns, and obstacle detection scenarios for comprehensive training." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of autonomous vehicle technology and navigation." },
      { q: "How can I impress in an automotive interview?", a: "Showcase your skills by building a mini autonomous vehicle navigation system using this dataset!" }
    ]
  },
  {
    id: "ind-5",
    name: "Smart City Infrastructure Data",
    domain: "Urban Planning",
    description: "Urban infrastructure metrics, traffic flow patterns, and utility usage data for smart city planning and optimization.",
    size: "780MB",
    price: 108,
    addToCart: true,
    previewText: [
      { q: "How can cities become smarter?", a: "Discover city traffic flows, infrastructure usage, and utility patterns to power urban planning and smart city projects." },
      { q: "Can I use this for a smart city app prototype?", a: "Definitely—jumpstart your smart city project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes urban infrastructure metrics, traffic flow patterns, and utility usage data for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of urban planning and smart city technology." },
      { q: "How can I impress in a smart city interview?", a: "Showcase your skills by building a mini smart city infrastructure system using this dataset!" }
    ]
  },
  {
    id: "ind-6",
    name: "Climate Change Analytics Bundle",
    domain: "Environmental",
    description: "Environmental data including temperature patterns, emission metrics, and climate change indicators for predictive modeling.",
    size: "850MB",
    price: 130,
    addToCart: true,
    previewText: [
      { q: "Can I track climate change over time?", a: "Access temperature records, emission data, and climate indicators for powerful climate change analysis and prediction." },
      { q: "Can I use this for a climate change app prototype?", a: "Definitely—jumpstart your climate change project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes temperature patterns, emission metrics, and climate change indicators for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of climate change analysis and prediction." },
      { q: "How can I impress in a climate change interview?", a: "Showcase your skills by building a mini climate change analysis system using this dataset!" }
    ]
  },
  {
    id: "ind-7",
    name: "Gaming Behavior Analytics",
    domain: "Gaming",
    description: "Player behavior patterns, game progression data, and in-game economy metrics for game optimization and player retention.",
    size: "420MB",
    price: 116,
    addToCart: true,
    previewText: [
      { q: "What keeps players engaged in games?", a: "See how players progress, interact, and spend in games to improve engagement and retention." },
      { q: "Can I use this for a gaming app prototype?", a: "Definitely—jumpstart your gaming app with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes player behavior patterns, game progression data, and in-game economy metrics for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of gaming analytics and player retention." },
      { q: "How can I impress in a gaming interview?", a: "Showcase your skills by building a mini gaming analytics system using this dataset!" }
    ]
  },
  {
    id: "ind-8",
    name: "Renewable Energy Performance",
    domain: "Energy",
    description: "Solar and wind energy performance data, efficiency metrics, and consumption patterns for renewable energy optimization.",
    size: "560MB",
    price: 86,
    addToCart: true,
    previewText: [
      { q: "How efficient are solar and wind energy sources?", a: "Review energy outputs, efficiency rates, and usage patterns for green tech and renewable energy projects." },
      { q: "Can I use this for a renewable energy app prototype?", a: "Definitely—jumpstart your renewable energy project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes solar and wind energy performance data, efficiency metrics, and consumption patterns for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of renewable energy optimization and analysis." },
      { q: "How can I impress in a renewable energy interview?", a: "Showcase your skills by building a mini renewable energy system using this dataset!" }
    ]
  },
  {
    id: "ind-9",
    name: "Sports Performance Analytics",
    domain: "Sports",
    description: "Athlete performance metrics, game statistics, and training effectiveness data for sports analytics and prediction models.",
    size: "680MB",
    price: 104,
    addToCart: true,
    previewText: [
      { q: "Who are the top performers in sports?", a: "Dive into athlete stats, game results, and training outcomes to build sports prediction models or coaching tools." },
      { q: "Can I use this for a sports app prototype?", a: "Definitely—jumpstart your sports project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes athlete performance metrics, game statistics, and training effectiveness data for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of sports analytics and prediction." },
      { q: "How can I impress in a sports interview?", a: "Showcase your skills by building a mini sports analytics system using this dataset!" }
    ]
  },
  {
    id: "ind-10",
    name: "Restaurant Management Intelligence",
    domain: "Hospitality",
    description: "Restaurant operations data, customer preferences, and inventory management patterns for hospitality optimization.",
    size: "340MB",
    price: 59,
    addToCart: true,
    previewText: [
      { q: "How can restaurants optimize their business?", a: "Analyze sales, customer feedback, and inventory trends to improve restaurant operations and menu planning." },
      { q: "Can I use this for a restaurant app prototype?", a: "Definitely—jumpstart your restaurant project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes restaurant operations data, customer preferences, and inventory management patterns for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of restaurant management and optimization." },
      { q: "How can I impress in a restaurant interview?", a: "Showcase your skills by building a mini restaurant management system using this dataset!" }
    ]
  },
  {
    id: "ind-11",
    name: "Music Streaming Patterns",
    domain: "Entertainment",
    description: "Music listening patterns, genre preferences, and artist popularity metrics for music recommendation systems.",
    size: "490MB",
    price: 105,
    addToCart: true,
    previewText: [
      { q: "What music is trending right now?", a: "Understand what people listen to, their favorite genres, and trending artists for music recommendation and analytics." },
      { q: "Can I use this for a music app prototype?", a: "Definitely—jumpstart your music project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes music listening patterns, genre preferences, and artist popularity metrics for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of music analytics and recommendation." },
      { q: "How can I impress in a music interview?", a: "Showcase your skills by building a mini music recommendation system using this dataset!" }
    ]
  },
  {
    id: "ind-12",
    name: "Agricultural Yield Optimizer",
    domain: "Agriculture",
    description: "Crop yield data, weather patterns, and soil condition metrics for agricultural optimization and prediction.",
    size: "620MB",
    price: 84,
    addToCart: true,
    previewText: [
      { q: "How do weather and soil affect crop yields?", a: "Explore crop yields, weather effects, and soil quality data for agricultural forecasting and farm management." },
      { q: "Can I use this for an agricultural app prototype?", a: "Definitely—jumpstart your agricultural project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes crop yield data, weather patterns, and soil condition metrics for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of agricultural optimization and prediction." },
      { q: "How can I impress in an agriculture interview?", a: "Showcase your skills by building a mini farm management tool using this dataset!" }
    ]
  },
  {
    id: "ind-13",
    name: "Fashion Trend Analyzer",
    domain: "Fashion",
    description: "Fashion trend data, consumer preferences, and seasonal pattern analysis for fashion retail optimization.",
    size: "380MB",
    price: 43,
    addToCart: true,
    previewText: [
      { q: "What styles are in fashion this season?", a: "See trending styles, seasonal changes, and consumer preferences for fashion analytics and retail planning." },
      { q: "Can I use this for a fashion app prototype?", a: "Definitely—jumpstart your fashion project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes fashion trend data, consumer preferences, and seasonal pattern analysis for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of fashion analytics and retail planning." },
      { q: "How can I impress in a fashion interview?", a: "Showcase your skills by building a mini fashion trend analyzer using this dataset!" }
    ]
  },
  {
    id: "ind-14",
    name: "Mental Health Insights",
    domain: "Psychology",
    description: "Mental health patterns, treatment effectiveness, and behavioral analysis data for healthcare AI applications.",
    size: "290MB",
    price: 55,
    addToCart: true,
    previewText: [
      { q: "What are the latest trends in mental health?", a: "Review mental health trends, treatment outcomes, and behavioral data for research and wellness apps." },
      { q: "Can I use this for a mental health app prototype?", a: "Definitely—jumpstart your mental health project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes mental health patterns, treatment effectiveness, and behavioral analysis data for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of mental health analytics and wellness app development." },
      { q: "How can I impress in a psychology interview?", a: "Showcase your skills by building a mini mental health insights tool using this dataset!" }
    ]
  },
  {
    id: "ind-15",
    name: "Real Estate Market Dynamics",
    domain: "Real Estate",
    description: "Property market trends, pricing patterns, and location-based analytics for real estate prediction models.",
    size: "720MB",
    price: 90,
    addToCart: true,
    previewText: [
      { q: "Where are property prices rising fastest?", a: "Analyze property prices, market trends, and location data for real estate investment and prediction tools." },
      { q: "Can I use this for a real estate app prototype?", a: "Definitely—jumpstart your real estate project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes property market trends, pricing patterns, and location-based analytics for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of real estate analytics and investment." },
      { q: "How can I impress in a real estate interview?", a: "Showcase your skills by building a mini real estate market analyzer using this dataset!" }
    ]
  },
  {
    id: "ind-16",
    name: "Cryptocurrency Trading Patterns",
    domain: "Crypto",
    description: "Cryptocurrency price movements, trading patterns, and market sentiment data for crypto trading models.",
    size: "890MB",
    price: 139,
    addToCart: true,
    previewText: [
      { q: "How do crypto prices and trading volumes change?", a: "Track crypto prices, trading volumes, and market sentiment for building trading bots and analytics dashboards." },
      { q: "Can I use this for a crypto app prototype?", a: "Definitely—jumpstart your crypto project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes cryptocurrency price movements, trading patterns, and market sentiment data for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of crypto analytics and trading bot development." },
      { q: "How can I impress in a crypto interview?", a: "Showcase your skills by building a mini crypto trading pattern analyzer using this dataset!" }
    ]
  },
  {
    id: "ind-17",
    name: "Social Media Engagement Analytics",
    domain: "Social Media",
    description: "Social media engagement metrics, content performance, and user behavior patterns for social media optimization.",
    size: "580MB",
    price: 73,
    addToCart: true,
    previewText: [
      { q: "What content gets the most engagement online?", a: "See how users interact with posts, what content performs best, and engagement trends for social media managers and marketers." },
      { q: "Can I use this for a social media app prototype?", a: "Definitely—jumpstart your social media project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes social media engagement metrics, content performance, and user behavior patterns for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of social media analytics and optimization." },
      { q: "How can I impress in a social media interview?", a: "Showcase your skills by building a mini social media engagement analyzer using this dataset!" }
    ]
  },
  {
    id: "ind-18",
    name: "Travel Booking Intelligence",
    domain: "Travel",
    description: "Travel booking patterns, destination popularity, and seasonal trends for travel industry optimization.",
    size: "450MB",
    price: 129,
    addToCart: true,
    previewText: [
      { q: "Where do people love to travel?", a: "Explore booking trends, popular destinations, and seasonal travel data for travel agencies and tourism analytics." },
      { q: "Can I use this for a travel app prototype?", a: "Definitely—jumpstart your travel project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes travel booking patterns, destination popularity, and seasonal trends for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of travel analytics and tourism planning." },
      { q: "How can I impress in a travel interview?", a: "Showcase your skills by building a mini travel booking intelligence tool using this dataset!" }
    ]
  },
  {
    id: "ind-19",
    name: "Education Platform Analytics",
    domain: "Education",
    description: "Student learning patterns, course engagement metrics, and educational outcome data for e-learning optimization.",
    size: "520MB",
    price: 61,
    addToCart: true,
    previewText: [
      { q: "How do students engage with online courses?", a: "Analyze student progress, course engagement, and learning outcomes to improve e-learning platforms and education research." },
      { q: "Can I use this for an education app prototype?", a: "Definitely—jumpstart your education project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes student learning patterns, course engagement metrics, and educational outcome data for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of education analytics and e-learning optimization." },
      { q: "How can I impress in an education interview?", a: "Showcase your skills by building a mini education platform analytics tool using this dataset!" }
    ]
  },
  {
    id: "ind-20",
    name: "Fitness Training Optimizer",
    domain: "Fitness",
    description: "Workout effectiveness data, fitness progress patterns, and nutrition impact metrics for fitness applications.",
    size: "410MB",
    price: 113,
    addToCart: true,
    previewText: [
      { q: "What workouts deliver the best results?", a: "Track workout results, fitness progress, and nutrition effects for fitness app developers and trainers." },
      { q: "Can I use this for a fitness app prototype?", a: "Definitely—jumpstart your fitness project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes workout effectiveness data, fitness progress patterns, and nutrition impact metrics for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of fitness analytics and training optimization." },
      { q: "How can I impress in a fitness interview?", a: "Showcase your skills by building a mini fitness training optimizer using this dataset!" }
    ]
  },
  {
    id: "ind-21",
    name: "Insurance Risk Analyzer",
    domain: "Insurance",
    description: "Insurance claim patterns, risk assessment metrics, and fraud detection data for insurance AI models.",
    size: "640MB",
    price: 92,
    addToCart: true,
    previewText: [
      { q: "How do insurers assess risk and detect fraud?", a: "Review insurance claims, risk scores, and fraud detection data for analytics and risk management." },
      { q: "Can I use this for an insurance app prototype?", a: "Definitely—jumpstart your insurance project with real-world data." },
      { q: "What makes this dataset unique?", a: "It includes insurance claim patterns, risk assessment metrics, and fraud detection data for comprehensive analysis." },
      { q: "Is this data suitable for beginners?", a: "Absolutely—it's perfect for learning the basics of insurance analytics and risk management." },
      { q: "How can I impress in an insurance interview?", a: "Showcase your skills by building a mini insurance risk analyzer using this dataset!" }
    ]
  },
  {
    id: "ind-22",
    name: "FINANCE",
    domain: "Finance",
    description: "A curated 50MB Q/A dataset covering fundamental financial concepts. Perfect for training finance chatbots.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "What is a Systematic Investment Plan (SIP)?", a: "An SIP is a method of investing a fixed sum regularly in mutual funds. This dataset provides Q&As on how they work." },
      { q: "How does cryptocurrency mining work?", a: "Explore Q&As on the basics of blockchain, proof-of-work, and how new coins are created." },
      { q: "What are the risks of options trading?", a: "Learn about market volatility, time decay, and other factors from our curated Q&A pairs." },
      { q: "Can this data explain stock valuation?", a: "Yes, it includes Q&As on P/E ratios, DCF models, and other key valuation methods." },
      { q: "Ready to build a finance bot?", a: "Add to cart to get instant access to hundreds of financial Q&As!" }
    ]
  },
  {
    id: "ind-23",
    name: "HEALTHCARE",
    domain: "Healthcare",
    description: "A curated 50MB Q/A dataset on common healthcare and medical topics. Perfect for training medical assistant bots.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "What are common symptoms of diabetes?", a: "This dataset includes Q&As on symptoms, diagnosis, and management of chronic conditions like diabetes." },
      { q: "How do vaccines stimulate the immune system?", a: "Explore curated answers on vaccine mechanisms, types, and their role in public health." },
      { q: "What is the difference between an MRI and a CT scan?", a: "Get clear answers to common questions about medical imaging techniques." },
      { q: "Can this data help with mental health queries?", a: "Yes, it covers basic Q&As on topics like anxiety, depression, and when to seek help." },
      { q: "Build a smarter health assistant!", a: "Add to cart to access a rich database of medical Q&As!" }
    ]
  },
  {
    id: "ind-24",
    name: "AGRICULTURE",
    domain: "Agriculture",
    description: "A curated 50MB Q/A dataset on modern agricultural practices and science. Perfect for AgriTech applications.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "What is precision agriculture?", a: "Learn how technology like GPS and drones are used to optimize crop yields through our detailed Q&As." },
      { q: "How does crop rotation benefit soil health?", a: "This dataset contains Q&As on sustainable farming practices that improve soil fertility." },
      { q: "What are the best methods for pest control?", a: "Explore integrated pest management techniques with our curated question-answer pairs." },
      { q: "Can this data help with irrigation questions?", a: "Yes, find answers on efficient water usage, drip irrigation, and soil moisture." },
      { q: "Grow your AgriTech knowledge!", a: "Add to cart to get instant access to essential farming Q&As!" }
    ]
  },
  {
    id: "ind-25",
    name: "RETAIL",
    domain: "Retail",
    description: "A curated 50MB Q/A dataset covering e-commerce, customer behavior, and retail trends. Excellent for support bots.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "What is the average cart abandonment rate?", a: "Get answers to key e-commerce metrics and learn the strategies to reduce cart abandonment." },
      { q: "How do you calculate customer lifetime value (CLV)?", a: "This dataset has Q&As that break down important retail formulas and their applications." },
      { q: "What are the latest trends in omnichannel retail?", a: "Explore Q&As about integrating online and offline shopping experiences." },
      { q: "Can I find questions about inventory management?", a: "Yes, learn about Just-In-Time (JIT), FIFO, and other inventory systems." },
      { q: "Build a better retail bot!", a: "Add to cart to power your customer service with expert knowledge!" }
    ]
  },
  {
    id: "ind-26",
    name: "TECHNOLOGY",
    domain: "Technology",
    description: "A curated 50MB Q/A dataset on emerging technologies, from AI to blockchain. Great for tech explainers.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "What is the difference between AI and Machine Learning?", a: "This dataset provides clear Q&As to demystify complex tech concepts." },
      { q: "How does a blockchain ensure security?", a: "Explore the principles of decentralization, cryptography, and consensus mechanisms." },
      { q: "What is Quantum Computing?", a: "Get simple explanations for mind-bending topics in the tech world." },
      { q: "Can this explain APIs and SDKs?", a: "Yes, find Q&As that cover the fundamental building blocks of software development." },
      { q: "Become a tech guru!", a: "Add to cart and start building your tech knowledge base bot!" }
    ]
  },
  {
    id: "ind-27",
    name: "AUTOMOTIVE",
    domain: "Automotive",
    description: "A curated 50MB Q/A dataset about electric vehicles, autonomous driving, and car manufacturing. Ideal for infotainment systems.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "How do Electric Vehicle (EV) batteries work?", a: "Discover the science behind lithium-ion batteries, charging cycles, and range." },
      { q: "What are the different levels of autonomous driving?", a: "This dataset explains the SAE levels from 0 (no automation) to 5 (full automation)." },
      { q: "What is torque vectoring in a car?", a: "Learn about advanced automotive technologies that improve vehicle handling and safety." },
      { q: "Can I find info on car manufacturing processes?", a: "Yes, explore Q&As on the assembly line, robotics in factories, and quality control." },
      { q: "Drive your automotive project forward!", a: "Add to cart for instant access to automotive Q&As!" }
    ]
  },
  {
    id: "ind-28",
    name: "EDUCATION",
    domain: "Education",
    description: "A curated 50MB Q/A dataset on e-learning, pedagogy, and educational technologies. Perfect for student helper bots.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "What is gamification in learning?", a: "This dataset includes Q&As on how game mechanics can be used to increase student engagement." },
      { q: "How does adaptive learning technology work?", a: "Explore Q&As on AI-powered systems that tailor educational content to individual student needs." },
      { q: "What is project-based learning (PBL)?", a: "Learn about teaching methods that involve students in complex, real-world projects." },
      { q: "Can this help me understand different learning theories?", a: "Yes, find Q&As on constructivism, behaviorism, and cognitivism." },
      { q: "Build the future of EdTech!", a: "Add to cart to create a smarter learning assistant!" }
    ]
  },
  {
    id: "ind-29",
    name: "ENERGY",
    domain: "Energy",
    description: "A curated 50MB Q/A dataset covering renewable energy, power grids, and consumption patterns. Great for energy apps.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "How does a solar panel generate electricity?", a: "Our Q&As explain the photovoltaic effect and how solar energy is converted into power." },
      { q: "What is a smart grid?", a: "Learn how modern technology is used to make electricity distribution more efficient and reliable." },
      { q: "What is the difference between renewable and clean energy?", a: "This dataset clarifies important terminology in the energy sector." },
      { q: "Can I find info on energy storage solutions?", a: "Yes, explore Q&As about batteries, pumped hydro, and other storage technologies." },
      { q: "Power your next project!", a: "Add to cart for curated Q&As on the energy industry!" }
    ]
  },
  {
    id: "ind-30",
    name: "ENVIRONMENTAL",
    domain: "Environmental",
    description: "A curated 50MB Q/A dataset on climate change, conservation, and sustainability. Perfect for educational tools.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "What is the greenhouse effect?", a: "This dataset provides clear Q&As on the core science behind climate change." },
      { q: "How does deforestation impact biodiversity?", a: "Explore the connections between habitats and species diversity with our curated content." },
      { q: "What is a carbon footprint and how can I reduce it?", a: "Find actionable answers on how to promote sustainability in daily life." },
      { q: "Can this explain the Paris Agreement?", a: "Yes, get simplified explanations of major international environmental policies." },
      { q: "Build an app that makes a difference!", a: "Add to cart to access vital environmental Q&As!" }
    ]
  },
  {
    id: "ind-31",
    name: "REAL ESTATE",
    domain: "Real Estate",
    description: "A curated 50MB Q/A dataset covering property markets, investment, and housing trends. Ideal for agent assistant bots.",
    size: "50MB",
    price: 7,
    tag: "Offer",
    addToCart: true,
    previewText: [
      { q: "What is a buyer's market vs. a seller's market?", a: "This dataset has Q&As to help users understand real estate market dynamics." },
      { q: "How is property value assessed?", a: "Explore Q&As on comparable sales (comps), appraisals, and other valuation methods." },
      { q: "What is a 1031 exchange in real estate?", a: "Learn about advanced real estate investment strategies through our curated answers." },
      { q: "Can this explain different types of mortgages?", a: "Yes, find clear explanations of fixed-rate, ARM, FHA, and other loan types." },
      { q: "Unlock the door to real estate AI!", a: "Add to cart for essential Q&As for your real estate app!" }
    ]
  }
]; 