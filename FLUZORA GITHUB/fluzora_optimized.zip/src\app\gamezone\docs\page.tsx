"use client";
import React from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { FaBook, FaArrowLeft } from "react-icons/fa";

export default function DocsPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg flex items-center justify-center gap-2"><FaBook /> Docs</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">Read the GameZone rules, terms, and contribution policy. Stay informed and play fair!</p>
        <Link href="/gamezone" className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/30 border border-blue-400 text-blue-300 font-inter hover:bg-blue-900/30 transition-all mt-4"><FaArrowLeft /> Back to GameZone</Link>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="glassmorphic p-8 rounded-2xl shadow-lg flex flex-col gap-6 border border-blue-400 max-w-3xl mx-auto"
      >
        <div className="font-orbitron text-xl text-neon mb-1">GameZone Terms & Rules (Mock)</div>
        <ul className="font-inter text-white/80 text-left list-disc list-inside space-y-2">
          <li>Only upload datasets you have the rights to share.</li>
          <li>No personal or sensitive data allowed.</li>
          <li>Quality and metadata increase FLZ rewards.</li>
          <li>Voting and referrals earn bonus FLZ.</li>
          <li>Abuse or spam will result in a ban.</li>
        </ul>
        <div className="font-inter text-purple-200 text-sm">For full terms, contact support@fluzora.com</div>
      </motion.div>
    </main>
  );
} 