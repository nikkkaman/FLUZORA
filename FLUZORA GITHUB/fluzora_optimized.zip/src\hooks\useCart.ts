import { useState } from 'react';
import { Dataset } from './useDatasets';

export function useCart(initialDatasets: Dataset[]) {
  const [cart, setCart] = useState<string[]>([]);
  const [cartOpen, setCartOpen] = useState(false);

  const handleAddToCart = (id: string) => {
    if (cart.includes(id)) {
      setCart(cart.filter((itemId) => itemId !== id));
    } else {
      setCart([...cart, id]);
    }
  };

  const handleRemoveFromCart = (id: string) => {
    setCart(cart.filter((itemId) => itemId !== id));
  };

  const cartDatasets = initialDatasets.filter((d) => cart.includes(d.id));
  const totalPrice = cartDatasets.reduce((sum, d) => sum + (d.price || 0), 0);

  return {
    cart,
    cartOpen,
    setCartOpen,
    handleAddToCart,
    handleRemoveFromCart,
    cartDatasets,
    totalPrice,
  };
} 