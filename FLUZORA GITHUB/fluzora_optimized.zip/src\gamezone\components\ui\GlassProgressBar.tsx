import React from 'react';

export default function GlassProgressBar({ value, label, className = '' }: { value: number; label?: string; className?: string }) {
  return (
    <div className={`w-full glassmorphic p-2 rounded-lg ${className}`} aria-label={label || 'Progress'}>
      {label && <div className="font-orbitron text-neon mb-1">{label}</div>}
      <div className="w-full h-4 bg-black/40 rounded-full overflow-hidden">
        <div className="h-4 bg-neon rounded-full transition-all" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
} 