"use client";
import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function BillingPage() {
  const router = useRouter();
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [loading, setLoading] = useState(true);

  const handleUpdatePlan = () => setShowPlanModal(true);
  const handleUpdatePayment = () => setShowPaymentModal(true);
  const handleShowInvoices = () => setShowInvoiceModal(true);
  const handleClosePlanModal = () => setShowPlanModal(false);
  const handleClosePaymentModal = () => setShowPaymentModal(false);
  const handleCloseInvoiceModal = () => setShowInvoiceModal(false);

  // Dummy data
  const plan = "Ultimate (Annual)";
  const planDetails = "Unlimited datasets, priority support, annual billing.";
  const payment = "Visa ending in 4242";
  const nextPayment = "2025-06-01";
  const billingHistory = [
    { date: "2024-06-01", amount: "$99.00", status: "Paid", invoice: "#INV-20240601" },
    { date: "2023-06-01", amount: "$99.00", status: "Paid", invoice: "#INV-20230601" },
  ];

  useEffect(() => {
    setLoading(true);
    const timeout = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timeout);
  }, []);

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-900 p-8 flex flex-col items-center">
      <button
        onClick={() => router.back()}
        className="absolute left-8 top-8 flex items-center gap-2 px-3 py-2 rounded-full bg-transparent border border-white/30 hover:bg-white/10 hover:border-white/80 text-white transition shadow"
        style={{ zIndex: 10 }}
        aria-label="Back"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="hidden md:inline">Back</span>
      </button>
      <div className="w-full max-w-3xl bg-gray-800/80 rounded-xl p-8 shadow-xl">
        <h1 className="text-3xl font-bold text-white mb-8">Billing</h1>
        {loading ? (
          <>
            <div className="flex flex-col md:flex-row gap-6 mb-8">
              <Skeleton className="h-40 w-full md:w-1/2" />
              <Skeleton className="h-40 w-full md:w-1/2" />
            </div>
            <Skeleton className="h-32 w-full mb-4" />
          </>
        ) : (
        <>
        {/* Summary Card */}
        <div className="flex flex-col md:flex-row gap-6 mb-8">
          <div className="flex-1 bg-gradient-to-r from-purple-700 to-purple-500 rounded-xl p-6 flex flex-col justify-center shadow-lg">
            <div className="text-lg text-white font-semibold mb-1">Current Plan</div>
            <div className="text-2xl font-bold text-white mb-2">{plan}</div>
            <div className="text-purple-100 text-sm mb-2">{planDetails}</div>
            <div className="text-xs text-purple-200 mb-2">Next payment: <span className="font-bold">{nextPayment}</span></div>
            <div className="flex gap-2 mt-2">
              <button className="px-4 py-2 rounded bg-purple-600 text-white hover:bg-purple-700 font-semibold shadow" onClick={handleUpdatePlan}>Change Plan</button>
            </div>
          </div>
          <div className="flex-1 bg-gradient-to-r from-blue-600 to-green-500 rounded-xl p-6 flex flex-col justify-center shadow-lg">
            <div className="text-lg text-white font-semibold mb-1">Payment Method</div>
            <div className="text-xl font-bold text-white mb-2">{payment}</div>
            <button className="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 font-semibold shadow" onClick={handleUpdatePayment}>Update Card</button>
          </div>
        </div>
        {/* Billing History */}
        <section>
          <h2 className="text-xl font-bold text-purple-300 mb-2">Billing History</h2>
          <div className="bg-black/30 rounded-lg p-4 text-white/90">
            <table className="w-full text-left">
              <thead>
                <tr className="text-purple-300">
                  <th className="py-2">Date</th>
                  <th className="py-2">Amount</th>
                  <th className="py-2">Status</th>
                  <th className="py-2">Invoice</th>
                </tr>
              </thead>
              <tbody>
                {billingHistory.map((row, idx) => (
                  <tr key={idx}>
                    <td className="py-2">{row.date}</td>
                    <td className="py-2">{row.amount}</td>
                    <td className="py-2 text-green-400">{row.status}</td>
                    <td className="py-2">
                      <button className="underline text-blue-400 hover:text-blue-600" onClick={handleShowInvoices}>Download</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        </>) }
      </div>
      {/* Plan Modal */}
      {showPlanModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full shadow-lg flex flex-col items-center">
            <h3 className="text-2xl font-bold mb-4 text-purple-700">Change Plan</h3>
            <p className="mb-6 text-gray-700">Plan upgrade/downgrade coming soon.</p>
            <button className="px-6 py-2 rounded bg-purple-600 text-white hover:bg-purple-700 font-semibold shadow" onClick={handleClosePlanModal}>Close</button>
          </div>
        </div>
      )}
      {/* Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full shadow-lg flex flex-col items-center">
            <h3 className="text-2xl font-bold mb-4 text-blue-700">Update Payment Method</h3>
            <p className="mb-6 text-gray-700">Payment update coming soon.</p>
            <button className="px-6 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 font-semibold shadow" onClick={handleClosePaymentModal}>Close</button>
          </div>
        </div>
      )}
      {/* Invoice Modal */}
      {showInvoiceModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full shadow-lg flex flex-col items-center">
            <h3 className="text-2xl font-bold mb-4 text-green-700">Download Invoice</h3>
            <p className="mb-6 text-gray-700">Invoice download coming soon.</p>
            <button className="px-6 py-2 rounded bg-green-600 text-white hover:bg-green-700 font-semibold shadow" onClick={handleCloseInvoiceModal}>Close</button>
          </div>
        </div>
      )}
    </main>
  );
} 