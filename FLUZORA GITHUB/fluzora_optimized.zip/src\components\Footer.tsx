"use client";

import React from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { 
  Database, 
  Brain, 
  BookOpen, 
  Shield, 
  Users, 
  Gamepad2, 
  Mail 
} from "lucide-react";
import { usePathname } from "next/navigation";

const footerLinks = [
  {
    title: "Product",
    links: [
      { name: "Datasets", href: "/datasets", icon: Database },
      { name: "AI Demo", href: "/ai-demo", icon: Brain },
      { name: "Documentation", href: "#", icon: BookOpen },
      { name: "Game Zone", href: "#", icon: Gamepad2, soon: true }
    ]
  },
  {
    title: "Company",
    links: [
      { name: "About", href: "/about", icon: Users },
      { name: "Security", href: "#", icon: Shield },
      { name: "Contact", href: "#", icon: Mail }
    ]
  }
];

export default function Footer() {
  const pathname = usePathname();
  // Only show footer on /home, /datasets, /learn-agents
  if (!['/home', '/datasets', '/learn-agents'].includes(pathname)) return null;

  return (
    <footer className="bg-black/80 border-t border-purple-500/30 py-10 px-4 backdrop-blur-xl">
      <div className="container mx-auto max-w-7xl flex flex-col md:flex-row md:items-start md:justify-between gap-10 md:gap-0">
        {/* Left: Logo & Company Info */}
        <div className="flex flex-col gap-3 md:w-1/3">
          <div className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 font-orbitron tracking-wide select-none">FLUZORA</div>
          <div className="text-gray-400 text-sm font-inter max-w-xs">Powering the next generation of AI with premium, curated datasets. Secure. Scalable. Community-driven.</div>
          <div className="flex gap-3 mt-2">
            <a href="https://twitter.com/fluzora" target="_blank" rel="noopener" aria-label="Twitter" className="hover:text-blue-400 text-gray-400 transition-colors"><svg width="22" height="22" fill="currentColor" viewBox="0 0 24 24"><path d="M22.46 5.924c-.793.352-1.646.59-2.542.698a4.48 4.48 0 0 0 1.963-2.475 8.94 8.94 0 0 1-2.828 1.082A4.48 4.48 0 0 0 16.11 4c-2.48 0-4.49 2.01-4.49 4.49 0 .352.04.695.116 1.022C7.728 9.36 4.1 7.6 1.67 4.905c-.387.664-.61 1.437-.61 2.26 0 1.56.795 2.936 2.006 3.744a4.48 4.48 0 0 1-2.034-.563v.057c0 2.18 1.55 4.002 3.604 4.418-.377.103-.775.158-1.186.158-.29 0-.57-.028-.844-.08.57 1.78 2.23 3.08 4.2 3.12A8.98 8.98 0 0 1 2 19.54a12.7 12.7 0 0 0 6.88 2.02c8.26 0 12.78-6.84 12.78-12.78 0-.195-.004-.39-.013-.583A9.1 9.1 0 0 0 24 4.59a8.98 8.98 0 0 1-2.54.697z"/></svg></a>
            <a href="https://linkedin.com/company/fluzora" target="_blank" rel="noopener" aria-label="LinkedIn" className="hover:text-blue-400 text-gray-400 transition-colors"><svg width="22" height="22" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.76 0-5 2.24-5 5v14c0 2.76 2.24 5 5 5h14c2.76 0 5-2.24 5-5v-14c0-2.76-2.24-5-5-5zm-11 19h-3v-9h3v9zm-1.5-10.28c-.97 0-1.75-.79-1.75-1.75s.78-1.75 1.75-1.75 1.75.79 1.75 1.75-.78 1.75-1.75 1.75zm15.5 10.28h-3v-4.5c0-1.08-.02-2.47-1.5-2.47-1.5 0-1.73 1.17-1.73 2.39v4.58h-3v-9h2.88v1.23h.04c.4-.75 1.38-1.54 2.84-1.54 3.04 0 3.6 2 3.6 4.59v4.72z"/></svg></a>
            <a href="mailto:support@fluzora.com" aria-label="Email" className="hover:text-pink-400 text-gray-400 transition-colors"><Mail className="w-5 h-5" /></a>
          </div>
        </div>
        {/* Center: Product & Company Links */}
        <div className="flex flex-col sm:flex-row gap-8 md:gap-16 md:w-1/3 justify-center mt-8 md:mt-0">
          <div>
            <div className="text-lg font-bold text-purple-300 mb-3 font-orbitron">Product</div>
            <ul className="space-y-2">
              <li><Link href="/datasets" className="flex items-center gap-2 text-gray-300 hover:text-purple-400 transition-colors text-sm"><Database className="w-4 h-4" /> Datasets</Link></li>
              <li><Link href="/ai-demo" className="flex items-center gap-2 text-gray-300 hover:text-purple-400 transition-colors text-sm"><Brain className="w-4 h-4" /> AI Demo</Link></li>
              <li><Link href="/gamezone/home" className="flex items-center gap-2 text-gray-300 hover:text-purple-400 transition-colors text-sm"><Gamepad2 className="w-4 h-4" /> GameZone</Link></li>
              <li><Link href="/docs" className="flex items-center gap-2 text-gray-300 hover:text-purple-400 transition-colors text-sm"><BookOpen className="w-4 h-4" /> Documentation</Link></li>
            </ul>
          </div>
          <div>
            <div className="text-lg font-bold text-purple-300 mb-3 font-orbitron">Company</div>
            <ul className="space-y-2">
              <li><Link href="/about" className="flex items-center gap-2 text-gray-300 hover:text-purple-400 transition-colors text-sm"><Users className="w-4 h-4" /> About</Link></li>
              <li><Link href="/security" className="flex items-center gap-2 text-gray-300 hover:text-purple-400 transition-colors text-sm"><Shield className="w-4 h-4" /> Security</Link></li>
              <li><Link href="/contact" className="flex items-center gap-2 text-gray-300 hover:text-purple-400 transition-colors text-sm"><Mail className="w-4 h-4" /> Contact</Link></li>
            </ul>
          </div>
        </div>
        {/* Right: Newsletter */}
        <div className="flex flex-col gap-4 md:w-1/3 max-w-xs">
          <div className="text-lg font-bold text-purple-300 mb-1 font-orbitron">Stay in the Loop</div>
          <div className="text-gray-400 text-sm mb-2">Get updates on new datasets, features, and events. No spam, ever.</div>
          <form className="flex flex-col gap-2">
            <input
              type="email"
              placeholder="Your email address"
              className="bg-gray-900/80 border border-purple-500/30 rounded-lg px-3 py-2 text-gray-100 focus:outline-none focus:border-purple-500 text-sm"
            />
            <button type="submit" className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg font-semibold text-sm hover:from-pink-600 hover:to-purple-600 transition-all">Subscribe</button>
          </form>
        </div>
      </div>
      <div className="border-t border-purple-900/40 mt-10 pt-6 text-center text-xs text-gray-500 font-inter">
        &copy; {new Date().getFullYear()} FLUZORA Technologies Pvt. Ltd. All rights reserved. | Made with <span className="text-pink-400">♥</span> for the AI community.
      </div>
    </footer>
  );
}
