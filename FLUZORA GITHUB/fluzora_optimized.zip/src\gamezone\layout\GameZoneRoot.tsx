import React from 'react';
import { GameZoneProvider } from '../context/GameZoneContext';

export default function GameZoneRoot({ children }: { children: React.ReactNode }) {
  return <GameZoneProvider>{children}</GameZoneProvider>;
} 