import React from 'react';
import { motion } from 'framer-motion';
import { Database, Lock, Star } from 'lucide-react';

const tabs = [
  { id: 'individual', name: 'Individual Data', icon: Database },
  { id: 'subscription', name: 'Subscription Data', icon: Star },
  { id: 'premium', name: 'Premium Vault', icon: Lock },
];

type DatasetTabsProps = {
  activeTab: string;
  setActiveTab: (id: string) => void;
};

export function DatasetTabs({ activeTab, setActiveTab }: DatasetTabsProps) {
  return (
    <div className="flex flex-wrap justify-center gap-4 mb-12">
      {tabs.map((tab) => (
        <motion.button
          key={tab.id}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setActiveTab(tab.id)}
          className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
            activeTab === tab.id
              ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/20'
              : 'bg-purple-900/20 text-gray-300 hover:bg-purple-900/30'
          }`}
        >
          <tab.icon className="w-4 h-4" />
          {tab.name}
        </motion.button>
      ))}
    </div>
  );
} 