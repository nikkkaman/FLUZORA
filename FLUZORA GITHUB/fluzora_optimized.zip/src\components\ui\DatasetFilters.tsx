import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search } from 'lucide-react';
import Fuse from 'fuse.js';
import { Dataset } from '@/hooks/useDatasets';
import { Input } from './input';

interface DatasetFiltersProps {
  datasets: Dataset[];
  onSearch: (query: string) => void;
  onSuggestionClick: (suggestion: string) => void;
  value: string;
  setValue: (v: string) => void;
}

export const DatasetFilters: React.FC<DatasetFiltersProps> = ({
  datasets,
  onSearch,
  onSuggestionClick,
  value,
  setValue,
}) => {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const fuse = new Fuse(datasets, {
    keys: ['name', 'tags', 'domain', 'description'],
    threshold: 0.35, // typo tolerance
    ignoreLocation: true,
    minMatchCharLength: 2,
  });

  // Debounce input
  useEffect(() => {
    const handler = setTimeout(() => {
      if (value.trim().length > 0) {
        const results = fuse.search(value.trim());
        setSuggestions(results.slice(0, 6).map(r => r.item.name));
      } else {
        setSuggestions([]);
      }
    }, 180);
    return () => clearTimeout(handler);
  }, [value, datasets]);

  // Handle Enter key
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSearch(value);
      setSuggestions([]);
    }
    if (e.key === 'ArrowDown' && suggestions.length > 0) {
      e.preventDefault();
      inputRef.current?.blur();
    }
  };

  // Handle suggestion click
  const handleSuggestionClick = (suggestion: string) => {
    setValue(suggestion);
    onSuggestionClick(suggestion);
    setSuggestions([]);
  };

  return (
    <div className="w-full max-w-3xl mx-auto mb-8 relative">
      <div className="relative">
        <Input
          ref={inputRef}
          type="text"
          value={value}
          onChange={e => setValue(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 120)}
          onKeyDown={handleKeyDown}
          placeholder="Search datasets by name, tag, or keyword…"
          className={`w-full pl-12 pr-4 py-3 text-lg rounded-xl bg-black/80 border border-purple-700 focus:border-pink-500 focus:ring-2 focus:ring-pink-500/40 text-white placeholder-gray-400 shadow-lg transition-all duration-200 ${isFocused ? 'ring-2 ring-pink-500/40 shadow-pink-500/20' : ''}`}
          autoComplete="off"
        />
        <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 ${isFocused ? 'text-pink-400 drop-shadow-glow' : 'text-purple-300'}`} />
      </div>
      <AnimatePresence>
        {isFocused && suggestions.length > 0 && (
          <motion.ul
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 8 }}
            className="absolute z-30 w-full bg-black/95 border border-purple-800 rounded-xl mt-2 shadow-xl overflow-hidden"
          >
            {suggestions.map((s, i) => (
              <li
                key={s}
                className="px-5 py-3 text-white hover:bg-purple-900/60 cursor-pointer text-base border-b border-purple-900 last:border-b-0 transition-colors"
                onMouseDown={() => handleSuggestionClick(s)}
              >
                {s}
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  );
}; 