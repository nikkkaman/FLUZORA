import React from 'react';
import GameZoneLayout from '../layout/GameZoneLayout';
import { useGameZoneContext } from '../context/GameZoneContext';

function exportCSV(billing: any[]) {
  const header = 'Date,Type,Amount,Description\n';
  const rows = billing.map(b => `${b.date},${b.type},${b.amount},${b.desc}`).join('\n');
  const csv = header + rows;
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'billing.csv';
  a.click();
  URL.revokeObjectURL(url);
}

export default function GameZoneBilling() {
  const { billing } = useGameZoneContext();
  return (
    <GameZoneLayout>
      <div className="mb-6">
        <a href="/gamezone" className="inline-block px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform">Back</a>
      </div>
      <h1 className="text-3xl font-orbitron text-neon mb-8">Billing Logs</h1>
      <div className="mb-4 flex items-center gap-4">
        <button className="px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform" onClick={() => exportCSV(billing)}>Export as CSV</button>
        <span className="text-white/60 font-inter">Token trend graph coming soon...</span>
      </div>
      <div className="glassmorphic p-6 rounded-2xl shadow-lg overflow-x-auto">
        <table className="min-w-full text-left">
          <thead>
            <tr className="text-neon font-orbitron text-lg">
              <th className="py-2">Date</th>
              <th className="py-2">Type</th>
              <th className="py-2">Amount</th>
              <th className="py-2">Description</th>
            </tr>
          </thead>
          <tbody>
            {billing.map((b: any) => (
              <tr key={b.id} className="border-b border-white/10 hover:bg-neon/5 transition-all">
                <td className="py-2 text-white/80">{b.date}</td>
                <td className="py-2 text-neon font-bold font-orbitron">{b.type}</td>
                <td className="py-2 text-white/90">{b.amount}</td>
                <td className="py-2 text-white/80">{b.desc}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </GameZoneLayout>
  );
} 