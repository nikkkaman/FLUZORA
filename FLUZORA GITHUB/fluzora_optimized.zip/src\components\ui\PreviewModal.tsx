"use client";

import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "./dialog";
import { Button } from "./button";
import { Table } from "./table";
import { Copy, X } from "lucide-react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import { Dataset } from "@/hooks/useDatasets";

type PreviewModalProps = {
  isOpen: boolean;
  onClose: () => void;
  dataset: Dataset;
};

// Function to generate mock data based on domain
const generateMockData = (dataset: Dataset) => {
    // ... implementation from my plan
    const data: any[] = [];
    const numRows = 5;

    let headers: string[] = ['id'];

    if ((dataset.domain?.toLowerCase() || '').includes('finance')) {
        headers.push('date', 'stock_symbol', 'price_usd', 'volume');
    } else if ((dataset.domain?.toLowerCase() || '').includes('health')) {
        headers.push('patient_id', 'metric', 'value', 'timestamp');
    } else if ((dataset.domain?.toLowerCase() || '').includes('retail')) {
        headers.push('order_id', 'product_sku', 'quantity', 'price');
    } else {
        headers.push('feature_1', 'feature_2', 'feature_3', 'label');
    }

    for (let i = 1; i <= numRows; i++) {
        const row: any = { id: i };
        headers.slice(1).forEach(header => {
            if (header.includes('date')) row[header] = new Date(Date.now() - Math.random() * 1e12).toISOString().split('T')[0];
            else if (header.includes('price')) row[header] = (Math.random() * 1000).toFixed(2);
            else if (header.includes('quantity') || header.includes('volume')) row[header] = Math.floor(Math.random() * 1000);
            else if (header.includes('id')) row[header] = `USR-${Math.random().toString(36).substr(2, 9)}`;
            else row[header] = `${header.split('_')[0]}_${Math.random().toString(36).substr(2, 5)}`;
        });
        data.push(row);
    }
    return data;
};

const generateAIPrompt = (dataset: Dataset) => {
    if (dataset.aiPrompt) {
        return dataset.aiPrompt;
    }
    
    const { domain, name } = dataset;
    if ((domain?.toLowerCase() || '').includes('finance')) {
        return `Analyze the financial dataset "${name}" to identify key market trends, predict stock performance, and develop algorithmic trading strategies.`;
    } else if ((domain?.toLowerCase() || '').includes('health')) {
        return `Use the healthcare dataset "${name}" to build a diagnostic model, predict patient outcomes, and optimize treatment plans based on symptoms and medical history.`;
    } else if ((domain?.toLowerCase() || '').includes('retail')) {
        return `Leverage the e-commerce dataset "${name}" to create a personalized recommendation engine, forecast sales, and analyze customer purchasing behavior.`;
    } else {
        return `Utilize the "${name}" dataset to train a machine learning model for classification, regression, or clustering tasks based on its features.`;
    }
};

export function PreviewModal({
  isOpen,
  onClose,
  dataset,
}: PreviewModalProps) {
  if (!isOpen) {
    return null;
  }

  const mockData = generateMockData(dataset);
  const aiPrompt = generateAIPrompt(dataset);

  // Razorpay payment handler for TEST DATA
  const handleBuyClick = async () => {
    try {
      const options = {
        key: "rzp_test_YourKey", // Replace with your Razorpay test key
        amount: 700, // ₹7 in paise
        currency: "INR",
        name: "FLUZORA",
        description: "Purchase TEST DATA dataset",
        handler: async function (response: any) {
          const webhookRes = await fetch("https://n8n.YOURDOMAIN.com/webhook/fluzora-unlock", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              email: "test@demo.com", // Replace with dynamic user input
              datasetKey: "TEST_DATA.json",
            }),
          });

          const data = await webhookRes.json();

          if (data.downloadUrl) {
            window.location.href = data.downloadUrl;
          } else {
            alert("Payment successful. Check your email for the dataset link.");
          }
        },
        prefill: {
          name: "Demo User",
          email: "test@demo.com", // dynamic
        },
        theme: {
          color: "#3399cc"
        }
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    } catch (err) {
      console.error("Payment failed:", err);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50"
    >
      <div className="bg-gray-900/80 border border-purple-700/50 rounded-2xl shadow-2xl shadow-purple-500/10 p-6 w-full max-w-4xl max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center mb-4 pb-4 border-b border-purple-800/50">
          <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">{dataset.name}</h2>
          <button onClick={onClose} className="p-1 rounded-full text-gray-400 hover:bg-gray-700/50 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="flex-grow overflow-y-auto pr-2 custom-scrollbar">
            <p className="text-gray-300 mb-6 text-base">{dataset.description}</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-sm">
                <div className="bg-black/20 p-3 rounded-lg border border-white/10">
                    <p className="text-purple-400 font-semibold mb-1">Domain</p>
                    <p className="text-gray-200">{dataset.domain || 'N/A'}</p>
                </div>
                <div className="bg-black/20 p-3 rounded-lg border border-white/10">
                    <p className="text-purple-400 font-semibold mb-1">Size</p>
                    <p className="text-gray-200">{dataset.size || 'N/A'}</p>
                </div>
                <div className="bg-black/20 p-3 rounded-lg border border-white/10">
                    <p className="text-purple-400 font-semibold mb-1">Price</p>
                    <p className="text-gray-200">{dataset.price ? `$${dataset.price}` : 'Subscription'}</p>
                </div>
                <div className="bg-black/20 p-3 rounded-lg border border-white/10">
                    <p className="text-purple-400 font-semibold mb-1">License</p>
                    <p className="text-gray-200">{dataset.licenseType || 'Standard'}</p>
                </div>
            </div>

            <h3 className="text-xl font-semibold text-white mb-3">Data Preview</h3>
            <div className="bg-black/30 p-4 rounded-lg border border-white/10 max-h-60 overflow-y-auto custom-scrollbar">
              {Array.isArray(dataset.previewText) ? (
                <div className="space-y-4">
                  {dataset.previewText.map((item, idx) => (
                    <div key={idx} className="bg-black/40 rounded-lg p-3">
                      <p className="font-semibold text-purple-300 mb-1">Q: {item.q}</p>
                      <p className="text-pink-100">A: {item.a}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-lg text-center text-pink-200 font-medium leading-relaxed drop-shadow-md">
                  {dataset.previewText}
                </p>
              )}
            </div>

            <h3 className="text-xl font-semibold text-white mt-6 mb-3">AI Prompt Idea</h3>
            <div className="bg-black/30 p-4 rounded-lg border border-white/10">
                <p className="text-gray-300 italic text-base">{aiPrompt}</p>
            </div>
        </div>
        <div className="mt-6 pt-4 flex justify-end border-t border-purple-800/50">
          {dataset.id === 'ind-14' && (
            <button
              className="px-6 py-2 rounded-md bg-gradient-to-r from-green-500 to-blue-600 text-white font-semibold hover:from-green-600 hover:to-blue-700 transition-all shadow-lg shadow-green-500/20 mr-4"
              onClick={handleBuyClick}
            >
              Buy Now – $7
            </button>
          )}
          <button
            className="px-6 py-2 rounded-md bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg shadow-purple-500/20"
            onClick={onClose}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
