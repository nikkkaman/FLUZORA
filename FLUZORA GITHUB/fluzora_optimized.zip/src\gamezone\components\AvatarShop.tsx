'use client';
import React from 'react';
import { useGameZoneContext } from '../context/GameZoneContext';
import GlassCard from './ui/GlassCard';
import GlassButton from './ui/GlassButton';
import GlassBadge from './ui/GlassBadge';

export default function AvatarShop() {
  const { avatars, user } = useGameZoneContext();
  return (
    <GlassCard>
      <div className="font-orbitron text-neon text-xl mb-4">Avatar Shop</div>
      <div className="mb-4 flex items-center gap-4">
        <span className="font-orbitron text-white/80">Current Avatar:</span>
        <img src={user.avatar} alt="Current Avatar" className="w-14 h-14 rounded-full border-2 border-neon" />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
        {avatars.map((a: any) => (
          <div key={a.id} className="flex flex-col items-center gap-2 relative">
            <img src={a.src} alt="Avatar" className="w-16 h-16 rounded-full border-2 border-neon" />
            <div className="font-orbitron text-neon font-bold">{a.price} FLZ</div>
            {a.owned ? (
              <GlassBadge>Equipped</GlassBadge>
            ) : (
              <GlassButton>Redeem</GlassButton>
            )}
          </div>
        ))}
      </div>
    </GlassCard>
  );
} 