import React from 'react';
import GameZoneLayout from '../layout/GameZoneLayout';
import { useGameZoneContext } from '../context/GameZoneContext';

export default function GameZoneChallenges() {
  const { challenges } = useGameZoneContext();
  return (
    <GameZoneLayout>
      <div className="mb-6">
        <a href="/gamezone" className="inline-block px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform">Back</a>
      </div>
      <h1 className="text-3xl font-orbitron text-neon mb-8">Ongoing Challenges</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
        {challenges.map((c: any) => (
          <div key={c.id} className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col gap-3">
            <div className="flex items-center gap-2">
              <span className="font-orbitron text-xl text-neon">{c.title}</span>
              <span className="ml-auto px-3 py-1 rounded-full bg-neon/10 text-neon font-bold text-xs">{c.domain}</span>
            </div>
            <div className="flex items-center gap-4 text-white/80 font-inter">
              <span>Bonus: <span className="text-neon font-bold">+{c.bonus} FLZ</span></span>
              <span className="ml-auto">Deadline: <span className="text-neon">{c.deadline}</span></span>
            </div>
            <button className="mt-4 px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform focus:outline-none focus:ring-2 focus:ring-neon" aria-label={`Upload for ${c.title}`}>Upload</button>
          </div>
        ))}
      </div>
    </GameZoneLayout>
  );
} 