"use client";

import React from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { Database, Brain, Zap, ArrowRight, Star, Globe, Shield } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-black text-white flex flex-col">
      {/* Hero Section */}
      <section className="py-24 px-4 flex-grow flex flex-col justify-center items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-8"
        >
          <h1 className="text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
            FLUZORA
          </h1>
          <h2 className="text-3xl font-bold text-purple-300">
            WORLD'S FIRST AI DATASET MARKETPLACE
          </h2>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Link href="/login">
            <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-4 rounded-lg text-lg font-semibold shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-all duration-300 flex items-center gap-2 hover:scale-105">
              GET STARTED <ArrowRight size={20} />
            </button>
          </Link>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-b from-black/50 to-purple-900/20 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-16">Why Choose Fluzora?</h2>
          
          <div className="grid md:grid-cols-3 gap-10">
            {[
              {
                icon: Brain,
                title: "Premium AI Data",
                description: "Access meticulously curated datasets ensuring the highest quality for AI training."
              },
              {
                icon: Zap,
                title: "Build Faster",
                description: "Reduce development time by 10x with ready-to-use, optimized datasets for your AI models."
              },
              {
                icon: Shield,
                title: "Enterprise Security",
                description: "Bank-grade encryption protecting your valuable data assets and AI models."
              },
              {
                icon: Star,
                title: "Quality Guaranteed",
                description: "Every dataset is verified by AI experts to ensure maximum performance and accuracy."
              },
              {
                icon: Globe,
                title: "Global Access",
                description: "Connect with datasets from around the world, covering every industry and domain."
              },
              {
                icon: Database,
                title: "Vast Selection",
                description: "Over 1,000+ datasets across multiple domains, from text and images to specialized data."
              }
            ].map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-8 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 shadow-lg shadow-purple-500/10 hover:shadow-purple-500/20"
              >
                <div className="flex items-center gap-4 mb-4">
                  <feature.icon size={28} className="text-purple-400" />
                  <h3 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                    {feature.title}
                  </h3>
                </div>
                <p className="text-gray-300">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Section: Not All Data Is Created Equal */}
      <section className="py-16 px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-3xl md:text-4xl font-bold text-center mb-10 bg-clip-text text-transparent bg-gradient-to-r from-pink-400 to-purple-400"
          style={{ fontFamily: 'Orbitron, Inter, sans-serif' }}
        >
          Not All Data Is Created Equal
        </motion.h2>
        <div className="flex flex-col md:flex-row gap-8 max-w-5xl mx-auto">
          <motion.div
            whileHover={{ y: -2 }}
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex-1 bg-gradient-to-br from-gray-900 to-black border-2 border-red-500/40 rounded-2xl p-8 shadow-lg mb-4 md:mb-0"
          >
            <h3 className="text-xl font-bold text-red-400 mb-4" style={{ fontFamily: 'Orbitron, Inter, sans-serif' }}>
              Public Web Data
            </h3>
            <ul className="text-gray-300 space-y-3 text-base" style={{ fontFamily: 'Inter, sans-serif' }}>
              <li>Often outdated and inconsistent</li>
              <li>Requires hours of cleaning</li>
              <li>Lacks structure or tagging</li>
              <li>No support or context</li>
              <li>Not optimized for building real AI agents</li>
              <li>Everyone else is using it too</li>
            </ul>
          </motion.div>
          <motion.div
            whileHover={{ y: -2 }}
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="flex-1 bg-gradient-to-br from-purple-900 to-pink-900 border-2 border-green-500/40 rounded-2xl p-8 shadow-lg"
          >
            <h3 className="text-xl font-bold text-green-400 mb-4" style={{ fontFamily: 'Orbitron, Inter, sans-serif' }}>
              FLUZORA-Curated Data
            </h3>
            <ul className="text-gray-100 space-y-3 text-base" style={{ fontFamily: 'Inter, sans-serif' }}>
              <li>Clean, structured, and use-case specific</li>
              <li>Tagged and enriched for AI workflows</li>
              <li>Updated and quality-checked regularly</li>
              <li>Trusted by real agents like Lora</li>
              <li>Designed for faster building, smarter results</li>
              <li>Exclusive to FLUZORA — not publicly searchable</li>
            </ul>
          </motion.div>
        </div>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-center text-lg text-pink-200 mt-10 font-semibold"
          style={{ fontFamily: 'Inter, sans-serif' }}
        >
          Build smarter — with structured data that actually performs.
        </motion.p>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-b from-purple-900/20 to-black/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="bg-purple-900/30 backdrop-blur-sm rounded-lg p-10 border border-purple-500/30 max-w-4xl mx-auto"
          >
            <h2 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600">
              Ready to Transform Your AI Development?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Join thousands of AI developers who are building the future with Fluzora's premium datasets.
            </p>
            <Link href="/login">
              <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-4 rounded-lg text-lg font-semibold shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-all duration-300 flex items-center gap-2 mx-auto hover:scale-105">
                Get Started Now <ArrowRight size={20} />
              </button>
            </Link>
          </motion.div>
        </div>
      </section>


    </div>
  );
}
