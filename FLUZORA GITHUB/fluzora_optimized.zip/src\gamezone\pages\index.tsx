import { redirect } from 'next/navigation';

export default function Page() {
  redirect('/gamezone/home');
  return null;
} 