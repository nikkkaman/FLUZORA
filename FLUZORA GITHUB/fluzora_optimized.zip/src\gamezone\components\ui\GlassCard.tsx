import React from 'react';

export default function GlassCard({ children, className = '' }: React.PropsWithChildren<{ className?: string }>) {
  return (
    <div className={`glassmorphic p-6 rounded-2xl ${className}`}>{children}</div>
  );
} 