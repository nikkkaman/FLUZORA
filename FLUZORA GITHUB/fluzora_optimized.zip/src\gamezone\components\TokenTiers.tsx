'use client';
import React from 'react';
import GlassBadge from './ui/GlassBadge';
import GlassCard from './ui/GlassCard';

const tiers = [
  { name: 'Bronze', min: 0, color: 'bg-yellow-700 text-yellow-300', benefits: 'Basic uploads, leaderboard access' },
  { name: 'Silver', min: 500, color: 'bg-gray-400 text-white', benefits: 'Challenge bonuses, avatar shop' },
  { name: 'Gold', min: 1500, color: 'bg-yellow-400 text-yellow-900', benefits: 'Vault redemptions, streak rewards' },
  { name: 'Platinum', min: 3000, color: 'bg-blue-400 text-white', benefits: 'Exclusive datasets, referral rewards' },
];

export default function TokenTiers() {
  return (
    <GlassCard className="mb-8">
      <div className="font-orbitron text-neon text-2xl mb-4">Token Tiers</div>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
        {tiers.map(t => (
          <div key={t.name} className="flex flex-col items-center gap-2">
            <GlassBadge className={t.color}>{t.name}</GlassBadge>
            <div className="text-white/80 font-inter">{t.min}+ FLZ</div>
            <div className="text-white/60 font-inter text-sm text-center">{t.benefits}</div>
          </div>
        ))}
      </div>
    </GlassCard>
  );
} 