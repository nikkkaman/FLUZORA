'use client';
import React, { useEffect, useState } from 'react';
import GlassCard from './ui/GlassCard';

function getTimeLeft(target: Date) {
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  if (diff <= 0) return '00:00:00';
  const h = String(Math.floor(diff / 3600000)).padStart(2, '0');
  const m = String(Math.floor((diff % 3600000) / 60000)).padStart(2, '0');
  const s = String(Math.floor((diff % 60000) / 1000)).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

export default function TokenCountdown() {
  const [left, setLeft] = useState(getTimeLeft(new Date(Date.now() + 3600 * 1000)));
  useEffect(() => {
    const interval = setInterval(() => {
      setLeft(getTimeLeft(new Date(Date.now() + 3600 * 1000)));
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  return (
    <GlassCard className="mb-8 flex flex-col items-center">
      <div className="font-orbitron text-neon text-2xl mb-2">Next Token Drop</div>
      <div className="font-orbitron text-4xl text-neon drop-shadow-neon">{left}</div>
    </GlassCard>
  );
} 