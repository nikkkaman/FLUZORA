import React from 'react';
import GameZoneLayout from '../layout/GameZoneLayout';

export default function GameZoneDocs() {
  return (
    <GameZoneLayout>
      <div className="mb-6">
        <a href="/gamezone" className="inline-block px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform">Back</a>
      </div>
      <h1 className="text-3xl font-orbitron text-neon mb-8">Documentation & Rules</h1>
      <div className="glassmorphic p-8 rounded-2xl shadow-xl max-w-3xl mx-auto">
        <h2 className="text-2xl font-orbitron text-neon mb-4">Terms & Conditions</h2>
        <ul className="list-disc pl-6 text-white/80 font-inter mb-6">
          <li>All datasets must comply with FLUZORA's data policies.</li>
          <li>No personally identifiable or sensitive information.</li>
          <li>All contributions are reviewed before approval.</li>
          <li>FLZ tokens are non-transferable and redeemable only within GameZone.</li>
        </ul>
        <h2 className="text-2xl font-orbitron text-neon mb-4">FAQ</h2>
        <ul className="list-disc pl-6 text-white/80 font-inter mb-6">
          <li><b>How do I earn FLZ?</b> By uploading datasets and completing challenges.</li>
          <li><b>How do I redeem datasets?</b> Use your FLZ in the Vault section.</li>
          <li><b>What file types are accepted?</b> CSV, TXT, and JSON.</li>
          <li><b>Where can I see my progress?</b> Check your Dashboard for stats and streaks.</li>
        </ul>
        <div className="mt-6">
          <a href="/policies" className="text-neon underline font-orbitron">View Full Policies</a>
        </div>
      </div>
    </GameZoneLayout>
  );
} 