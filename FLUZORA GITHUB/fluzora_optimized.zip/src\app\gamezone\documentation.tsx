import React from "react";
import { BookOpen } from "lucide-react";

const orbitron = { fontFamily: "'Orbitron', Inter, sans-serif" };
const inter = { fontFamily: "'Inter', sans-serif" };

export default function GameZoneDocumentation() {
  return (
    <main className="min-h-screen w-full bg-gradient-to-b from-slate-900 to-blue-950 flex flex-col items-center justify-start py-12 px-2">
      <section className="w-full max-w-4xl mx-auto bg-slate-900/90 border border-slate-700 rounded-2xl shadow-xl p-8 md:p-12 space-y-8">
        <h1 className="text-4xl font-bold text-slate-100 flex items-center gap-3 mb-2" style={orbitron}>
          <BookOpen className="text-blue-400" size={36} />
          GameZone Documentation
        </h1>
        <h2 className="text-2xl font-bold text-slate-100 mt-6 mb-2">Data Contribution Terms & Participation Policy</h2>
        <div className="text-slate-400 text-lg space-y-6" style={inter}>
          <div className="text-base text-slate-400">Effective Date: June 2025<br/>Version: 1.0</div>
          <ol className="list-decimal list-inside space-y-4">
            <li>
              <strong>Introduction</strong><br/>
              FLUZORA GameZone is a data contribution and rewards system designed to power the world's smartest AI agents. By participating in GameZone, users ("Contributors") voluntarily submit datasets to FLUZORA Technologies Pvt. Ltd. ("FLUZORA") in exchange for non-financial rewards, such as FLZ tokens and platform recognition.<br/><br/>
              By using GameZone, you acknowledge and accept the terms outlined below. These terms are legally binding and supersede any prior understanding between you and FLUZORA regarding GameZone contributions.
            </li>
            <li>
              <strong>Rights Granted to FLUZORA</strong><br/>
              By submitting any dataset through GameZone, you agree to grant FLUZORA a worldwide, irrevocable, perpetual, non-exclusive, royalty-free, and transferable license to:
              <ul className="list-disc list-inside ml-6">
                <li>Use, modify, process, analyze, distribute, sublicense, publish, and commercialize the submitted dataset</li>
                <li>Integrate the dataset into FLUZORA products, APIs, models, and tools, including resale as part of commercial offerings</li>
                <li>Display, promote, and use the data for marketing or research purposes, with or without attribution</li>
              </ul>
              Contributors do not retain any right to compensation, royalties, or profit sharing unless explicitly stated in a future signed agreement.
            </li>
            <li>
              <strong>Contributor Responsibilities</strong><br/>
              By uploading a dataset, you represent and warrant that:
              <ul className="list-disc list-inside ml-6">
                <li>You are the lawful owner or have obtained all necessary rights to the content</li>
                <li>The dataset does not contain any personally identifiable information (PII), copyrighted material, or confidential data</li>
                <li>The content is free from malware, false claims, or AI-generated spam</li>
              </ul>
              You acknowledge that submission of infringing, harmful, or deceptive data may result in:
              <ul className="list-disc list-inside ml-6">
                <li>Account suspension or permanent ban from FLUZORA and GameZone</li>
                <li>Legal action under applicable data or intellectual property laws</li>
              </ul>
            </li>
            <li>
              <strong>Quality, Format & Evaluation</strong><br/>
              To maintain FLUZORA's standard of excellence, all submitted datasets must meet the following criteria:
              <ul className="list-disc list-inside ml-6">
                <li>Structured and clean (CSV, TXT, JSON)</li>
                <li>Domain-relevant and valuable to AI use-cases</li>
                <li>Grammatically sound and logically organized</li>
                <li>Free from duplication, spam, or misleading content</li>
              </ul>
              FLUZORA reserves full and final discretion in determining whether a dataset is accepted, rejected, or modified.
            </li>
            <li>
              <strong>FLZ Token Rewards</strong><br/>
              Contributors may receive FLZ tokens based on internal evaluation of dataset quality, originality, usefulness, and alignment with FLUZORA's strategic goals.<br/>
              Tokens are non-convertible to cash and may be used only within the FLUZORA ecosystem.<br/>
              FLUZORA may change reward logic or token distribution policies at any time without prior notice.<br/>
              Contributing does not entitle you to equity, ownership, or royalties under any circumstance.
            </li>
            <li>
              <strong>Moderation & Control</strong><br/>
              FLUZORA retains full editorial and operational control over all contributions and GameZone operations, including:
              <ul className="list-disc list-inside ml-6">
                <li>Reviewing, editing, or removing any dataset without explanation</li>
                <li>Changing GameZone rules, rewards, and eligibility criteria at any time</li>
                <li>Permanently banning users who violate rules or abuse the system</li>
              </ul>
              FLUZORA has no obligation to publish, reward, or respond to any specific contribution.
            </li>
            <li>
              <strong>Privacy & Confidentiality</strong><br/>
              We respect your privacy and will never share your personal details (such as name, email, contact info) with third parties without consent.<br/>
              Datasets may be displayed publicly, but your personal identity will remain hidden unless explicitly authorized by you.<br/>
              FLUZORA follows data protection standards and applicable Indian data privacy laws.
            </li>
            <li>
              <strong>Legal Compliance</strong><br/>
              By participating in GameZone, you agree to comply with:
              <ul className="list-disc list-inside ml-6">
                <li>The Indian Information Technology Act, 2000 (as amended)</li>
                <li>International IP and data protection standards (e.g., GDPR where applicable)</li>
                <li>Any applicable local regulations in your jurisdiction</li>
              </ul>
              You accept full legal responsibility for the content you upload.
            </li>
            <li>
              <strong>Indemnity & Liability</strong><br/>
              You agree to indemnify and hold harmless FLUZORA, its founders, team members, and affiliates from any legal claims, damages, or liabilities arising from your submitted content.<br/>
              FLUZORA shall not be liable for:
              <ul className="list-disc list-inside ml-6">
                <li>Loss of data or rewards</li>
                <li>Disputes over content originality</li>
                <li>Any indirect or incidental damages related to GameZone</li>
              </ul>
            </li>
            <li>
              <strong>Contact & Support</strong><br/>
              For support, clarifications, or removal requests, contact:<br/>
              Email: <a href="mailto:support@fluzora.com" className="text-blue-400 underline">support@fluzora.com</a><br/>
              Official Site: <a href="https://www.fluzora.com" className="text-blue-400 underline">www.fluzora.com</a><br/>
              Registered Address: (Insert your real business address here)
            </li>
          </ol>
          <div className="mt-8 p-4 bg-blue-950/80 border border-blue-700 rounded-lg text-blue-300 text-base">
            ✅ By uploading a dataset to GameZone, you confirm that you have read, understood, and agreed to these terms in full.
          </div>
        </div>
      </section>
    </main>
  );
} 