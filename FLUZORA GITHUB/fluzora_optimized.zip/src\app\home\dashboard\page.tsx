"use client";
import React from "react";

export default function HomeDashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f051d] to-[#1a1333] py-10 px-4 font-inter">
      <div className="max-w-2xl mx-auto bg-white/10 border-2 border-purple-500/40 rounded-xl p-8 shadow-xl backdrop-blur-xl mt-16">
        <h1 className="text-3xl md:text-4xl font-orbitron font-bold text-center mb-8 text-white drop-shadow-[0_0_10px_#a855f7]" style={{ fontFamily: 'Orbitron, sans-serif' }}>
          Home Dashboard
        </h1>
        <div className="bg-black/30 rounded-lg p-6 text-white/90 text-center">
          <p className="text-lg mb-2">Welcome to your Home Dashboard!</p>
          <p className="text-purple-300">(Future widgets and stats will appear here.)</p>
        </div>
      </div>
      <style jsx global>{`
        .font-orbitron { font-family: 'Orbitron', sans-serif; }
        .font-inter { font-family: 'Inter', sans-serif; }
      `}</style>
    </div>
  );
} 