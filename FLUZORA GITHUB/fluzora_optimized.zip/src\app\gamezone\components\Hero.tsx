"use client";
import React from "react";
import { motion } from "framer-motion";
import Link from "next/link";
// import { Particles } from "react-tsparticles"; // Uncomment and configure if using tsParticles

export default function Hero() {
  return (
    <section className="relative py-24 px-4 flex flex-col justify-center items-center text-center min-h-[60vh] overflow-hidden">
      {/* Floating 3D spark particles background (add tsParticles/Three.js here) */}
      {/* <Particles options={...} className="absolute inset-0 z-0" /> */}
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-5xl md:text-7xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 max-w-4xl drop-shadow-lg tracking-tight font-orbitron z-10"
      >
        ENTER THE GAMEZONE
      </motion.h1>
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-2xl md:text-3xl font-medium mb-10 text-purple-200/90 max-w-2xl mx-auto tracking-normal font-inter z-10"
      >
        Contribute. Compete. Collect. Curated data meets gamified rewards.
      </motion.h2>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="z-10"
      >
        <Link href="/gamezone/upload">
          <button className="px-10 py-4 rounded-xl font-orbitron text-lg bg-white/10 border border-white/20 backdrop-blur-md text-neon shadow-lg hover:bg-white/20 hover:scale-105 transition-all duration-300">
            Start Your Data Quest
          </button>
        </Link>
      </motion.div>
    </section>
  );
} 