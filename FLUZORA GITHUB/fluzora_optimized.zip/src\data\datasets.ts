import { Dataset } from '@/hooks/useDatasets';

export const allDatasets: Dataset[] = [
  // Health & Mental Health (cheapest first)
  {
    id: 'health-004',
    name: 'Meditation & Mindfulness Scripts',
    domain: 'Mental Health',
    description: 'A collection of guided meditation scripts for various goals like sleep, focus, and stress relief.',
    price: 25,
    size: 'N/A',
    tags: ['mental health', 'wellness', 'meditation', 'audio'],
    previewText: [
        { q: "What kind of meditations are included?", a: "Includes scripts for guided imagery, body scans, and breathing exercises." },
        { q: "Are there different lengths?", a: "Yes, scripts range from short 3-minute meditations to longer 20-minute sessions." },
        { q: "Can I use these for a meditation app?", a: "Absolutely. These scripts are ready to be recorded by a voice artist for your app." },
        { q: "Are the scripts written by experts?", a: "They are crafted by experienced meditation instructors and mindfulness coaches." },
        { q: "What themes do they cover?", a: "Themes include anxiety relief, improving focus, preparing for sleep, and cultivating gratitude." },
    ]
  },
  {
    id: 'fin-004',
    name: 'Personal Finance Planner Prompts',
    domain: 'Finance',
    description: 'A collection of user prompts and AI responses for creating personalized financial plans and budgets.',
    price: 29,
    size: 'N/A',
    tags: ['finance', 'planning', 'budgeting', 'prompts'],
    previewText: [
        { q: "What kind of financial plans can I create?", a: "Generate plans for saving for a house, retirement, or paying off debt." },
        { q: "Are the prompts realistic?", a: "The prompts are based on thousands of real-world user queries about personal finance." },
        { q: "Can this power a budgeting app's AI?", a: "Yes, it's ideal for training an AI assistant to give smart, personalized financial advice." },
        { q: "How are the AI responses structured?", a: "Responses are helpful, actionable, and broken down into easy-to-follow steps." },
        { q: "Does it cover investment advice?", a: "It provides prompts and responses for basic investment planning, suitable for a general audience." },
    ]
  },
  {
    id: 'health-002',
    name: 'Fitness Goal Tracker Bot Data',
    domain: 'Fitness',
    description: 'User goals, workout logs, and progress metrics for building a motivational fitness tracking AI.',
    price: 39,
    size: 'N/A',
    tags: ['fitness', 'health', 'tracking', 'goals'],
    previewText: [
        { q: "What fitness goals are included?", a: "Goals range from 'lose 10 pounds' and 'run a 5k' to 'build muscle'." },
        { q: "Does it include workout data?", a: "Yes, it contains logs for various activities like running, weightlifting, and yoga." },
        { q: "Can I build a motivational bot with this?", a: "The data includes progress check-ins and motivational messages to keep users engaged." },
        { q: "Is nutrition data part of this set?", a: "This dataset focuses on exercise. A separate Nutrition Tracker dataset is available." },
        { q: "How is progress measured?", a: "Metrics include weight, distance, reps/sets, and self-reported energy levels." },
    ]
  },
  {
    id: 'health-005',
    name: 'Personalized Meal Planner Data',
    domain: 'Fitness',
    description: 'A database of recipes, nutritional information, and dietary preferences for creating custom meal plans.',
    price: 45,
    size: 'N/A',
    tags: ['fitness', 'health', 'nutrition', 'planning'],
    previewText: [
        { q: "Can this create a keto or vegan meal plan?", a: "Yes, recipes are tagged with dietary labels like 'keto', 'vegan', 'gluten-free', etc." },
        { q: "Does it include nutritional information?", a: "Every recipe comes with a full breakdown of calories, macros (protein, carbs, fat), and micronutrients." },
        { q: "How can this be used in an app?", a: "You can build an AI that generates weekly meal plans based on a user's goals and preferences." },
        { q: "Are the recipes easy to make?", a: "The dataset includes a mix of simple, quick recipes and more advanced ones." },
        { q: "How many recipes are included?", a: "The database contains over 1,000 unique recipes for breakfast, lunch, dinner, and snacks." },
    ]
  },
  {
    id: 'fin-001',
    name: 'Credit Card Dispute Generator',
    domain: 'Finance',
    description: 'Generate realistic credit card dispute scenarios and resolution dialogues for training customer support AI.',
    price: 49,
    size: 'N/A',
    tags: ['finance', 'customer support', 'disputes', 'chatbot'],
    previewText: [
      { q: "What kind of disputes are included?", a: "Covers common scenarios like 'unrecognized charge', 'duplicate billing', and 'defective product'." },
      { q: "Can this train a chatbot to handle angry customers?", a: "Yes, the dataset includes dialogues with varying tones, from calm to highly frustrated." },
      { q: "Is the data structured for easy parsing?", a: "Yes, each entry is a clean JSON object with fields for customer query, agent response, and resolution status." },
      { q: "How large is this dataset?", a: "Contains over 5,000 unique dispute scenarios and dialogues." },
      { q: "Can this help reduce resolution time?", a: "Models trained on this data can learn to identify issue types faster, leading to quicker resolutions." },
    ],
  },
  {
    id: 'health-001',
    name: 'Mental Health Copilot Dialogues',
    domain: 'Mental Health',
    description: 'Therapeutic-style dialogues for training AI copilots to support users with anxiety and stress.',
    price: 65,
    size: 'N/A',
    tags: ['mental health', 'chatbot', 'dialogues', 'wellness'],
    previewText: [
        { q: "Is this data written by professionals?", a: "Dialogues are based on principles of Cognitive Behavioral Therapy (CBT) and reviewed by therapists." },
        { q: "What topics are covered?", a: "It covers common anxiety triggers, stress management techniques, and mindfulness exercises." },
        { q: "Can this AI provide real therapy?", a: "This data is for building supportive copilots, not to replace professional therapy. It includes disclaimers for a real app." },
        { q: "How are the dialogues structured?", a: "Each dialogue is a turn-by-turn conversation between a 'user' and an 'AI copilot'." },
        { q: "Is the tone empathetic?", a: "Yes, all AI responses are designed to be non-judgmental, empathetic, and supportive." },
    ]
  },
  {
    id: 'fin-005',
    name: 'Real Estate Market Analysis',
    domain: 'Finance',
    description: 'Property listings, pricing history, and neighborhood demographics for training predictive real estate models.',
    price: 75,
    size: 'N/A',
    tags: ['finance', 'real estate', 'investment', 'prediction'],
     previewText: [
        { q: "Can this data predict future housing prices?", a: "Yes, the historical pricing and market trends are perfect for building predictive models." },
        { q: "What locations are covered?", a: "It includes data from 5 major metropolitan areas with diverse market dynamics." },
        { q: "Does it include neighborhood data?", a: "Yes, data on schools, crime rates, and amenities is included for deeper analysis." },
        { q: "How granular is the property information?", a: "Each listing includes details like square footage, number of rooms, and year built." },
        { q: "Is this useful for real estate investors?", a: "Absolutely. It's designed to help investors identify undervalued properties and growth areas." },
    ]
  },
  {
    id: 'fin-003',
    name: 'Insurance Claim Automation Data',
    domain: 'Finance',
    description: 'Structured data on auto, health, and property insurance claims to train models for automated assessment.',
    price: 89,
    size: 'N/A',
    tags: ['finance', 'insurance', 'automation', 'fintech'],
    previewText: [
        { q: "What types of insurance claims are included?", a: "The dataset covers auto accidents, property damage, and common health insurance claims." },
        { q: "Can this data help in detecting fraudulent claims?", a: "Yes, it includes labeled examples of both legitimate and fraudulent claims for training detection models." },
        { q: "Is the data structured for machine learning?", a: "Each claim is a structured object with fields for policy details, incident reports, and payout amounts." },
        { q: "How can this improve claim processing speed?", a: "Models trained on this data can learn to automatically categorize and assess claims, reducing manual work." },
        { q: "Does it include image data?", a: "This version contains structured text data. An expanded version with images is available in the Ultimate pack." },
    ]
  },
  {
    id: 'health-003',
    name: 'Symptom Checker Q&A',
    domain: 'Health',
    description: 'A large set of common medical symptoms and their potential diagnoses, reviewed by medical professionals.',
    price: 85,
    size: 'N/A',
    tags: ['health', 'medical', 'q&a', 'diagnostics'],
    previewText: [
        { q: "Can this AI replace a doctor?", a: "No, it's designed to provide preliminary information and suggest when to see a professional." },
        { q: "How accurate is the information?", a: "The data is sourced from reputable medical knowledge bases and reviewed by doctors for accuracy." },
        { q: "What range of symptoms does it cover?", a: "It covers over 200 common symptoms, from headaches and fevers to digestive issues." },
        { q: "Is the data structured for a chatbot?", a: "Yes, it's formatted as question-answer pairs for easy integration into a diagnostic bot." },
        { q: "Does it include severity levels?", a: "Yes, it provides context on when a symptom might be a sign of a serious condition." },
    ]
  },
  {
    id: 'fin-002',
    name: 'Stock Market Q&A 2024',
    domain: 'Finance',
    description: 'A vast collection of questions and expert answers about the 2024 stock market, perfect for financial assistants.',
    price: 120,
    size: 'N/A',
    tags: ['finance', 'q&a', 'investment', 'stock market'],
    previewText: [
        { q: "What topics does this Q&A cover?", a: "It covers everything from stock valuation and market analysis to IPOs and dividend strategies." },
        { q: "Is the information up-to-date?", a: "Yes, all data and answers are relevant to the 2024 market landscape." },
        { q: "Can I build a financial advice bot with this?", a: "This is a perfect foundation for training a bot to answer common investor questions accurately." },
        { q: "How complex are the answers?", a: "They range from beginner-friendly explanations to in-depth expert analysis." },
        { q: "Are sources included for the answers?", a: "Where applicable, answers are linked to public financial reports and reputable market analysis." },
    ]
  },
  {
    id: 'legal-001',
    name: 'Legal Compliance Explainers',
    domain: 'Legal',
    description: 'Complex legal regulations (like GDPR, CCPA) explained in simple terms, perfect for compliance bots.',
    price: 110,
    size: 'N/A',
    tags: ['legal', 'compliance', 'q&a', 'gdpr'],
    previewText: [
        { q: "What legal topics does this cover?", a: "It focuses on data privacy (GDPR, CCPA), financial compliance (AML), and intellectual property." },
        { q: "Is this a substitute for a lawyer?", a: "No, it's for informational purposes to help businesses understand compliance basics." },
        { q: "How is the information simplified?", a: "Complex legal jargon is translated into easy-to-understand language with practical examples." },
        { q: "Can I build a compliance assistant with this?", a: "Yes, it's ideal for training an AI to answer common compliance questions from employees." },
        { q: "Is the information kept up-to-date?", a: "The dataset is updated quarterly to reflect major changes in key regulations." },
    ]
  },
  {
    id: 'fin-003',
    name: 'Insurance Claim Automation Data',
    domain: 'Finance',
    description: 'Structured data on auto, health, and property insurance claims to train models for automated assessment.',
    price: 89,
    size: 'N/A',
    tags: ['finance', 'insurance', 'automation', 'fintech'],
    previewText: [
        { q: "What types of insurance claims are included?", a: "The dataset covers auto accidents, property damage, and common health insurance claims." },
        { q: "Can this data help in detecting fraudulent claims?", a: "Yes, it includes labeled examples of both legitimate and fraudulent claims for training detection models." },
        { q: "Is the data structured for machine learning?", a: "Each claim is a structured object with fields for policy details, incident reports, and payout amounts." },
        { q: "How can this improve claim processing speed?", a: "Models trained on this data can learn to automatically categorize and assess claims, reducing manual work." },
        { q: "Does it include image data?", a: "This version contains structured text data. An expanded version with images is available in the Ultimate pack." },
    ]
  },
  // Finance
  {
    id: 'fin-006',
    name: 'Loan Application Risk Predictor',
    domain: 'Finance',
    description: 'Anonymized historical loan application data with outcomes (approved, denied) to train risk assessment models.',
    price: 115,
    size: 'N/A',
    tags: ['finance', 'risk management', 'fintech', 'prediction'],
    previewText: [
      { q: "Can this AI predict if a loan will be repaid?", a: "Yes, it's designed to train models that assess the risk of default based on applicant data." },
      { q: "What data points are included?", a: "Includes anonymized credit score ranges, income levels, loan amounts, and loan outcomes." },
      { q: "Is this compliant with financial regulations?", a: "The data is fully anonymized and synthetic in parts to comply with privacy laws." },
      { q: "How can this help a lending business?", a: "It can automate the initial screening of loan applications, saving time and reducing human bias." },
      { q: "Is it suitable for academic research?", a: "Yes, it's an excellent resource for studying credit risk and financial modeling." },
    ]
  },
  {
    id: 'health-006',
    name: 'Clinical Trial Patient Matching',
    domain: 'Health',
    description: 'A dataset of patient profiles and clinical trial eligibility criteria to train a patient-matching AI.',
    price: 95,
    size: 'N/A',
    tags: ['health', 'medical', 'clinical trials', 'research'],
    previewText: [
      { q: "How can this speed up medical research?", a: "By automatically matching eligible patients to clinical trials, it can significantly accelerate recruitment." },
      { q: "What diseases are covered?", a: "The dataset includes trials for oncology, cardiology, and neurological disorders." },
      { q: "What patient data is included?", a: "Anonymized data such as diagnosis, age, medical history, and genetic markers." },
      { q: "Can I build a tool for hospitals?", a: "Yes, this can power a system that helps doctors find relevant trials for their patients." },
      { q: "Is the data structure complex?", a: "It's structured with clear links between patient profiles and trial criteria for easy processing." },
    ]
  },
  {
    id: 'legal-003',
    name: 'Intellectual Property Case Law Q&A',
    domain: 'Legal',
    description: 'A collection of Q&A on landmark intellectual property cases, covering patents, trademarks, and copyrights.',
    price: 79,
    size: 'N/A',
    tags: ['legal', 'intellectual property', 'q&a', 'case law'],
    previewText: [
      { q: "Can this help me understand patent law?", a: "Yes, it breaks down complex case law into simple questions and answers." },
      { q: "Is this useful for law students?", a: "It's an excellent study aid for understanding the key precedents in IP law." },
      { q: "What famous cases are included?", a: "Includes summaries of cases like Apple vs. Samsung and Diamond vs. Chakrabarty." },
      { q: "Can I use this for a legal tech app?", a: "It's perfect for training a legal assistant bot that can answer basic IP questions." },
      { q: "How is it different from a law textbook?", a: "The Q&A format makes it more accessible and easier to search for specific topics." },
    ]
  },
  {
    id: 'prod-003',
    name: 'Developer Productivity Metrics',
    domain: 'Productivity',
    description: 'A dataset of anonymized git commits, pull requests, and ticket resolutions to analyze developer productivity.',
    price: 85,
    size: 'N/A',
    tags: ['productivity', 'software development', 'analytics', 'devops'],
    previewText: [
      { q: "How can I measure my team's performance?", a: "Analyze metrics like commit frequency, code churn, and lead time for changes." },
      { q: "Is this data biased?", a: "The dataset focuses on team-level metrics rather than individual performance to avoid bias." },
      { q: "Can it identify bottlenecks in our workflow?", a: "Yes, you can spot trends like long pull request review times or high bug rates." },
      { q: "Is it compatible with tools like Jira?", a: "The data is structured to be easily imported and analyzed alongside your existing project management data." },
      { q: "Can this help improve team collaboration?", a: "Yes, by providing objective data, it facilitates constructive conversations about workflow improvements." },
    ]
  },
  {
    id: 'mktg-002',
    name: 'Customer Segmentation Profiles',
    domain: 'Marketing',
    description: 'A dataset of anonymized customer profiles with purchasing behavior, demographics, and engagement metrics.',
    price: 90,
    size: 'N/A',
    tags: ['marketing', 'customer segmentation', 'analytics', 'e-commerce'],
    previewText: [
      { q: "How can I understand my customer base better?", a: "Use this data to identify distinct customer segments like 'High Spenders' or 'New Shoppers'." },
      { q: "What data is included in a profile?", a: "Includes purchase history, frequency, average order value, and site engagement." },
      { q: "Can this help with targeted advertising?", a: "Absolutely. You can create personalized marketing campaigns for each customer segment." },
      { q: "Is the data privacy-compliant?", a: "All data is anonymized and aggregated to protect individual privacy." },
      { q: "Can I use this with machine learning?", a: "Yes, it's perfect for training clustering algorithms like K-Means to find segments automatically." },
    ]
  },
  {
    id: 'support-003',
    name: 'Customer Churn Prediction Data',
    domain: 'Customer Support',
    description: 'Anonymized data of SaaS user activity, support tickets, and subscription status to predict customer churn.',
    price: 125,
    size: 'N/A',
    tags: ['customer support', 'churn prediction', 'saas', 'analytics'],
    previewText: [
      { q: "Can I predict which customers are about to cancel?", a: "Yes, train a model to identify users at high risk of churning based on their behavior." },
      { q: "What are the key predictors of churn?", a: "Analyze factors like decreased product usage, frequent support issues, and billing problems." },
      { q: "How can this save my business money?", a: "By proactively engaging at-risk customers, you can reduce churn and increase customer lifetime value." },
      { q: "Is the data labeled?", a: "Yes, each user profile is labeled with a 'Churned' or 'Active' status." },
      { q: "Can this integrate with my CRM?", a: "The structured data can be used to build a churn prediction dashboard within your existing tools." },
    ]
  },
  {
    id: 'edu-003',
    name: 'Language Learning Flashcard Deck',
    domain: 'Education',
    description: 'A massive deck of vocabulary flashcards for Spanish, French, and German, with translations and example sentences.',
    price: 20,
    size: 'N/A',
    tags: ['education', 'language learning', 'flashcards', 'edutech'],
    previewText: [
      { q: "How many words are included per language?", a: "Each language includes the 3,000 most common vocabulary words." },
      { q: "Does it include audio pronunciation?", a: "This dataset contains text only. An audio version is available separately." },
      { q: "Can I build a language app with this?", a: "Yes, this is the perfect content backbone for a spaced-repetition learning app like Anki or Duolingo." },
      { q: "Are example sentences provided?", a: "Yes, every word comes with an example sentence to provide context." },
      { q: "Is it suitable for all learning levels?", a: "It's ideal for beginners and intermediate learners looking to expand their vocabulary." },
    ]
  },
  {
    id: 'self-001',
    name: 'Positive Affirmations Generator',
    domain: 'Self-Help',
    description: 'A large collection of positive affirmations categorized by theme, such as self-esteem, career, and relationships.',
    price: 15,
    size: 'N/A',
    tags: ['self-help', 'wellness', 'mental health', 'generator'],
     previewText: [
        { q: "What are positive affirmations?", a: "They are positive statements that can help challenge and overcome self-sabotaging and negative thoughts." },
        { q: "What themes are included?", a: "Themes include building confidence, attracting success, improving relationships, and fostering a positive mindset." },
        { q: "How can I use this data?", a: "You can build an app that sends users a daily affirmation, or a generator for creating custom ones." },
        { q: "Are the affirmations well-written?", a: "Yes, they are crafted to be empowering, positive, and easy to remember." },
        { q: "Is this suitable for a wellness app?", a: "Absolutely. It's a simple but powerful feature to add to any wellness or mental health application." },
    ]
  },
  {
    id: 'mktg-001',
    name: 'A/B Testing Headline Data',
    domain: 'Marketing',
    description: 'A dataset of website headlines and their corresponding click-through rates (CTR) from A/B tests.',
    price: 99,
    size: 'N/A',
    tags: ['marketing', 'ab testing', 'optimization', 'copywriting'],
     previewText: [
        { q: "Can this help me write better headlines?", a: "Yes, by analyzing which headlines performed best, you can learn the principles of high-converting copy." },
        { q: "What industries are covered?", a: "The data includes A/B tests from e-commerce, SaaS, and content websites." },
        { q: "What metrics are included besides CTR?", a: "The dataset also includes conversion rates for some of the tests, where available." },
        { q: "Can I train an AI to write headlines?", a: "This data is a great starting point for fine-tuning a language model to generate effective marketing copy." },
        { q: "How many A/B tests are in the dataset?", a: "It contains the results of over 1,000 different headline A/B tests." },
    ]
  },
  // Legal & Productivity
  {
    id: 'legal-002',
    name: 'Contract Anomaly Detection Set',
    domain: 'Legal',
    description: 'A set of legal contracts with labeled clauses that are unusual, risky, or non-standard.',
    price: 140,
    size: 'N/A',
    tags: ['legal', 'contracts', 'risk management', 'fintech'],
    previewText: [
        { q: "What does 'anomaly detection' do?", a: "It trains an AI to flag clauses in a contract that deviate from standard legal language." },
        { q: "Can this replace a legal review?", a: "No, but it can speed it up by highlighting potential areas of concern for a lawyer to review." },
        { q: "What types of contracts are included?", a: "Includes NDAs, service agreements, and employment contracts with highlighted anomalies." },
        { q: "How are anomalies labeled?", a: "Clauses are tagged with risk levels (e.g., 'High Risk - Vague Liability') and explanations." },
        { q: "Is this for experienced lawyers only?", a: "It's a powerful tool for legal teams, but also for businesses looking to streamline contract reviews." },
    ]
  },
  {
    id: 'prod-002',
    name: 'Meeting Summarizer Training Data',
    domain: 'Productivity',
    description: 'A collection of meeting transcripts and their human-written summaries, perfect for training summarization AI.',
    price: 60,
    size: 'N/A',
    tags: ['productivity', 'meetings', 'summarization', 'nlp'],
    previewText: [
        { q: "Can this AI summarize my Zoom meetings?", a: "Yes, it's designed to train models that can turn long transcripts into concise summaries." },
        { q: "What is included in the summaries?", a: "Summaries include key decisions, action items, and main discussion points." },
        { q: "How long are the meetings?", a: "Transcripts range from short 15-minute check-ins to hour-long project kickoffs." },
        { q: "Is the data clean?", a: "All transcripts have been cleaned and anonymized, with clear speaker labels." },
        { q: "How accurate are the summaries?", a: "The human-written summaries are high-quality and serve as a 'gold standard' for training." },
    ]
  },
   // Education & Customer Support
  {
    id: 'edu-001',
    name: 'Personalized Learning Path Generator',
    domain: 'Education',
    description: 'Data on learning topics, their dependencies, and user skill levels to generate custom learning roadmaps.',
    price: 70,
    size: 'N/A',
    tags: ['education', 'learning', 'personalization', 'edutech'],
     previewText: [
        { q: "How does it create a personalized path?", a: "It uses a knowledge graph to map out how topics connect, from beginner to advanced." },
        { q: "What subjects are included?", a: "This dataset focuses on tech skills like 'Python Programming', 'Data Science', and 'Web Development'." },
        { q: "Can this power an educational platform?", a: "Yes, it's the perfect backend for an AI that suggests the next best module for a student to learn." },
        { q: "How do you assess user skill level?", a: "The data includes sample quizzes and project outputs that can be used to gauge proficiency." },
        { q: "Can it adapt to different learning styles?", a: "The topic data is tagged with formats like 'video', 'article', or 'interactive project' to suit different learners." },
    ]
  },
  {
    id: 'support-001',
    name: 'E-commerce Support Chatbot Dialogues',
    domain: 'Customer Support',
    description: 'Realistic customer support chats for an e-commerce store, covering topics from shipping to returns.',
    price: 49,
    size: 'N/A',
    tags: ['customer support', 'chatbot', 'dialogues', 'retail'],
     previewText: [
        { q: "What kind of customer questions are included?", a: "Common questions like 'Where is my order?', 'How do I make a return?', and 'Is this item in stock?'." },
        { q: "Can this bot handle complex issues?", a: "It's trained to handle common queries and to escalate more complex issues to a human agent." },
        { q: "Is the data ready for training?", a: "Yes, the dialogues are structured in a simple, turn-by-turn format, ideal for training a chatbot." },
        { q: "Does it include different customer tones?", a: "Yes, the dataset features examples of patient, impatient, and confused customers." },
        { q: "Can this reduce my support ticket volume?", a: "An AI trained on this data can resolve a significant percentage of common customer questions automatically." },
    ]
  },
  {
    id: 'edu-002',
    name: 'Historical Events Q&A',
    domain: 'Education',
    description: 'A comprehensive dataset of questions and answers about major world history events.',
    price: 35,
    size: 'N/A',
    tags: ['education', 'history', 'q&a', 'trivia'],
    previewText: [
        { q: "What historical periods are covered?", a: "From ancient civilizations and the Roman Empire to the World Wars and the Cold War." },
        { q: "Is this good for building a trivia app?", a: "Perfect! The Q&A format is ideal for creating a fun and educational history trivia game." },
        { q: "How accurate is the information?", a: "All answers have been verified against reputable historical sources and academic texts." },
        { q: "Are the questions multiple choice?", a: "The data includes both open-ended questions and questions with defined correct answers for flexibility." },
        { q: "Can this be used as a study aid?", a: "Yes, it's a great tool for students to test their knowledge and prepare for history exams." },
    ]
  },
  {
    id: 'support-002',
    name: 'SaaS Helpdesk Ticket Classifier',
    domain: 'Customer Support',
    description: 'A labeled dataset of SaaS helpdesk tickets, categorized by issue type (e.g., Bug, Feature Request, Billing).',
    price: 65,
    size: 'N/A',
    tags: ['customer support', 'saas', 'classification', 'automation'],
    previewText: [
        { q: "How can this organize my support tickets?", a: "Train an AI to automatically categorize incoming tickets so they can be routed to the right team." },
        { q: "What SaaS issues are covered?", a: "Covers common issues for a typical SaaS product, including login problems, bugs, billing questions, and feature requests." },
        { q: "Does it help prioritize tickets?", a: "Yes, tickets are labeled with a priority level (Low, Medium, High, Urgent) based on their content." },
        { q: "Can this integrate with Zendesk or Jira?", a: "The structured data can be used to build integrations that automate ticket tagging in popular helpdesk systems." },
        { q: "How does this improve support efficiency?", a: "By automating categorization and prioritization, it frees up your support team to focus on solving problems." },
    ]
  },
  // Self-Help & Marketing
  {
    id: 'self-001',
    name: 'Positive Affirmations Generator',
    domain: 'Self-Help',
    description: 'A large collection of positive affirmations categorized by theme, such as self-esteem, career, and relationships.',
    price: 15,
    size: 'N/A',
    tags: ['self-help', 'wellness', 'mental health', 'generator'],
     previewText: [
        { q: "What are positive affirmations?", a: "They are positive statements that can help challenge and overcome self-sabotaging and negative thoughts." },
        { q: "What themes are included?", a: "Themes include building confidence, attracting success, improving relationships, and fostering a positive mindset." },
        { q: "How can I use this data?", a: "You can build an app that sends users a daily affirmation, or a generator for creating custom ones." },
        { q: "Are the affirmations well-written?", a: "Yes, they are crafted to be empowering, positive, and easy to remember." },
        { q: "Is this suitable for a wellness app?", a: "Absolutely. It's a simple but powerful feature to add to any wellness or mental health application." },
    ]
  },
  {
    id: 'mktg-001',
    name: 'A/B Testing Headline Data',
    domain: 'Marketing',
    description: 'A dataset of website headlines and their corresponding click-through rates (CTR) from A/B tests.',
    price: 99,
    size: 'N/A',
    tags: ['marketing', 'ab testing', 'optimization', 'copywriting'],
     previewText: [
        { q: "Can this help me write better headlines?", a: "Yes, by analyzing which headlines performed best, you can learn the principles of high-converting copy." },
        { q: "What industries are covered?", a: "The data includes A/B tests from e-commerce, SaaS, and content websites." },
        { q: "What metrics are included besides CTR?", a: "The dataset also includes conversion rates for some of the tests, where available." },
        { q: "Can I train an AI to write headlines?", a: "This data is a great starting point for fine-tuning a language model to generate effective marketing copy." },
        { q: "How many A/B tests are in the dataset?", a: "It contains the results of over 1,000 different headline A/B tests." },
    ]
  },
  {
    id: 'mktg-003',
    name: 'Social Media Influencer Analytics',
    domain: 'Marketing',
    description: 'A database of social media influencers, their follower counts, engagement rates, and content categories.',
    price: 70,
    size: 'N/A',
    tags: ['marketing', 'influencer marketing', 'social media', 'analytics'],
    previewText: [
      { q: "How can I find the right influencer for my brand?", a: "Use this data to filter influencers by niche, engagement rate, and audience size." },
      { q: "What platforms are covered?", a: "The dataset includes influencers from Instagram, TikTok, and YouTube." },
      { q: "Is the engagement data reliable?", a: "Engagement rates are calculated based on a recent sample of posts to ensure accuracy." },
      { q: "Can this help me spot fake followers?", a: "While not definitive, you can analyze follower-to-engagement ratios to flag potential red flags." },
      { q: "How can this optimize my marketing budget?", a: "By choosing the right influencers, you can ensure your marketing spend goes towards reaching an engaged and relevant audience." },
    ]
  },
  {
    id: 'edu-004',
    name: 'Scientific Paper Summarization Set',
    domain: 'Education',
    description: 'A collection of scientific papers from various fields and their corresponding abstracts (summaries).',
    price: 110,
    size: 'N/A',
    tags: ['education', 'research', 'nlp', 'summarization'],
    previewText: [
      { q: "Can this AI summarize dense research papers?", a: "Yes, it's designed to train models that can extract the key findings from complex academic texts." },
      { q: "What scientific fields are included?", a: "The dataset includes papers from computer science, biology, and physics." },
      { q: "Is this useful for students and researchers?", a: "It's an invaluable tool for quickly understanding the gist of a paper without reading the whole thing." },
      { q: "How does it handle technical jargon?", a: "The models trained on this data learn to recognize and correctly summarize specialized terminology." },
      { q: "Can I build a research assistant tool?", a: "Absolutely. This is the core component for an AI that helps users stay up-to-date with the latest research." },
    ]
  },
   {
    id: 'legal-004',
    name: 'Deposition Transcript Analysis Data',
    domain: 'Legal',
    description: 'Anonymized deposition transcripts with labeled entities, topics, and sentiment.',
    price: 130,
    size: 'N/A',
    tags: ['legal', 'nlp', 'analytics', 'litigation'],
    previewText: [
      { q: "How can AI help analyze legal transcripts?", a: "It can automatically identify key people, dates, and topics mentioned in a long deposition." },
      { q: "Can it detect sentiment or deception?", a: "The data includes sentiment labels (e.g., 'hesitant', 'confident') that can help in building analysis models." },
      { q: "Is this useful for trial preparation?", a: "Yes, it helps legal teams quickly search and analyze thousands of pages of testimony to find key evidence." },
      { q: "Is the data anonymized?", a: "All personal identifying information has been removed to protect privacy." },
      { q: "Can this create a summary of a deposition?", a: "The topic modeling labels can be used to generate a structured summary of the key points discussed." },
    ]
  },
  {
    id: 'self-003',
    name: 'Dream Journal & Interpretation Data',
    domain: 'Self-Help',
    description: 'A collection of anonymized dream journal entries and their symbolic interpretations.',
    price: 22,
    size: 'N/A',
    tags: ['self-help', 'psychology', 'journaling', 'nlp'],
    previewText: [
      { q: "Can an AI interpret my dreams?", a: "Train a model to identify common dream symbols and offer potential interpretations based on psychological theories." },
      { q: "What kind of symbols are included?", a: "Covers common dream themes like flying, falling, being chased, and encounters with animals." },
      { q: "Is this based on scientific principles?", a: "Interpretations are based on common archetypes from Jungian psychology and other dream analysis theories." },
      { q: "Can I build a dream journaling app?", a: "Yes, this dataset provides a unique and engaging feature for any journaling or wellness app." },
      { q: "Is the data sensitive?", a: "All entries are fully anonymized and have been reviewed to remove any identifying details." },
    ]
  },
  {
    id: 'fitness-001',
    name: 'Yoga Pose Image & Instruction Set',
    domain: 'Fitness',
    description: 'A dataset of yoga poses with high-quality images, step-by-step instructions, and difficulty labels.',
    price: 45,
    size: 'N/A',
    tags: ['fitness', 'yoga', 'images', 'health'],
    previewText: [
      { q: "Can this be used for a yoga instruction app?", a: "Yes, it's perfect for building an app that guides users through different yoga poses and routines." },
      { q: "How many poses are included?", a: "The dataset contains over 100 common yoga poses, from beginner to advanced." },
      { q: "Are the images high-quality?", a: "All poses are demonstrated by a professional instructor in high-resolution images." },
      { q: "What do the instructions cover?", a: "They provide clear, step-by-step guidance on how to get into the pose safely and effectively." },
      { q: "Is it categorized by difficulty?", a: "Yes, poses are labeled as 'Beginner', 'Intermediate', or 'Advanced' for easy filtering." },
    ]
  },
   {
    id: 'fin-007',
    name: 'Cryptocurrency Sentiment Analysis',
    domain: 'Finance',
    description: 'A dataset of social media posts and news headlines about cryptocurrencies, labeled with sentiment (positive, negative, neutral).',
    price: 85,
    size: 'N/A',
    tags: ['finance', 'crypto', 'sentiment analysis', 'nlp'],
    previewText: [
      { q: "Can I gauge the market's mood on Bitcoin?", a: "Yes, train a model to analyze real-time sentiment and understand what drives crypto market hype." },
      { q: "What sources are used?", a: "The data is collected from Twitter, Reddit, and major financial news outlets." },
      { q: "How is sentiment labeled?", a: "Each text snippet is manually labeled by financial analysts for high accuracy." },
      { q: "Can this help with trading?", a: "Sentiment is a powerful indicator that can be used to inform crypto trading strategies." },
      { q: "Does it cover altcoins?", a: "Yes, while Bitcoin and Ethereum are prominent, the dataset also includes sentiment on dozens of popular altcoins." },
    ]
  },
  {
    id: 'health-007',
    name: 'Food Image Nutrition Recognition',
    domain: 'Health',
    description: 'A large dataset of food images labeled with their nutritional information (calories, protein, carbs, fat).',
    price: 150,
    size: 'N/A',
    tags: ['health', 'computer vision', 'nutrition', 'images'],
    previewText: [
      { q: "Can I build an app that counts calories from a photo?", a: "Yes! This is the perfect dataset for training a computer vision model to recognize food and estimate its nutrition." },
      { q: "How many food items are included?", a: "Contains over 5,000 common food items with multiple images for each." },
      { q: "Is the nutritional data accurate?", a: "The data is sourced from verified nutritional databases." },
      { q: "What kind of images are they?", a: "The dataset includes images of single ingredients, plated meals, and packaged foods." },
      { q: "Can this power a diet tracking app?", a: "This is the core technology for a next-generation, AI-powered diet and nutrition tracker." },
    ]
  },
  {
    id: 'prod-004',
    name: 'Automated Code Documentation Generator',
    domain: 'Productivity',
    description: 'A dataset of Python functions and their corresponding human-written docstrings.',
    price: 95,
    size: 'N/A',
    tags: ['productivity', 'software development', 'code generation', 'nlp'],
    previewText: [
      { q: "Can I train an AI to write documentation for my code?", a: "Yes, fine-tune a large language model on this data to automatically generate docstrings for functions." },
      { q: "What kind of functions are included?", a: "A wide variety of functions, from simple utility scripts to complex algorithms." },
      { q: "Are the docstrings high-quality?", a: "Yes, they follow the standard PEP 257 format and are written clearly and concisely." },
      { q: "How does this help developers?", a: "It saves a significant amount of time on a crucial but often tedious task." },
      { q: "Does it support other languages?", a: "This version is for Python. Datasets for JavaScript and Java are in development." },
    ]
  },
  {
    id: 'mktg-004',
    name: 'Product Description Generation Data',
    domain: 'Marketing',
    description: 'A dataset of product features and their corresponding professionally written, persuasive product descriptions.',
    price: 75,
    size: 'N/A',
    tags: ['marketing', 'copywriting', 'nlp', 'e-commerce'],
    previewText: [
      { q: "Can an AI write my product descriptions for me?", a: "Yes, use this data to fine-tune a language model to generate compelling descriptions from a list of features." },
      { q: "What kind of products are included?", a: "Covers a range of products from consumer electronics to fashion and home goods." },
      { q: "What makes a description 'persuasive'?", a: "The descriptions use proven copywriting techniques to highlight benefits, not just features." },
      { q: "Can this help with SEO?", a: "The data includes examples of descriptions optimized with relevant keywords." },
      { q: "How much time can this save?", a: "It can reduce the time it takes to write high-quality product copy from hours to minutes." },
    ]
  },
  {
    id: 'fin-008',
    name: 'Corporate Financial Statements',
    domain: 'Finance',
    description: 'A structured dataset of quarterly and annual financial statements (income, balance sheet, cash flow) from public companies.',
    price: 135,
    size: 'N/A',
    tags: ['finance', 'investment', 'analytics', 'accounting'],
    previewText: [
      { q: "How can I analyze a company's financial health?", a: "Use this structured data to calculate key financial ratios and compare performance across companies." },
      { q: "What companies are included?", a: "Includes data from over 500 companies across various sectors in the S&P 500." },
      { q: "Is the data easy to work with?", a: "Yes, unlike raw SEC filings, this data is cleaned and structured in a simple JSON format." },
      { q: "Can this be used for stock valuation?", a: "This is the essential raw data needed for building discounted cash flow (DCF) and other valuation models." },
      { q: "Is historical data included?", a: "The dataset contains 5 years of historical financial statements for trend analysis." },
    ]
  },
  {
    id: 'health-008',
    name: 'Hospital Performance Metrics',
    domain: 'Health',
    description: 'A dataset of US hospital performance metrics, including readmission rates, patient satisfaction scores, and procedure costs.',
    price: 80,
    size: 'N/A',
    tags: ['health', 'analytics', 'healthcare management', 'data'],
    previewText: [
      { q: "How can I compare the quality of different hospitals?", a: "Analyze key performance indicators to see which hospitals have the best patient outcomes and satisfaction." },
      { q: "Is the data from a reliable source?", a: "The data is compiled from public reports from the Centers for Medicare & Medicaid Services (CMS)." },
      { q: "What can this data be used for?", a: "It's valuable for healthcare consultants, researchers, and patients looking to make informed decisions." },
      { q: "Does it include pricing information?", a: "Yes, it includes the average cost of common procedures for each hospital." },
      { q: "Can this help improve hospital operations?", a: "Yes, by benchmarking performance against peers, hospitals can identify areas for improvement." },
    ]
  },
   {
    id: 'support-004',
    name: 'FAQ & Knowledge Base Auto-Generator',
    domain: 'Customer Support',
    description: 'A dataset of common customer support tickets and their ideal, human-written FAQ answers.',
    price: 55,
    size: 'N/A',
    tags: ['customer support', 'automation', 'nlp', 'knowledge base'],
    previewText: [
      { q: "How can I create a helpful FAQ page quickly?", a: "Train a model to turn common customer questions into a structured, easy-to-read knowledge base." },
      { q: "What kind of questions are included?", a: "Covers the most frequent questions related to billing, account management, and product features." },
      { q: "Are the answers well-written?", a: "Yes, they are written by professional technical writers to be clear, concise, and helpful." },
      { q: "Can this reduce my support workload?", a: "A good knowledge base empowers customers to find their own answers, significantly reducing support tickets." },
      { q: "Does this help with SEO?", a: "A comprehensive FAQ page can rank in search engines, attracting new users who are looking for solutions." },
    ]
  },
  {
    id: 'edu-005',
    name: 'Student Performance Predictor Data',
    domain: 'Education',
    description: 'Anonymized student data including study habits, attendance, and past grades to predict final exam scores.',
    price: 70,
    size: 'N/A',
    tags: ['education', 'prediction', 'analytics', 'edutech'],
    previewText: [
      { q: "Can I predict which students are at risk of failing?", a: "Yes, build a model to identify students who may need extra support before it's too late." },
      { q: "What factors influence student success?", a: "Analyze the impact of factors like homework completion, class participation, and study time." },
      { q: "Is this data ethically sourced?", a: "The data is fully anonymized and synthetic, created for educational and research purposes." },
      { q: "Can this help teachers personalize their approach?", a: "Yes, by understanding individual student needs, teachers can provide more targeted support." },
      { q: "What machine learning models can I use?", a: "This dataset is well-suited for classification and regression models like Logistic Regression or Gradient Boosting." },
    ]
  },
  {
    id: 'mktg-005',
    name: 'Brand Sentiment Tracker Data',
    domain: 'Marketing',
    description: 'A dataset of news articles and social media posts about major brands, labeled with sentiment and key topics.',
    price: 90,
    size: 'N/A',
    tags: ['marketing', 'brand management', 'sentiment analysis', 'pr'],
    previewText: [
      { q: "How is my brand perceived online?", a: "Analyze sentiment to understand public opinion and track your brand's reputation over time." },
      { q: "Can I track my competitors' brands too?", a: "Yes, the dataset includes data for multiple brands in several key industries for competitive analysis." },
      { q: "What topics are people talking about in relation to my brand?", a: "The data is tagged with topics like 'Customer Service', 'Product Quality', or 'Ethical Concerns'." },
      { q: "How can this help with crisis management?", a: "By detecting negative sentiment spikes early, you can respond to PR issues before they escalate." },
      { q: "Can this measure the impact of a marketing campaign?", a: "Yes, you can track sentiment before, during, and after a campaign to measure its effect on brand perception." },
    ]
  },
  {
    id: 'legal-005',
    name: 'E-Discovery Document Classifier',
    domain: 'Legal',
    description: 'A large set of emails and documents labeled as "relevant" or "not relevant" to a legal case.',
    price: 140,
    size: 'N/A',
    tags: ['legal', 'e-discovery', 'classification', 'litigation'],
    previewText: [
      { q: "How can AI speed up document review in a lawsuit?", a: "Train a model to do a 'first pass' review, automatically identifying documents that are likely to be relevant." },
      { q: "How much time can this save?", a: "It can reduce the number of documents human lawyers need to review by over 80%, saving thousands of hours." },
      { q: "What kind of documents are included?", a: "Anonymized emails, memos, and reports typical of corporate litigation." },
      { q: "Is this technology court-approved?", a: "Yes, Technology-Assisted Review (TAR) is widely accepted in the legal industry." },
      { q: "Is the data labeled by experts?", a: "All documents were labeled by experienced paralegals and attorneys." },
    ]
  },
   {
    id: 'self-004',
    name: 'Stoic Philosophy Q&A',
    domain: 'Self-Help',
    description: 'A dataset of questions and answers based on the writings of Stoic philosophers like Marcus Aurelius, Seneca, and Epictetus.',
    price: 12,
    size: 'N/A',
    tags: ['self-help', 'philosophy', 'stoicism', 'q&a'],
    previewText: [
      { q: "How can I apply Stoic wisdom to my modern life?", a: "Get clear, actionable answers to questions about handling anxiety, adversity, and emotions." },
      { q: "Can I build a philosophy chatbot with this?", a: "Yes, this is perfect for creating an AI mentor that provides Stoic advice." },
      { q: "Are the answers direct quotes?", a: "They are interpretations of Stoic teachings, translated into modern, easy-to-understand language." },
      { q: "What topics does it cover?", a: "Covers key Stoic concepts like the 'dichotomy of control', 'memento mori', and the 'view from above'." },
      { q: "Is this for philosophy experts?", a: "No, it's designed to make ancient wisdom accessible and practical for everyone." },
    ]
  },
  {
    id: 'fitness-003',
    name: 'Running & Cycling Route Generator Data',
    domain: 'Fitness',
    description: 'A dataset of popular running and cycling routes, including distance, elevation gain, and user ratings.',
    price: 30,
    size: 'N/A',
    tags: ['fitness', 'running', 'cycling', 'maps'],
    previewText: [
      { q: "How can I find the best running routes near me?", a: "Use this data to build a tool that suggests routes based on a user's desired distance and difficulty." },
      { q: "What data is included for each route?", a: "Each route has a map polyline, distance, elevation profile, and user-submitted ratings and photos." },
      { q: "Are the routes safe?", a: "Routes are user-rated for safety and include tags like 'well-lit' or 'trail'." },
      { q: "Can this integrate with a map API?", a: "Yes, the polyline data can be easily overlaid on map services like Google Maps or Mapbox." },
      { q: "Does it work for both running and cycling?", a: "Yes, routes are tagged for suitability for both activities." },
    ]
  }
];

// Sort datasets by price ascending (null/undefined treated as 0)
allDatasets.sort((a, b) => {
  const priceA = typeof a.price === 'number' ? a.price : 0;
  const priceB = typeof b.price === 'number' ? b.price : 0;
  return priceA - priceB;
}); 