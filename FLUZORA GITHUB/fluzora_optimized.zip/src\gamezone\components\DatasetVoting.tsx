'use client';
import React, { useState } from 'react';
import GlassCard from './ui/GlassCard';
import GlassButton from './ui/GlassButton';

const mockDatasets = [
  { id: 'd1', title: 'Genomics 2024', votes: 12 },
  { id: 'd2', title: 'Satellite Images', votes: 8 },
  { id: 'd3', title: 'Climate Data', votes: 5 },
];

export default function DatasetVoting() {
  const [datasets, setDatasets] = useState(mockDatasets);
  const vote = (id: string, delta: number) => {
    setDatasets(ds => ds.map(d => d.id === id ? { ...d, votes: d.votes + delta } : d));
  };
  return (
    <GlassCard className="mb-8">
      <div className="font-orbitron text-neon text-2xl mb-4">Dataset Voting</div>
      <ul className="space-y-4">
        {datasets.map(d => (
          <li key={d.id} className="flex items-center gap-4">
            <span className="font-orbitron text-white/90 flex-1">{d.title}</span>
            <GlassButton onClick={() => vote(d.id, 1)} aria-label={`Upvote ${d.title}`}>▲</GlassButton>
            <span className="font-orbitron text-neon w-8 text-center">{d.votes}</span>
            <GlassButton onClick={() => vote(d.id, -1)} aria-label={`Downvote ${d.title}`}>▼</GlassButton>
          </li>
        ))}
      </ul>
    </GlassCard>
  );
} 