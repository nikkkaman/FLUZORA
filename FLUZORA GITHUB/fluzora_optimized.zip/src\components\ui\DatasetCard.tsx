"use client";

import React, { useState, useEffect } from "react";
import {
  ShoppingCart,
  Eye,
  Star,
  FileJson,
  Database,
  Lock,
} from "lucide-react";

import { Button } from "./button";

type DatasetCardProps = {
  id: string;
  name: string;
  domain: string;
  description: string;
  size: string;
  price: number | null;
  onAddToCart: (id: string) => void;
  onPreview: (id: string) => void;
  // Deprecated/unused props - can be removed if not needed elsewhere
  accessLevel?: "Starter" | "Pro" | "Premium" | "Individual";
  badges?: string[];
  lastUpdated?: string;
  licenseType?: string;
  version?: string;
  isLocked?: boolean;
  isInCart?: boolean;
  aiPrompt?: string;
};

export function DatasetCard({
  id,
  name,
  domain,
  description,
  size,
  price,
  onAddToCart,
  onPreview,
  isInCart,
  isLocked,
}: DatasetCardProps) {

  const rating = 4.8; // This can be dynamic later
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!(window as any).Razorpay) {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  // Razorpay payment handler only for TEST DATA
  const handleBuyClick = async () => {
    if (id === 'ind-14') {
      try {
        const options = {
          key: "J0BnecRdCVwFKfeKyNPLzXlA",
          amount: 700, // ₹7 in paise
          currency: "INR",
          name: "FLUZORA",
          description: "Purchase TEST DATA dataset",
          handler: async function (response: any) {
            const webhookRes = await fetch("https://n8n.YOURDOMAIN.com/webhook/fluzora-unlock", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                email: "test@demo.com", // Replace with dynamic user input
                datasetKey: "TEST_DATA.json",
              }),
            });

            const data = await webhookRes.json();

            if (data.downloadUrl) {
              setDownloadUrl(data.downloadUrl);
              setPaymentSuccess(true);
            } else {
              setPaymentSuccess(true);
              alert("Payment successful. Check your email for the dataset link.");
            }
          },
          prefill: {
            name: "Demo User",
            email: "test@demo.com", // dynamic
          },
          theme: {
            color: "#3399cc"
          }
        };

        const rzp = new (window as any).Razorpay(options);
        rzp.open();
      } catch (err) {
        console.error("Payment failed:", err);
      }
    } else {
      onAddToCart(id);
    }
  };

  const handleDownload = () => {
    if (downloadUrl) {
      window.location.href = downloadUrl;
    } else {
      alert("Download link not available. Please check your email.");
    }
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-md rounded-xl border border-gray-700 p-6 flex flex-col justify-between shadow-lg hover:shadow-purple-500/20 transition-all duration-300 group hover:-translate-y-1 font-sans">
      {/* Header */}
      <div className="flex flex-col mb-4">
        <h3 className="text-xl font-bold text-gray-100 tracking-tight pr-4 mb-2 flex items-center gap-2">
          {name}
          {id === 'fin-001' && (
            <span className="ml-2 px-2 py-0.5 rounded bg-pink-600 text-white text-xs font-bold">TEST DEMO</span>
          )}
        </h3>
        <div className="flex justify-between items-center text-sm text-gray-400">
          <span className="bg-purple-900/50 text-purple-300 px-3 py-1 rounded-full text-xs font-semibold">{domain}</span>
          <div className="flex items-center gap-1">
            <span className="text-yellow-400">Rating:</span>
            <Star className="w-4 h-4 text-yellow-400 fill-current" />
            <span className="font-semibold text-white">{rating.toFixed(1)}</span>
          </div>
        </div>
      </div>

      {/* Description */}
      <p className="text-gray-400 mb-4 text-sm leading-relaxed italic">"{description}"</p>

      {/* Meta Info */}
      <div className="flex justify-between items-center text-gray-400 text-sm mb-4 border-t border-b border-gray-700/50 py-3">
        <div className="flex items-center gap-2">
          <FileJson className="w-4 h-4 text-purple-400" />
          <span>Format: CSV | JSON</span>
        </div>
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-purple-400" />
          <span>Size: {size}</span>
        </div>
      </div>
      
      {/* Price */}
      <div className="text-2xl font-bold text-white mb-4">
        {typeof price === 'number' ? (
          <span>${price.toFixed(2)}</span>
        ) : (
          <span className="text-green-400 text-base">Free</span>
        )}
      </div>

      {/* Footer Actions */}
      <div className="flex justify-between items-center mt-auto">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onPreview(id)}
          className="text-gray-300 border-gray-600 hover:bg-gray-700 hover:text-white flex-1 mr-2"
        >
          <Eye className="w-4 h-4 mr-2" />
          Preview
        </Button>
        {id === 'ind-14' ? (
          paymentSuccess ? (
            <button
              onClick={handleDownload}
              className="glass-button p-2 px-4 rounded-xl text-white flex-1 ml-2 bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
            >
              Download Dataset
            </button>
          ) : (
            <button
              onClick={handleBuyClick}
              className="glass-button p-2 px-4 rounded-xl text-white flex-1 ml-2 bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
              disabled={isLocked}
            >
              Buy Now – $7
            </button>
          )
        ) : (
          <Button
            variant={isInCart ? "secondary" : "default"}
            size="sm"
            onClick={handleBuyClick}
            className="flex items-center gap-2 bg-purple-600 text-white hover:bg-purple-500 transition-colors flex-1 ml-2"
            disabled={isLocked}
          >
            <ShoppingCart className="w-4 h-4" />
            {isInCart ? "In Cart" : "Add to Cart"}
          </Button>
        )}
      </div>
    </div>
  );
}
