"use client";
import React from "react";
import { motion } from "framer-motion";
import { FaBell, FaCheckCircle, FaCoins, FaUserAstronaut, FaFire } from "react-icons/fa";

const notifications = [
  { id: 1, type: "upload", text: "Upload approved! +120 FLZ", icon: <FaCheckCircle className="text-green-400" /> },
  { id: 2, type: "flz", text: "+50 FLZ for voting", icon: <FaCoins className="text-yellow-400" /> },
  { id: 3, type: "avatar", text: "Bought new avatar! -300 FLZ", icon: <FaUserAstronaut className="text-pink-400" /> },
  { id: 4, type: "streak", text: "5-day upload streak! +100 FLZ", icon: <FaFire className="text-orange-400" /> },
];

export default function NotificationsPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg flex items-center justify-center gap-2"><FaBell /> Notifications</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">See your latest GameZone activity: uploads, FLZ, avatars, and streaks. Stay up to date!</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full max-w-3xl flex flex-col gap-8"
      >
        {notifications.map((n, i) => (
          <motion.div
            key={n.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i, duration: 0.5 }}
            className="glassmorphic p-6 rounded-2xl shadow-lg flex items-center gap-4 border border-neon"
          >
            <div className="text-2xl">{n.icon}</div>
            <div className="font-inter text-white/80 text-lg">{n.text}</div>
          </motion.div>
        ))}
      </motion.div>
    </main>
  );
} 