"use client";
import React from "react";
import { motion } from "framer-motion";

const leaderboard = [
  { id: 1, name: "DataNinja", avatar: "/default-avatar.svg", flz: 1250, uploads: 12 },
  { id: 2, name: "QuantumQueen", avatar: "/default-avatar.svg", flz: 1100, uploads: 10 },
  { id: 3, name: "StatSamurai", avatar: "/default-avatar.svg", flz: 950, uploads: 8 },
  { id: 4, name: "AIronMan", avatar: "/default-avatar.svg", flz: 800, uploads: 7 },
  { id: 5, name: "PixelGuru", avatar: "/default-avatar.svg", flz: 700, uploads: 6 },
];

export default function LeaderboardPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg">Leaderboard</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">See the top contributors, their FLZ earnings, and uploads. Compete for the top spot and earn exclusive badges!</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full max-w-3xl"
      >
        <table className="min-w-full text-left rounded-2xl overflow-hidden bg-black/60 border-2 border-purple-500/20">
          <thead>
            <tr className="text-neon font-orbitron text-lg">
              <th className="py-3 px-4">#</th>
              <th className="py-3 px-4">Avatar</th>
              <th className="py-3 px-4">Name</th>
              <th className="py-3 px-4">FLZ</th>
              <th className="py-3 px-4">Uploads</th>
            </tr>
          </thead>
          <tbody>
            {leaderboard.map((u, i) => (
              <motion.tr
                key={u.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i, duration: 0.4 }}
                className={`border-b border-white/10 ${i < 3 ? "bg-neon/10" : ""}`}
              >
                <td className="py-2 px-4 font-bold font-orbitron text-xl">{i + 1}</td>
                <td className="py-2 px-4"><img src={u.avatar} alt={u.name} className="w-10 h-10 rounded-full border-2 border-neon" /></td>
                <td className="py-2 px-4 font-orbitron text-white/90">{u.name}</td>
                <td className="py-2 px-4 text-neon font-bold">{u.flz}</td>
                <td className="py-2 px-4 text-white/80">{u.uploads}</td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </main>
  );
} 