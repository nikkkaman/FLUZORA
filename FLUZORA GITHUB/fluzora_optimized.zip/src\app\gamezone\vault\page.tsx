"use client";
import React from "react";
import { motion } from "framer-motion";
import { FaDatabase, FaCoins, FaEye } from "react-icons/fa";

const datasets = [
  { id: 1, title: "Genomics 2024", price: 500, preview: "5,000 rows, 12 columns" },
  { id: 2, title: "Satellite Images", price: 700, preview: "2,000 images, 256x256" },
  { id: 3, title: "Finance QA", price: 350, preview: "1,200 Q&A pairs" },
  { id: 4, title: "Medical QA", price: 400, preview: "1,000 Q&A pairs" },
];

export default function VaultPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg">Vault</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">Redeem your FLZ tokens for premium, curated datasets. Preview before you unlock!</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full max-w-4xl grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-8"
      >
        {datasets.map((d, i) => (
          <motion.div
            key={d.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i, duration: 0.5 }}
            className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col gap-3 border border-blue-900"
          >
            <div className="flex items-center gap-2 mb-2">
              <FaDatabase className="text-blue-400 text-2xl" />
              <span className="font-orbitron text-xl text-neon">{d.title}</span>
            </div>
            <div className="font-inter text-white/80 mb-2">{d.preview}</div>
            <div className="flex items-center gap-2 text-yellow-400 font-bold font-orbitron mb-2">
              <FaCoins /> {d.price} FLZ
            </div>
            <button className="mt-auto px-4 py-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 text-white font-orbitron font-bold shadow-lg hover:scale-105 transition-all">Redeem</button>
            <button className="mt-2 px-4 py-2 rounded-lg bg-black/30 border border-blue-400 text-blue-300 font-inter flex items-center gap-2 hover:bg-blue-900/30 transition-all"><FaEye /> Preview</button>
          </motion.div>
        ))}
      </motion.div>
    </main>
  );
} 