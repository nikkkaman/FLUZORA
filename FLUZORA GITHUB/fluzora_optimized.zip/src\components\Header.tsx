"use client";

import React, { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/context/AuthContext";
import { Menu, X, ChevronDown, LogOut, User, ShoppingCart } from "lucide-react";
import { Dataset } from '@/hooks/useDatasets';

type CartHeaderProps = {
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  cartDatasets: Dataset[];
  totalPrice: number;
  handleRemoveFromCart: (id: string) => void;
  handleBuyNow: () => void;
  cartCount: number;
};

export default function Header(props: CartHeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const router = useRouter();

  // Move navigation array here and use pathname
  const navLinks = [
    { name: "Datasets", path: "/datasets" },
    { name: "Learn to Build AI", path: "/learn-agents" },
    { name: "GameZone", path: "/gamezone/home" },
    { name: "About Fluzora", path: "/about" },
  ];

  const isActive = (path: string) => pathname === path;

  // Navigation click handler: if not logged in, or if on landing page and requireLogin, redirect to /login
  const handleNavClick = (href: string, e: React.MouseEvent, requireLogin?: boolean) => {
    if (
      (!user && href !== "/login") ||
      (pathname === "/" && requireLogin)
    ) {
      e.preventDefault();
      router.push("/login");
    }
  };

  // Hide header on /login and /signup
  if (["/login", "/signup"].includes(pathname)) return null;

  // Framer Motion entrance
  const headerVariants = {
    hidden: { y: -64, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: "spring" as const, stiffness: 80, damping: 18 } },
  };

  // Theme colors
  const bg = "bg-gradient-to-r from-purple-900 via-black to-black";
  const logoGlow = "text-4xl font-orbitron text-white drop-shadow-[0_0_8px_rgba(168,85,247,0.7)] tracking-wide select-none";
  const navLinkBase = "px-4 py-2 rounded-md text-base font-medium transition-colors duration-150";
  const navLinkActive = "text-purple-300 bg-white/10 shadow-inner";
  const navLinkDisabled = "text-gray-400 cursor-not-allowed opacity-60 relative";
  const navLinkGlow = "hover:text-purple-200 hover:bg-purple-800/30 focus:text-purple-200 focus:bg-purple-800/30";

  // Mobile nav
  const mobileNavVariants = {
    closed: { x: "100%", opacity: 0 },
    open: { x: 0, opacity: 1, transition: { type: "spring" as const, stiffness: 80, damping: 18 } },
  };

  return (
    <AnimatePresence>
      <motion.header
        className={`sticky top-0 left-0 right-0 z-50 w-full h-16 ${bg} border-b border-purple-800/40 flex items-center`}
        initial="hidden"
        animate="visible"
        exit="hidden"
        variants={headerVariants}
        style={{ minHeight: 64 }}
      >
        <div className="max-w-7xl w-full mx-auto flex items-center justify-between px-4 md:px-8 h-full">
          {/* Left: Logo */}
          <Link href="/" className="flex items-center gap-2" style={{ fontFamily: 'Orbitron, Inter, sans-serif', letterSpacing: '0.07em' }}>
            <span className={logoGlow}>FLUZORA</span>
          </Link>

          {/* Center: Nav */}
          <nav className="hidden md:flex gap-2 items-center flex-1 justify-center">
            {navLinks.map((item) => (
              <Link
                key={item.name}
                href={item.path}
                onClick={e => handleNavClick(item.path, e)}
                className={`${navLinkBase} ${navLinkGlow} ${isActive(item.path) ? navLinkActive : "text-white/90"}`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Right: Profile and Cart */}
          <div className="flex items-center gap-3 ml-auto">
            {/* Cart Icon */}
            {pathname !== "/lora" && (
              <div className="relative flex items-center">
                <button
                  className="relative p-2 rounded-full bg-purple-800 hover:bg-purple-700 transition-colors"
                  onClick={() => props.setCartOpen(!props.cartOpen)}
                  aria-label="View Cart"
                >
                  <ShoppingCart className="w-6 h-6 text-white" />
                  {props.cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 border-2 border-black">
                      {props.cartCount}
                    </span>
                  )}
                </button>
                {props.cartOpen && (
                  <div className="absolute right-0 mt-2 w-80 bg-black border border-purple-800 rounded-xl shadow-lg py-4 px-4 animate-fade-in z-50">
                    <h3 className="text-lg font-semibold text-white mb-2">Cart</h3>
                    {props.cartDatasets.length === 0 ? (
                      <div className="text-gray-400">No datasets in cart.</div>
                    ) : (
                      <ul className="mb-4 max-h-56 overflow-y-auto">
                        {props.cartDatasets.map((d) => (
                          <li key={d.id} className="flex justify-between items-center py-2 border-b border-gray-800 last:border-b-0">
                            <span className="text-white text-sm">{d.name}</span>
                            <span className="text-gray-300 text-sm">${d.price?.toFixed(2) || 0}</span>
                            <button className="ml-2 text-xs text-red-400 hover:underline" onClick={() => props.handleRemoveFromCart(d.id)}>Remove</button>
                          </li>
                        ))}
                      </ul>
                    )}
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-white font-semibold">Total:</span>
                      <span className="text-pink-400 font-bold text-lg">${props.totalPrice.toFixed(2)}</span>
                    </div>
                    <button
                      className="w-full py-2 rounded-md bg-pink-600 hover:bg-pink-700 text-white font-semibold text-lg transition-colors"
                      onClick={props.handleBuyNow}
                      disabled={props.cartDatasets.length === 0}
                    >
                      Buy Now
                    </button>
                  </div>
                )}
              </div>
            )}
            {/* Profile Icon */}
            <div className="relative flex items-center">
              <button
                className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold"
                onClick={() => setProfileMenuOpen((v) => !v)}
                aria-label="Profile menu"
                type="button"
              >
                A
              </button>
              <AnimatePresence>
                {profileMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.18 }}
                    className="absolute right-0 top-full mt-2 w-48 bg-black border border-gray-700 rounded-lg shadow-lg py-1"
                  >
                    <Link href="/dashboard" className="block px-5 py-3 text-sm text-white hover:bg-purple-900/40 transition-colors">Dashboard</Link>
                    <Link href="/settings" className="block px-5 py-3 text-sm text-white hover:bg-purple-900/40 transition-colors">Settings</Link>
                    <Link href="/billing" className="block px-5 py-3 text-sm text-white hover:bg-purple-900/40 transition-colors">Billing</Link>
                    <Link href="/support" className="block px-5 py-3 text-sm text-white hover:bg-purple-900/40 transition-colors">Support</Link>
                    <button onClick={logout} className="block w-full text-left px-5 py-3 text-sm text-red-400 hover:bg-purple-900/40 transition-colors">Log Out</button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            {/* Hamburger for mobile */}
            <button className="md:hidden ml-2 p-2 rounded hover:bg-purple-800/30" onClick={() => setMobileMenuOpen((v) => !v)}>
              {mobileMenuOpen ? <X className="w-6 h-6 text-purple-200" /> : <Menu className="w-6 h-6 text-purple-200" />}
            </button>
          </div>
        </div>
        {/* Mobile Nav */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.nav
              initial="closed"
              animate="open"
              exit="closed"
              variants={mobileNavVariants}
              className="fixed top-0 right-0 w-64 h-full bg-gradient-to-br from-black via-purple-950 to-black z-50 shadow-2xl flex flex-col pt-20 px-6 gap-4"
            >
              {navLinks.map((item) => (
                <Link
                  key={item.name}
                  href={item.path}
                  className={`${navLinkBase} ${navLinkGlow} ${isActive(item.path) ? navLinkActive : "text-white/90"}`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
            </motion.nav>
          )}
        </AnimatePresence>
      </motion.header>
    </AnimatePresence>
  );
}

export function HomeHeader() {
  const pathname = usePathname();
  if (pathname !== "/home") return null;

  const navItems = [
    { name: "Datasets", href: "/datasets" },
    { name: "GameZone", href: "/gamezone" },
    { name: "Learn to Build AI", href: "/learn-agents" },
    { name: "About Fluzora", href: "/about" },
  ];

  const logoGlow = "text-4xl font-orbitron text-white drop-shadow-[0_0_8px_rgba(168,85,247,0.7)] tracking-wide select-none";

  // Profile dropdown state
  const [profileOpen, setProfileOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 border-b border-white/20 shadow-sm">
      <nav className="max-w-7xl mx-auto px-6 py-2 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2" style={{ fontFamily: 'Orbitron, Inter, sans-serif', letterSpacing: '0.07em' }}>
          <span className={logoGlow}>FLUZORA</span>
        </Link>
        {/* Navigation */}
        <div className="hidden md:flex items-center gap-8 flex-1 justify-center">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="text-white/80 hover:text-white transition-colors"
            >
              {item.name}
            </Link>
          ))}
        </div>
        {/* Profile */}
        <div className="relative">
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center text-white font-bold"
          >
            A
          </button>
          {profileOpen && (
            <div className="absolute right-0 mt-12 w-48 bg-black border border-gray-700 rounded-lg shadow-lg py-1">
              <Link href="/dashboard" className="block px-4 py-2 text-sm text-white hover:bg-gray-800">Dashboard</Link>
              <Link href="/settings" className="block px-4 py-2 text-sm text-white hover:bg-gray-800">Settings</Link>
              <Link href="/billing" className="block px-4 py-2 text-sm text-white hover:bg-gray-800">Billing</Link>
              <button className="block w-full text-left px-4 py-2 text-sm text-red-500 hover:bg-gray-800">Logout</button>
            </div>
          )}
        </div>
      </nav>
    </header>
  );
}
