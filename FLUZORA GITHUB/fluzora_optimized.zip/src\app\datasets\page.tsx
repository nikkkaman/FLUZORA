"use client";

import React, { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { DatasetCard } from "@/components/ui/DatasetCard";
import { PreviewModal } from "@/components/ui/PreviewModal";
import { useDatasets, Dataset } from "@/hooks/useDatasets";
import { useCart } from "@/hooks/useCart";
import { usePreview } from "@/hooks/usePreview";
import { Cart } from "@/components/ui/Cart";
import { DatasetTabs } from "@/components/ui/DatasetTabs";
import { RequestDatasetModal } from "@/components/ui/RequestDatasetModal";
import Header from "@/components/Header";
import { FaSearch } from "react-icons/fa";
import classNames from "classnames";
import debounce from "lodash.debounce";
import { Skeleton } from "@/components/ui/skeleton";
import { ChevronUp } from "lucide-react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";

const purchasedPack: 'starter' | 'pro' | 'premium' | null = null;

export default function DatasetsPage() {
  const [activeTab, setActiveTab] = useState("individual");
  const datasets = useDatasets(activeTab);
  const [search, setSearch] = useState("");
  const [suggestions, setSuggestions] = useState<Dataset[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredDatasets, setFilteredDatasets] = useState<Dataset[]>(datasets);
  const [loading, setLoading] = useState(true);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [showBackToTop, setShowBackToTop] = useState(false);

  const allDatasets = useDatasets('all');

  const {
    cart,
    cartOpen,
    setCartOpen,
    handleAddToCart,
    handleRemoveFromCart,
    cartDatasets,
    totalPrice,
  } = useCart(allDatasets);

  const { previewDataset, handlePreview, closePreview } = usePreview(allDatasets);
  
  const [isRequestModalOpen, setRequestModalOpen] = useState(false);

  const router = useRouter();

  function smartMatch(dataset: Dataset, query: string) {
    if (!query) return true;
    const q = query.toLowerCase();
    const fields = [dataset.name, dataset.domain, dataset.description, ...(dataset.tags || [])];
    return fields.some(f =>
      f &&
      f.toLowerCase().includes(q)
    );
  }

  const debouncedSearch = useMemo(() => debounce((q: string) => {
    if (!q) {
      setFilteredDatasets(datasets);
      setSuggestions([]);
      return;
    }
    const filtered = datasets.filter(ds => smartMatch(ds, q));
    setFilteredDatasets(filtered);
    const sugg = allDatasets.filter(ds => smartMatch(ds, q)).slice(0, 6);
    setSuggestions(sugg);
  }, 200), [datasets, allDatasets]);

  useEffect(() => {
    debouncedSearch(search);
    return () => debouncedSearch.cancel();
  }, [search, datasets, allDatasets]);

  useEffect(() => {
    setFilteredDatasets(datasets);
  }, [datasets]);

  useEffect(() => {
    setLoading(true);
    const timeout = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timeout);
  }, []);

  useEffect(() => {
    const onScroll = () => setShowBackToTop(window.scrollY > 400);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      setShowSuggestions(false);
      debouncedSearch.flush();
    }
  }

  const handleBuyNow = () => {
    window.location.href = "https://rzp.io/l/testpayment";
  };
  
  const handleRequestSubmit = (request: string) => {
    alert(`Your request for "${request}" has been submitted!`);
  };

  // Extract all unique tags from allDatasets
  const allTags = useMemo(() => {
    const tags = new Set<string>();
    allDatasets.forEach(ds => (ds.tags || []).forEach(tag => tags.add(tag)));
    return Array.from(tags).sort();
  }, [allDatasets]);

  // Filter datasets by tag if selected
  const visibleDatasets = useMemo(() => {
    if (!selectedTag) return filteredDatasets;
    return filteredDatasets.filter(ds => ds.tags && ds.tags.includes(selectedTag));
  }, [filteredDatasets, selectedTag]);

  const handleBackToTop = () => window.scrollTo({ top: 0, behavior: 'smooth' });

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-black">
      <button
        onClick={() => router.back()}
        className="absolute left-8 top-20 flex items-center gap-2 px-3 py-2 rounded-full bg-transparent border border-white/30 hover:bg-white/10 hover:border-white/80 text-white transition shadow"
        style={{ zIndex: 10 }}
        aria-label="Back"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="hidden md:inline">Back</span>
      </button>
      <Header
        cartOpen={cartOpen}
        setCartOpen={setCartOpen}
        cartDatasets={cartDatasets}
        totalPrice={totalPrice}
        handleRemoveFromCart={handleRemoveFromCart}
        handleBuyNow={handleBuyNow}
        cartCount={cart.length}
      />
      <div className="container mx-auto px-4 py-20">
        <DatasetTabs activeTab={activeTab} setActiveTab={setActiveTab} />
        {/* Tag Filters */}
        <div className="flex flex-wrap gap-2 mb-8">
          {allTags.map(tag => (
            <button
              key={tag}
              className={`px-4 py-2 rounded-full border font-semibold transition-all duration-150 ${selectedTag === tag ? 'bg-purple-600 text-white border-purple-700 scale-105 shadow-lg' : 'bg-black/40 text-purple-200 border-purple-700 hover:bg-purple-700/40 hover:text-white'}`}
              onClick={() => setSelectedTag(tag)}
            >
              {tag}
            </button>
          ))}
          {selectedTag && (
            <button
              className="px-4 py-2 rounded-full border border-gray-500 bg-gray-700 text-white font-semibold ml-2 hover:bg-gray-600 transition-all duration-150"
              onClick={() => setSelectedTag(null)}
            >
              Clear Filter
            </button>
          )}
        </div>
        <div className="relative w-full max-w-2xl mx-auto mb-10">
          <div
            className={classNames(
              "flex items-center w-full bg-black/70 border border-purple-700 rounded-xl px-5 py-4 shadow-lg transition-all",
              {
                "ring-2 ring-purple-400 shadow-purple-500/40": showSuggestions,
                "shadow-purple-900/30": !showSuggestions,
              }
            )}
          >
            <FaSearch className="text-purple-400 mr-3 text-lg" />
            <input
              type="text"
              className="flex-1 bg-transparent outline-none text-white placeholder-gray-400 text-lg"
              placeholder="Search datasets by name, tag, or keyword…"
              value={search}
              onChange={e => {
                setSearch(e.target.value);
                setShowSuggestions(true);
              }}
              onFocus={() => setShowSuggestions(true)}
              onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
              onKeyDown={handleKeyDown}
              aria-label="Search datasets by name, tag, or keyword"
            />
          </div>
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute left-0 right-0 mt-2 bg-black/90 border border-purple-700 rounded-xl shadow-xl z-20">
              {suggestions.map(ds => (
                <button
                  key={ds.id}
                  className="w-full text-left px-5 py-3 hover:bg-purple-900/60 text-white transition-colors rounded-xl"
                  onMouseDown={() => {
                    setSearch(ds.name);
                    setShowSuggestions(false);
                    setFilteredDatasets(datasets.filter(d => d.id === ds.id));
                  }}
                >
                  <span className="font-semibold text-purple-300">{ds.name}</span>
                  <span className="ml-2 text-gray-400 text-sm">{ds.domain}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            [...Array(6)].map((_, i) => <Skeleton key={i} className="h-64 w-full" />)
          ) : visibleDatasets.length === 0 ? (
            <div className="col-span-full text-center text-gray-400">
              Can't find what you're looking for?{" "}
              <button
                className="text-purple-400 underline"
                onClick={() => setRequestModalOpen(true)}
              >
                Request a Dataset
              </button>
            </div>
          ) : (
            visibleDatasets.map((dataset) => (
              <DatasetCard
                key={dataset.id}
                id={dataset.id}
                name={dataset.name}
                domain={dataset.domain}
                description={dataset.description}
                size={dataset.size}
                price={dataset.price}
                accessLevel={
                  dataset.pack
                    ? (dataset.pack.charAt(0).toUpperCase() + dataset.pack.slice(1)) as "Starter" | "Pro" | "Premium"
                    : "Individual"
                }
                badges={dataset.badges || []}
                lastUpdated={dataset.lastUpdated || "N/A"}
                licenseType={dataset.licenseType || "N/A"}
                version={dataset.version || "v1.0"}
                isLocked={
                  activeTab === "subscription"
                    ? !purchasedPack || dataset.pack !== purchasedPack
                    : false
                }
                isInCart={cart.includes(dataset.id)}
                onAddToCart={handleAddToCart}
                onPreview={handlePreview}
                aiPrompt={dataset.aiPrompt || "Use this dataset to build AI models."}
              />
            ))
          )}
        </div>

        {!loading && allDatasets.length > 3 && (
          <div className="mt-16">
            <h2 className="text-xl font-bold text-white mb-4">You Might Like</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {allDatasets.slice(0, 3).map((dataset) => (
                <DatasetCard
                  key={dataset.id}
                  id={dataset.id}
                  name={dataset.name}
                  domain={dataset.domain}
                  description={dataset.description}
                  size={dataset.size}
                  price={dataset.price}
                  accessLevel={
                    dataset.pack
                      ? (dataset.pack.charAt(0).toUpperCase() + dataset.pack.slice(1)) as "Starter" | "Pro" | "Premium"
                      : "Individual"
                  }
                  badges={dataset.badges || []}
                  lastUpdated={dataset.lastUpdated || "N/A"}
                  licenseType={dataset.licenseType || "N/A"}
                  version={dataset.version || "v1.0"}
                  isLocked={
                    activeTab === "subscription"
                      ? !purchasedPack || dataset.pack !== purchasedPack
                      : false
                  }
                  isInCart={cart.includes(dataset.id)}
                  onAddToCart={handleAddToCart}
                  onPreview={handlePreview}
                  aiPrompt={dataset.aiPrompt || "Use this dataset to build AI models."}
                />
              ))}
            </div>
          </div>
        )}

        {previewDataset && (
          <PreviewModal
            isOpen={!!previewDataset}
            onClose={closePreview}
            dataset={previewDataset}
          />
        )}
        
        <RequestDatasetModal 
            isOpen={isRequestModalOpen}
            onClose={() => setRequestModalOpen(false)}
            onSubmit={handleRequestSubmit}
        />
      </div>
      {showBackToTop && (
        <button
          onClick={handleBackToTop}
          className="fixed bottom-8 right-8 z-50 p-3 rounded-full bg-purple-700/80 hover:bg-purple-800 text-white shadow-lg border-2 border-white/20 transition-all duration-200 animate-bounce"
          aria-label="Back to top"
        >
          <ChevronUp className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
