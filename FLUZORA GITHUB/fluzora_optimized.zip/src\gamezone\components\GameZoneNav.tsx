import React from 'react';
import { FaHome, FaTrophy, FaUpload, FaUser, FaDatabase, FaStore, FaFileAlt, FaCoins, FaChartLine } from 'react-icons/fa';
import Link from 'next/link';

const navItems = [
  { href: '/gamezone', icon: <FaHome />, label: 'Home' },
  { href: '/gamezone/challenges', icon: <FaTrophy />, label: 'Challenges' },
  { href: '/gamezone/leaderboard', icon: <FaChartLine />, label: 'Leaderboard' },
  { href: '/gamezone/vault', icon: <FaDatabase />, label: 'Vault' },
  { href: '/gamezone/shop', icon: <FaStore />, label: 'Shop' },
  { href: '/gamezone/dashboard', icon: <FaUser />, label: 'Dashboard' },
  { href: '/gamezone/billing', icon: <FaCoins />, label: 'Billing' },
  { href: '/gamezone/docs', icon: <FaFileAlt />, label: 'Docs' },
];

export default function GameZoneNav() {
  return (
    <aside className="hidden md:flex flex-col w-56 min-h-full py-8 px-4 glassmorphic border-r border-white/10">
      <nav className="flex flex-col gap-4">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href} className="flex items-center gap-3 px-4 py-2 rounded-lg hover:bg-white/10 focus:bg-white/20 focus:outline-none transition-all text-lg font-inter text-white/80" aria-label={item.label}>
            <span className="text-xl">{item.icon}</span>
            <span className="font-orbitron tracking-wide">{item.label}</span>
          </Link>
        ))}
      </nav>
    </aside>
  );
} 