import React from 'react';
import Image from 'next/image';
import { FaGamepad } from 'react-icons/fa';

export default function GameZoneHeader() {
  return (
    <header className="w-full flex items-center justify-between px-6 py-4 glassmorphic border-b border-white/10">
      <div className="flex items-center gap-3">
        <span className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-tr from-blue-400 via-purple-500 to-pink-400 shadow-md">
          <FaGamepad className="text-white text-2xl" aria-label="GameZone Logo" />
        </span>
        <div className="flex flex-col">
          <span className="text-2xl md:text-3xl font-orbitron uppercase text-blue-200">GameZone</span>
          <span className="text-xs md:text-sm font-inter text-white/60 mt-1 tracking-wide">Gamified Data Hub</span>
        </div>
      </div>
      <nav className="hidden md:flex gap-6 text-lg font-inter">
        <a href="/gamezone" className="nav-link">Home</a>
        <a href="/gamezone/challenges" className="nav-link">Challenges</a>
        <a href="/gamezone/leaderboard" className="nav-link">Leaderboard</a>
        <a href="/gamezone/vault" className="nav-link">Vault</a>
        <a href="/gamezone/shop" className="nav-link">Shop</a>
        <a href="/gamezone/dashboard" className="nav-link">Dashboard</a>
        <a href="/gamezone/billing" className="nav-link">Billing</a>
        <a href="/gamezone/docs" className="nav-link">Docs</a>
      </nav>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full glassmorphic border border-white/20">
          <Image src="/default-avatar.svg" alt="User Avatar" width={32} height={32} className="rounded-full border-2 border-white/30" />
          <span className="font-bold text-white">1,250 FLZ</span>
        </div>
      </div>
    </header>
  );
} 