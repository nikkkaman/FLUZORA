"use client";
import React, { useState } from "react";
import { motion } from "framer-motion";
import { FaUsers, FaThumbsUp, FaReply, FaThumbtack } from "react-icons/fa";

const threads = [
  { id: 1, title: "Request: Medical QA Dataset", author: "DataNinja", replies: 3, likes: 12, pinned: true },
  { id: 2, title: "Report: Finance QA typo", author: "QuantumQueen", replies: 1, likes: 4, pinned: false },
  { id: 3, title: "Idea: Add leaderboard badges", author: "StatSamurai", replies: 2, likes: 7, pinned: false },
];

export default function CommunityPage() {
  const [liked, setLiked] = useState<number | null>(null);
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg">Community</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">Request datasets, report issues, and suggest ideas. Join the conversation and help shape GameZone!</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full max-w-3xl flex flex-col gap-8"
      >
        {threads.map((t, i) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i, duration: 0.5 }}
            className={`glassmorphic p-6 rounded-2xl shadow-lg flex flex-col gap-3 border ${t.pinned ? "border-yellow-400" : "border-blue-400"}`}
          >
            <div className="flex items-center gap-2 mb-2">
              <FaUsers className="text-cyan-400 text-2xl" />
              <span className="font-orbitron text-xl text-neon">{t.title}</span>
              {t.pinned && <FaThumbtack className="ml-auto text-yellow-400" title="Pinned" />}
            </div>
            <div className="font-inter text-white/80 mb-2">By {t.author}</div>
            <div className="flex items-center gap-4">
              <button onClick={() => setLiked(liked === t.id ? null : t.id)} className={`flex items-center gap-1 text-purple-400 hover:text-neon transition-all ${liked === t.id ? "font-bold" : ""}`}><FaThumbsUp /> {t.likes + (liked === t.id ? 1 : 0)}</button>
              <button className="flex items-center gap-1 text-blue-400 hover:text-neon transition-all"><FaReply /> {t.replies} Reply</button>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </main>
  );
} 