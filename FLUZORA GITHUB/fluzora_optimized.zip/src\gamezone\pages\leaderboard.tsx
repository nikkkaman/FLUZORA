import React from 'react';
import GameZoneLayout from '../layout/GameZoneLayout';
import { useGameZoneContext } from '../context/GameZoneContext';

const trophyColors = [
  'bg-gradient-to-r from-yellow-400 to-yellow-200',
  'bg-gradient-to-r from-gray-400 to-gray-200',
  'bg-gradient-to-r from-orange-400 to-orange-200',
];

export default function GameZoneLeaderboard() {
  const { leaderboard } = useGameZoneContext();
  return (
    <GameZoneLayout>
      <div className="mb-6">
        <a href="/gamezone" className="inline-block px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform">Back</a>
      </div>
      <h1 className="text-3xl font-orbitron text-neon mb-8">Leaderboard</h1>
      <div className="mb-4 text-white/60 font-inter">Top 10 contributors. Auto-refreshes every 30s.</div>
      <div className="glassmorphic p-6 rounded-2xl shadow-lg overflow-x-auto">
        <table className="min-w-full text-left">
          <thead>
            <tr className="text-neon font-orbitron text-lg">
              <th className="py-2">#</th>
              <th className="py-2">Avatar</th>
              <th className="py-2">Name</th>
              <th className="py-2">FLZ</th>
              <th className="py-2">Uploads</th>
            </tr>
          </thead>
          <tbody>
            {leaderboard.map((u: any, i: number) => (
              <tr key={u.id} className="border-b border-white/10 hover:bg-neon/5 transition-all">
                <td className="py-2 font-bold">
                  {i < 3 ? (
                    <span className={`inline-block w-8 h-8 rounded-full flex items-center justify-center animate-bounce ${trophyColors[i]}`}>🏆</span>
                  ) : (
                    <span>{i + 1}</span>
                  )}
                </td>
                <td className="py-2">
                  <img src={u.avatar} alt={u.name} className="w-10 h-10 rounded-full border-2 border-neon" />
                </td>
                <td className="py-2 font-orbitron text-white/90">{u.name}</td>
                <td className="py-2 text-neon font-bold">{u.flz}</td>
                <td className="py-2 text-white/80">{u.uploads}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </GameZoneLayout>
  );
} 