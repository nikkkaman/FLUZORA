"use client";
import React from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import Hero from "../components/Hero";
import { FaUpload, FaDatabase, FaChartLine, FaUserAstronaut, FaTrophy, FaGift, FaCoins, FaUsers, FaBook, FaBell, FaMedal, FaFire, FaStar, FaRegSmile } from "react-icons/fa";

const features = [
  {
    href: "/gamezone/upload",
    icon: <FaUpload className="text-neon text-3xl" />,
    title: "Upload",
    desc: "Contribute datasets and earn FLZ tokens. Quality and size matter!"
  },
  {
    href: "/gamezone/vault",
    icon: <FaDatabase className="text-blue-400 text-3xl" />,
    title: "Vault",
    desc: "Redeem FLZ for premium datasets. Preview before you unlock."
  },
  {
    href: "/gamezone/leaderboard",
    icon: <FaChartLine className="text-purple-400 text-3xl" />,
    title: "Leaderboard",
    desc: "See top contributors, streaks, and event winners."
  },
  {
    href: "/gamezone/avatars",
    icon: <FaUserAstronaut className="text-pink-400 text-3xl" />,
    title: "Avatars",
    desc: "Unlock and equip unique avatars with your FLZ."
  },
  {
    href: "/gamezone/challenges",
    icon: <FaTrophy className="text-yellow-400 text-3xl" />,
    title: "Challenges",
    desc: "Compete in themed events for bonus FLZ and badges."
  },
  {
    href: "/gamezone/rewards",
    icon: <FaGift className="text-green-400 text-3xl" />,
    title: "Rewards",
    desc: "Claim badges, streak bonuses, and referral rewards."
  },
  {
    href: "/gamezone/tokenomics",
    icon: <FaCoins className="text-orange-400 text-3xl" />,
    title: "Tokenomics",
    desc: "See live FLZ stats, mint/burn, and usage breakdown."
  },
  {
    href: "/gamezone/community",
    icon: <FaUsers className="text-cyan-400 text-3xl" />,
    title: "Community",
    desc: "Request datasets, report issues, and join discussions."
  },
  {
    href: "/gamezone/docs",
    icon: <FaBook className="text-blue-300 text-3xl" />,
    title: "Docs",
    desc: "Read GameZone rules, terms, and contribution policy."
  },
  {
    href: "/gamezone/notifications",
    icon: <FaBell className="text-pink-300 text-3xl" />,
    title: "Notifications",
    desc: "See upload approvals, FLZ earned, and milestones."
  },
];

const analytics = [
  { icon: <FaCoins className="text-yellow-400 text-2xl" />, label: "FLZ Minted", value: "1.2M" },
  { icon: <FaUpload className="text-blue-400 text-2xl" />, label: "Datasets Uploaded", value: "2,100+" },
  { icon: <FaUsers className="text-pink-400 text-2xl" />, label: "Contributors", value: "3,500+" },
  { icon: <FaTrophy className="text-purple-400 text-2xl" />, label: "Events Held", value: "24" },
];

const keyFeatures = [
  { icon: <FaMedal className="text-yellow-400 text-2xl" />, title: "Badge & Streak System", desc: "Earn badges and streak bonuses for consistent contributions." },
  { icon: <FaFire className="text-pink-500 text-2xl" />, title: "Live Events", desc: "Join weekly tournaments and bonus rounds for extra FLZ." },
  { icon: <FaStar className="text-blue-400 text-2xl" />, title: "Token Voting", desc: "Vote on datasets and earn FLZ for quality curation." },
  { icon: <FaRegSmile className="text-green-400 text-2xl" />, title: "Community Driven", desc: "Request, discuss, and improve datasets with the community." },
];

export default function GameZoneHome() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-black text-white flex flex-col">
      {/* Back to Main Button */}
      <div className="w-full flex justify-start px-4 pt-6">
        <Link href="/">
          <button className="px-6 py-2 rounded-full bg-white/10 border border-white/20 text-neon font-orbitron shadow-lg hover:bg-white/20 hover:scale-105 transition-all backdrop-blur-md">
            ← Back to Main
          </button>
        </Link>
      </div>
      {/* Hero Section */}
      <Hero />
      {/* Analytics Section */}
      <section className="py-10 bg-gradient-to-b from-black/60 to-purple-900/20 backdrop-blur-sm">
        <div className="max-w-5xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
          {analytics.map((a, i) => (
            <motion.div
              key={a.label}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 * i }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="bg-purple-900/30 rounded-xl p-6 flex flex-col items-center border border-purple-500/20 hover:border-purple-400/60 shadow-lg shadow-purple-500/10 hover:shadow-purple-500/20 transition-all duration-300"
            >
              <div className="mb-2">{a.icon}</div>
              <div className="text-3xl font-bold font-orbitron text-neon mb-1">{a.value}</div>
              <div className="text-lg font-inter text-purple-200">{a.label}</div>
            </motion.div>
          ))}
        </div>
      </section>
      {/* Features Grid Section */}
      <section className="py-16 px-4 w-full max-w-6xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-10 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 drop-shadow font-orbitron">GameZone Features</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * i }}
              whileHover={{ scale: 1.04, y: -5 }}
              className="bg-black/60 border-2 border-purple-500/20 hover:border-neon/80 rounded-2xl p-8 shadow-lg shadow-purple-500/10 hover:shadow-neon/20 transition-all duration-300 flex flex-col items-center text-center cursor-pointer backdrop-blur-md"
            >
              <Link href={feature.href} className="flex flex-col items-center gap-3 w-full h-full">
                {feature.icon}
                <span className="font-orbitron text-xl md:text-2xl text-neon mt-2 mb-1">{feature.title}</span>
                <span className="font-inter text-base text-white/80 text-center">{feature.desc}</span>
              </Link>
            </motion.div>
          ))}
        </div>
      </section>
      {/* Key Features Section */}
      <section className="py-16 bg-gradient-to-b from-purple-900/20 to-black/60 backdrop-blur-sm">
        <div className="max-w-5xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-10 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 drop-shadow font-orbitron">Why GameZone?</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
            {keyFeatures.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="bg-purple-900/30 rounded-xl p-6 flex flex-col items-center border border-purple-500/20 hover:border-purple-400/60 shadow-lg shadow-purple-500/10 hover:shadow-purple-500/20 transition-all duration-300"
              >
                <div className="mb-2">{f.icon}</div>
                <div className="text-xl font-bold font-orbitron text-neon mb-1">{f.title}</div>
                <div className="text-base font-inter text-purple-200 text-center">{f.desc}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
} 