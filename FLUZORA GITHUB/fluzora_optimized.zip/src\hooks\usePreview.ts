import { useState } from 'react';
import { Dataset } from './useDatasets';

export function usePreview(datasets: Dataset[]) {
  const [previewDataset, setPreviewDataset] = useState<Dataset | null>(null);

  const handlePreview = (id: string) => {
    const dataset = datasets.find((d) => d.id === id);
    if (dataset) {
      setPreviewDataset(dataset);
    }
  };

  const closePreview = () => {
    setPreviewDataset(null);
  };

  return {
    previewDataset,
    handlePreview,
    closePreview,
  };
} 