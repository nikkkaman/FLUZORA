import React from "react";
import Link from "next/link";
import { Trophy, UploadCloud, User, Sparkles, BarChart3, Star, Clock, Gift, BookOpen } from "lucide-react";

const orbitron = { fontFamily: "'Orbitron', Inter, sans-serif" };
const inter = { fontFamily: "'Inter', sans-serif" };

export default function GameZoneHeader() {
  return (
    <header className="relative z-50 w-full bg-slate-900/90 border-b border-purple-800/40 shadow-xl backdrop-blur-xl flex flex-col items-center">
      {/* Top Row: Logo + Nav + User */}
      <div className="w-full flex items-center justify-between px-6 md:px-16 h-20 relative z-10">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <Sparkles className="w-8 h-8 text-blue-400" />
          <span className="text-2xl md:text-3xl font-extrabold text-slate-100 tracking-wide font-display">
            GameZone
          </span>
        </div>
        {/* Navigation */}
        <nav className="flex items-center gap-6 md:gap-10 font-sans">
          <Link href="/gamezone/dashboard" className="flex items-center gap-2 text-slate-200 hover:text-blue-400 font-semibold transition text-lg">
            <BarChart3 className="w-5 h-5" /> Dashboard
          </Link>
          <Link href="/gamezone" className="flex items-center gap-2 text-slate-200 hover:text-blue-400 font-semibold transition text-lg">
            <UploadCloud className="w-5 h-5" /> Challenges
          </Link>
          <Link href="/gamezone#leaderboard" className="flex items-center gap-2 text-slate-200 hover:text-blue-400 font-semibold transition text-lg">
            <Trophy className="w-5 h-5" /> Leaderboard
          </Link>
          <Link href="/gamezone/documentation" className="flex items-center gap-2 text-blue-400 font-semibold transition text-lg underline underline-offset-2">
            <BookOpen className="w-5 h-5" /> Documentation
          </Link>
        </nav>
        {/* User avatar/stats (mocked) */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-100 font-bold text-lg border-2 border-blue-400">
            <User className="w-6 h-6" />
          </div>
          <div className="flex flex-col text-right">
            <span className="text-slate-100 font-semibold text-sm font-sans">You</span>
            <span className="text-blue-400 text-xs font-bold font-sans">340 FLZ</span>
          </div>
        </div>
      </div>
      {/* Feature Highlights Row */}
      <div className="w-full flex flex-wrap items-center justify-center gap-4 md:gap-8 py-2 md:py-3 relative z-10">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700">
          <UploadCloud className="w-5 h-5 text-blue-400" />
          <span className="text-slate-200 font-semibold text-xs md:text-sm font-sans">Earn FLZ Tokens</span>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700">
          <Trophy className="w-5 h-5 text-blue-400" />
          <span className="text-slate-200 font-semibold text-xs md:text-sm font-sans">Compete on Leaderboards</span>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700">
          <Star className="w-5 h-5 text-blue-400" />
          <span className="text-slate-200 font-semibold text-xs md:text-sm font-sans">Unlock Achievements</span>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700">
          <Clock className="w-5 h-5 text-blue-400" />
          <span className="text-slate-200 font-semibold text-xs md:text-sm font-sans">Real-time Challenges</span>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700">
          <Gift className="w-5 h-5 text-blue-400" />
          <span className="text-slate-200 font-semibold text-xs md:text-sm font-sans">Exclusive Rewards</span>
        </div>
      </div>
      {/* Terms Banner */}
      <div className="w-full flex justify-center items-center py-2 px-4 bg-blue-950/80 border-t border-blue-700">
        <span className="text-blue-300 text-sm text-center font-sans">By uploading a dataset to GameZone, you confirm that you have read, understood, and agreed to the <span className="underline underline-offset-2">Data Contribution Terms & Participation Policy</span>.</span>
      </div>
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Inter:wght@400;500;700&display=swap');
        .animate-pulse-glow {
          animation: pulseGlow 2s infinite alternate;
        }
        @keyframes pulseGlow {
          0% { box-shadow: 0 0 8px 0 #a855f7, 0 0 0px 0 #ec4899; }
          100% { box-shadow: 0 0 24px 4px #a855f7, 0 0 12px 2px #ec4899; }
        }
        .animate-glow-icon {
          animation: glowIcon 2s infinite alternate;
        }
        @keyframes glowIcon {
          0% { filter: drop-shadow(0 0 0px #a855f7); }
          100% { filter: drop-shadow(0 0 8px #a855f7); }
        }
        .animate-spin-slow {
          animation: spin 12s linear infinite;
        }
        @keyframes spin {
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </header>
  );
} 