import React from 'react';
import Head from 'next/head';
import { Orbitron, Inter } from 'next/font/google';
import GameZoneHeader from '../components/GameZoneHeader';
import GameZoneNav from '../components/GameZoneNav';
import '../styles/glassmorphic.css';

const orbitron = Orbitron({ subsets: ['latin'], weight: ['400', '700'] });
const inter = Inter({ subsets: ['latin'], weight: ['400', '700'] });

export default function GameZoneLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className={`min-h-screen bg-black bg-opacity-90 ${orbitron.className} ${inter.className} relative overflow-x-hidden`}> 
      <Head>
        <title>FLUZORA GameZone</title>
        <meta name="description" content="Gamified Data Contribution Platform" />
        <link rel="icon" href="/globe.svg" />
      </Head>
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-[#0f2027] via-[#2c5364] to-[#232526] opacity-90" />
      <div className="absolute inset-0 z-0 glassmorphic-bg" />
      <div className="relative z-10 flex flex-col min-h-screen">
        <GameZoneHeader />
        <div className="flex flex-1">
          <GameZoneNav />
          <main className="flex-1 p-4 md:p-8 lg:p-12 xl:p-16 overflow-y-auto">
            {children}
          </main>
        </div>
      </div>
    </div>
  );
} 