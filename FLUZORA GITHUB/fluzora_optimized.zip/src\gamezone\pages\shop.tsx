import React from 'react';
import GameZoneLayout from '../layout/GameZoneLayout';
import { useGameZoneContext } from '../context/GameZoneContext';

export default function GameZoneShop() {
  const { avatars, user } = useGameZoneContext();
  return (
    <GameZoneLayout>
      <div className="mb-6">
        <a href="/gamezone" className="inline-block px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform">Back</a>
      </div>
      <h1 className="text-3xl font-orbitron text-neon mb-8">Avatar Shop</h1>
      <div className="mb-8 flex items-center gap-4">
        <span className="font-orbitron text-white/80">Current Avatar:</span>
        <img src={user.avatar} alt="Current Avatar" className="w-14 h-14 rounded-full border-2 border-neon" />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-8">
        {avatars.map((a: any) => (
          <div key={a.id} className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col items-center gap-3 relative">
            <img src={a.src} alt="Avatar" className="w-16 h-16 rounded-full border-2 border-neon" />
            <div className="font-orbitron text-neon font-bold">{a.price} FLZ</div>
            {a.owned ? (
              <span className="px-3 py-1 rounded-full bg-neon/20 text-neon font-bold font-orbitron">Equipped</span>
            ) : (
              <button className="px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform">Redeem</button>
            )}
          </div>
        ))}
      </div>
    </GameZoneLayout>
  );
} 