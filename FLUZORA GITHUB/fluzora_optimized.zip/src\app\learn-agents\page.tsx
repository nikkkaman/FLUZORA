"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Download, BookOpen, Code, Brain, CheckCircle2, ArrowRight, Send, ExternalLink, ArrowLeft } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function LearnAgentsPage() {
  const router = useRouter();
  const [activeTrack, setActiveTrack] = useState("beginner");
  const [formData, setFormData] = useState({ name: "", suggestion: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitted(true);
    setFormData({ name: "", suggestion: "" });
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-900 p-8 flex flex-col items-center">
      <button
        onClick={() => router.back()}
        className="absolute left-8 top-20 flex items-center gap-2 px-3 py-2 rounded-full bg-transparent border border-white/30 hover:bg-white/10 hover:border-white/80 text-white transition shadow"
        style={{ zIndex: 10 }}
        aria-label="Back"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="hidden md:inline">Back</span>
      </button>
      <div className="container mx-auto px-4 py-12">
        {/* SECTION 1: Introduction */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 mb-4">
            Learn to Build AI Agents
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Use structured, ready-to-go datasets to create smarter AI agents — no fluff, no scraping, just results.
          </p>
          <p className="mt-4 text-gray-300 max-w-2xl mx-auto">
            This guide helps you start from scratch and build your first AI assistant. You'll learn the logic, the tools, and the steps — whether you're using FLUZORA datasets or your own data. It's 100% free, and beginner-friendly.
          </p>
        </motion.div>

        {/* SECTION 2: Why Use Curated Data? */}
        <div className="mb-16">
          <div className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-6 border border-purple-500/20">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-4 bg-red-900/20 rounded-lg border border-red-500/30">
                <h3 className="text-xl font-semibold text-red-300 mb-3 flex items-center">
                  ❌ Free internet data
                </h3>
                <p className="text-gray-300">messy, outdated, incomplete</p>
              </div>
              <div className="p-4 bg-green-900/20 rounded-lg border border-green-500/30">
                <h3 className="text-xl font-semibold text-green-300 mb-3 flex items-center">
                  ✅ FLUZORA data
                </h3>
                <p className="text-gray-300">structured, tagged, optimized for AI</p>
              </div>
            </div>
            <p className="mt-4 text-center text-gray-300">
              You can build agents with any data — but performance depends on quality. This is why FLUZORA matters.
            </p>
          </div>
        </div>

        {/* SECTION 3: Two Track Layout */}
        <div className="mb-16">
          <div className="flex justify-center mb-8">
            <div className="bg-purple-900/30 backdrop-blur-sm rounded-lg p-1 inline-flex">
              <button 
                onClick={() => setActiveTrack("beginner")}
                className={`px-6 py-3 rounded-lg font-medium transition-all ${
                  activeTrack === "beginner" 
                    ? "bg-purple-600 text-white" 
                    : "text-purple-300 hover:bg-purple-900/50"
                }`}
              >
                🤖 Build AI Agents (Beginner-Friendly)
              </button>
              <button 
                onClick={() => setActiveTrack("advanced")}
                className={`px-6 py-3 rounded-lg font-medium transition-all ${
                  activeTrack === "advanced" 
                    ? "bg-purple-600 text-white" 
                    : "text-purple-300 hover:bg-purple-900/50"
                }`}
              >
                🧠 Build Agentic AI (Advanced)
              </button>
            </div>
          </div>

          {activeTrack === "beginner" ? (
            <div className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-8 border border-purple-500/20">
              <h2 className="text-2xl font-bold text-purple-300 mb-6">🤖 Track 1: Build AI Agents (Beginner-Friendly)</h2>
              
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">1</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Install Python 3.9+</h3>
                    <p className="text-gray-300 mb-2">Choose your OS → Download → Check 'Add to PATH' during setup</p>
                    <a 
                      href="https://python.org" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-purple-400 hover:text-purple-300 inline-flex items-center gap-1"
                    >
                      Visit python.org <ExternalLink size={14} />
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">2</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Setup Flowise</h3>
                    <p className="text-gray-300 mb-2">Install Flowise and learn how to import JSON templates for quick agent setup</p>
                    <a 
                      href="https://flowiseai.com" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-purple-400 hover:text-purple-300 inline-flex items-center gap-1"
                    >
                      Visit flowiseai.com <ExternalLink size={14} />
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">3</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Choose your dataset</h3>
                    <p className="text-gray-300 mb-2">Select a FLUZORA dataset from our library or prepare your own .csv file</p>
                    <Link href="/datasets" className="text-purple-400 hover:text-purple-300 inline-flex items-center gap-1">
                      Browse FLUZORA datasets <ArrowRight size={14} />
                    </Link>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">4</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Connect your dataset to Flowise</h3>
                    <p className="text-gray-300 mb-2">Just upload your file → connect to memory block to create a basic RAG agent</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">5</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Test it</h3>
                    <p className="text-gray-300 mb-2">Ask your agent real questions and test its intelligence</p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-8 border border-purple-500/20">
              <h2 className="text-2xl font-bold text-purple-300 mb-6">🧠 Track 2: Build Agentic AI (For Builders/Advanced Users)</h2>
              
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">1</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Understand Agentic Logic</h3>
                    <p className="text-gray-300 mb-2">Plan → Retrieve → Act → Reflect</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">2</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Install Langchain or Flowise Advanced Blocks</h3>
                    <p className="text-gray-300 mb-2">Set up the necessary frameworks for building sophisticated agents</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">3</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Use persistent memory</h3>
                    <p className="text-gray-300 mb-2">Implement vector DB / JSON memory for long-term knowledge retention</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">4</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Define multi-step planning tasks</h3>
                    <p className="text-gray-300 mb-2">Create agents that can break down complex problems into manageable steps</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">5</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Add feedback/retry loop logic</h3>
                    <p className="text-gray-300 mb-2">Implement mechanisms for agents to learn from mistakes and improve over time</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">6</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Use advanced datasets</h3>
                    <p className="text-gray-300 mb-2">Leverage FLUZORA Vault datasets for premium performance (if subscribed)</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-purple-900/50 rounded-full w-8 h-8 flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-purple-300 font-bold">7</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-purple-300 mb-2">Deploy locally or via Docker</h3>
                    <p className="text-gray-300 mb-2">Set up your agent for production use with proper scaling and monitoring</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 4: Download Full Roadmap */}
        <div className="mb-16">
          <div className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-8 border border-purple-500/20 text-center">
            <h2 className="text-2xl font-bold text-purple-300 mb-4">
              📘 Need offline access or full visuals?
            </h2>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Download the complete roadmap PDF with screenshots, links, commands, and step-by-step setup.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-xl text-lg font-bold shadow-lg border-2 border-purple-400 flex items-center gap-2 mx-auto"
            >
              <Download size={20} /> Download Full Guide (Free)
            </motion.button>
          </div>
        </div>

        {/* SECTION 5: FAQ */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-center text-purple-300 mb-6">Frequently Asked Questions</h2>
          <div className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-6 border border-purple-500/20 space-y-4">
            <details className="group">
              <summary className="flex justify-between items-center font-medium cursor-pointer list-none p-3 bg-purple-900/30 rounded-lg">
                <span className="text-purple-200">Do I need coding knowledge?</span>
                <span className="transition group-open:rotate-180">
                  <ArrowRight size={20} className="text-purple-300" />
                </span>
              </summary>
              <div className="text-gray-300 mt-3 p-3">
                No, we explain every step. The beginner track uses Flowise which provides a visual interface for building agents without writing code.
              </div>
            </details>
            
            <details className="group">
              <summary className="flex justify-between items-center font-medium cursor-pointer list-none p-3 bg-purple-900/30 rounded-lg">
                <span className="text-purple-200">What if I want to use my own data?</span>
                <span className="transition group-open:rotate-180">
                  <ArrowRight size={20} className="text-purple-300" />
                </span>
              </summary>
              <div className="text-gray-300 mt-3 p-3">
                That works too! You can use your own CSV, JSON, or text files. We provide guidance on how to format and prepare your data for optimal results.
              </div>
            </details>
            
            <details className="group">
              <summary className="flex justify-between items-center font-medium cursor-pointer list-none p-3 bg-purple-900/30 rounded-lg">
                <span className="text-purple-200">Can I build agentic AI for finance/health/etc.?</span>
                <span className="transition group-open:rotate-180">
                  <ArrowRight size={20} className="text-purple-300" />
                </span>
              </summary>
              <div className="text-gray-300 mt-3 p-3">
                Yes, you can build domain-specific agents by using specialized datasets. FLUZORA offers datasets in various domains, or you can use your own domain-specific data.
              </div>
            </details>
          </div>
        </div>

        {/* SECTION 6: Suggestion Box */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-center text-purple-300 mb-6">Have a Suggestion?</h2>
          <div className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-8 border border-purple-500/20 max-w-2xl mx-auto">
            {submitted ? (
              <div className="text-center">
                <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-green-300 mb-2">Thank you for your suggestion!</h3>
                <p className="text-gray-300">We appreciate your feedback and will consider it for future updates.</p>
              </div>
            ) : (
              <form onSubmit={handleFormSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-purple-300 mb-2">Name (optional)</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleFormChange}
                    className="w-full bg-purple-900/30 border border-purple-500/30 rounded-lg px-4 py-3 text-gray-100 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label htmlFor="suggestion" className="block text-purple-300 mb-2">Your Suggestion</label>
                  <textarea
                    id="suggestion"
                    name="suggestion"
                    value={formData.suggestion}
                    onChange={handleFormChange}
                    rows={4}
                    required
                    className="w-full bg-purple-900/30 border border-purple-500/30 rounded-lg px-4 py-3 text-gray-100 focus:outline-none focus:border-purple-500"
                  ></textarea>
                </div>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg font-semibold flex items-center gap-2 mx-auto"
                >
                  Submit Suggestion <Send className="w-4 h-4" />
                </motion.button>
              </form>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}