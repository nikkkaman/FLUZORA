'use client';
import React from 'react';
import GlassCard from './ui/GlassCard';
import GlassProgressBar from './ui/GlassProgressBar';
import { useGameZoneContext } from '../context/GameZoneContext';

const milestones = [3, 7, 14, 30];

export default function UploadStreaks() {
  const { user } = useGameZoneContext();
  const next = milestones.find(m => m > user.streak) || milestones[milestones.length - 1];
  const progress = Math.min((user.streak / next) * 100, 100);
  return (
    <GlassCard className="mb-8">
      <div className="font-orbitron text-neon text-2xl mb-2">Upload Streak</div>
      <div className="font-orbitron text-3xl text-neon mb-2">🔥 {user.streak} days</div>
      <GlassProgressBar value={progress} label={`Next reward at ${next} days`} />
      <div className="mt-4 text-white/80 font-inter text-sm">Streak rewards: 3d = +50 FLZ, 7d = +150 FLZ, 14d = +400 FLZ, 30d = +1000 FLZ</div>
    </GlassCard>
  );
} 