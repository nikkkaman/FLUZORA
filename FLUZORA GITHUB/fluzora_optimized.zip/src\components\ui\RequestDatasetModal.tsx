import React, { useState } from 'react';

type RequestDatasetModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (request: string) => void;
};

export function RequestDatasetModal({ isOpen, onClose, onSubmit }: RequestDatasetModalProps) {
  const [request, setRequest] = useState('');

  if (!isOpen) {
    return null;
  }

  const handleSubmit = () => {
    onSubmit(request);
    setRequest('');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
      <div className="bg-gray-900 border border-purple-800 rounded-xl shadow-lg p-6 w-full max-w-md">
        <h2 className="text-2xl font-bold text-white mb-4">Request a Dataset</h2>
        <p className="text-gray-400 mb-6">
          Can't find what you're looking for? Let us know what dataset you need, and we'll do our best to source it for you.
        </p>
        <textarea
          className="w-full h-32 p-3 bg-gray-800 border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
          placeholder="Describe the dataset you need..."
          value={request}
          onChange={(e) => setRequest(e.target.value)}
        />
        <div className="mt-6 flex justify-end gap-4">
          <button
            className="px-4 py-2 rounded-md bg-gray-700 text-white hover:bg-gray-600 transition-colors"
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            className="px-4 py-2 rounded-md bg-purple-600 text-white hover:bg-purple-700 transition-colors"
            onClick={handleSubmit}
            disabled={!request.trim()}
          >
            Submit Request
          </button>
        </div>
      </div>
    </div>
  );
} 