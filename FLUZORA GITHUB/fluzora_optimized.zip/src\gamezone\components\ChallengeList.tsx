'use client';
import React from 'react';
import { useGameZoneContext } from '../context/GameZoneContext';
import GlassCard from './ui/GlassCard';
import GlassButton from './ui/GlassButton';
import GlassBadge from './ui/GlassBadge';

export default function ChallengeList() {
  const { challenges } = useGameZoneContext();
  return (
    <GlassCard>
      <div className="font-orbitron text-neon text-xl mb-4">Ongoing Challenges</div>
      <div className="flex flex-col gap-4">
        {challenges.map((c: any) => (
          <div key={c.id} className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <span className="font-orbitron text-lg text-neon">{c.title}</span>
              <GlassBadge>{c.domain}</GlassBadge>
            </div>
            <div className="flex items-center gap-4 text-white/80 font-inter">
              <span>Bonus: <span className="text-neon font-bold">+{c.bonus} FLZ</span></span>
              <span className="ml-auto">Deadline: <span className="text-neon">{c.deadline}</span></span>
            </div>
            <GlassButton className="mt-2 w-fit" aria-label={`Upload for ${c.title}`}>Upload</GlassButton>
          </div>
        ))}
      </div>
    </GlassCard>
  );
}

 