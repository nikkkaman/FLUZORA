"use client";

import React from "react";
import GameZoneHeader from "@/components/GameZoneHeader";
import { UploadCloud, Coins, Star, Trophy, Sparkles, CheckCircle2, ArrowRight } from "lucide-react";
import Link from "next/link";

const orbitron = { fontFamily: "'Orbitron', Inter, sans-serif" };
const inter = { fontFamily: "'Inter', sans-serif" };

const uploads = [
  { id: 1, title: "Personal Finance Tips", status: "Approved", reward: 40, date: "2024-06-21" },
  { id: 2, title: "Healthy Recipes", status: "Pending", reward: 30, date: "2024-06-20" },
  { id: 3, title: "Quiz Questions", status: "Rejected", reward: 0, date: "2024-06-19" },
];

const achievements = [
  { icon: Trophy, label: "Top 10 Contributor" },
  { icon: Star, label: "5 Uploads" },
  { icon: Sparkles, label: "First Reward" },
];

const activity = [
  { type: "upload", text: "Uploaded 'Healthy Recipes'", date: "2024-06-20" },
  { type: "reward", text: "+40 FLZ for 'Personal Finance Tips'", date: "2024-06-21" },
  { type: "achievement", text: "Unlocked '5 Uploads' badge", date: "2024-06-19" },
];

export default function GameZoneDashboard() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-black via-gray-900 to-black flex flex-col items-center justify-start relative overflow-x-hidden">
      <GameZoneHeader />
      <main className="w-full max-w-6xl mx-auto px-4 py-12 flex flex-col gap-10">
        {/* FLZ Balance & Achievements */}
        <section className="grid md:grid-cols-3 gap-8">
          <div className="bg-black/60 border border-yellow-400/40 rounded-2xl p-8 shadow-xl backdrop-blur-lg flex flex-col items-center justify-center">
            <Coins className="w-10 h-10 text-yellow-400 animate-glow-icon mb-2" />
            <div className="text-3xl font-bold text-yellow-400 mb-1" style={orbitron}>340 FLZ</div>
            <div className="text-purple-200 text-sm mb-2">Token Balance</div>
            <Link href="/gamezone" className="mt-2 px-4 py-2 rounded-full bg-gradient-to-r from-yellow-400 via-pink-500 to-purple-600 text-white font-semibold shadow-lg border-2 border-white/10 hover:scale-105 transition-all duration-200 animate-pulse-glow flex items-center gap-2">
              <UploadCloud className="w-5 h-5" /> Earn More
            </Link>
          </div>
          <div className="bg-black/60 border border-pink-600/40 rounded-2xl p-8 shadow-xl backdrop-blur-lg flex flex-col items-center justify-center">
            <div className="text-xl font-bold text-white mb-3 flex items-center gap-2" style={orbitron}>
              <Star className="w-6 h-6 text-pink-400 animate-glow-icon" /> Achievements
            </div>
            <div className="flex flex-wrap gap-4 justify-center">
              {achievements.map((ach, idx) => {
                const Icon = ach.icon;
                return (
                  <div key={idx} className="flex flex-col items-center gap-1">
                    <Icon className="w-8 h-8 animate-glow-icon text-yellow-400" />
                    <span className="text-xs text-purple-200" style={inter}>{ach.label}</span>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="bg-black/60 border border-purple-700/40 rounded-2xl p-8 shadow-xl backdrop-blur-lg flex flex-col items-center justify-center">
            <div className="text-xl font-bold text-white mb-3 flex items-center gap-2" style={orbitron}>
              <CheckCircle2 className="w-6 h-6 text-green-400 animate-glow-icon" /> Quick Links
            </div>
            <div className="flex flex-col gap-3 w-full">
              <Link href="/gamezone" className="flex items-center gap-2 text-pink-400 hover:text-yellow-400 font-semibold transition text-base" style={inter}>
                <UploadCloud className="w-5 h-5" /> New Challenges <ArrowRight className="w-4 h-4" />
              </Link>
              <Link href="/gamezone#leaderboard" className="flex items-center gap-2 text-purple-400 hover:text-yellow-400 font-semibold transition text-base" style={inter}>
                <Trophy className="w-5 h-5" /> Leaderboard <ArrowRight className="w-4 h-4" />
              </Link>
              <Link href="/gamezone" className="flex items-center gap-2 text-yellow-400 hover:text-pink-400 font-semibold transition text-base" style={inter}>
                <Star className="w-5 h-5" /> Earn FLZ <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>
        {/* Uploads Table */}
        <section className="bg-black/60 border border-purple-700/40 rounded-2xl p-8 shadow-xl backdrop-blur-lg">
          <div className="text-2xl font-bold text-white mb-6 flex items-center gap-2" style={orbitron}>
            <UploadCloud className="w-7 h-7 text-yellow-400 animate-glow-icon" /> Your Uploads
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-purple-300 text-sm">
                  <th className="py-2">Title</th>
                  <th className="py-2">Status</th>
                  <th className="py-2">Reward</th>
                  <th className="py-2">Date</th>
                </tr>
              </thead>
              <tbody>
                {uploads.map((u) => (
                  <tr key={u.id} className="text-white/90 font-medium">
                    <td className="py-2 flex items-center gap-2">
                      <UploadCloud className="w-4 h-4 text-pink-400" /> {u.title}
                    </td>
                    <td className={`py-2 font-bold ${u.status === "Approved" ? "text-green-400" : u.status === "Pending" ? "text-yellow-400" : "text-red-400"}`}>{u.status}</td>
                    <td className="py-2 flex items-center gap-1">
                      <Coins className="w-4 h-4 text-yellow-400" /> {u.reward}
                    </td>
                    <td className="py-2 text-purple-200">{u.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
        {/* Recent Activity */}
        <section className="bg-black/60 border border-pink-600/40 rounded-2xl p-8 shadow-xl backdrop-blur-lg">
          <div className="text-2xl font-bold text-white mb-6 flex items-center gap-2" style={orbitron}>
            <Sparkles className="w-7 h-7 text-pink-400 animate-glow-icon" /> Recent Activity
          </div>
          <ul className="flex flex-col gap-4">
            {activity.map((a, idx) => (
              <li key={idx} className="flex items-center gap-3 text-purple-200 text-lg">
                {a.type === "upload" && <UploadCloud className="w-6 h-6 text-yellow-400 animate-bounce" />}
                {a.type === "reward" && <Coins className="w-6 h-6 text-pink-400 animate-spin-slow" />}
                {a.type === "achievement" && <Star className="w-6 h-6 text-purple-400 animate-glow-icon" />}
                {a.text}
                <span className="ml-2 text-xs text-purple-400">{a.date}</span>
              </li>
            ))}
          </ul>
        </section>
      </main>
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=Inter:wght@400;500;700&display=swap');
        .animate-glow-icon {
          animation: glowIcon 2s infinite alternate;
        }
        @keyframes glowIcon {
          0% { filter: drop-shadow(0 0 0px #a855f7); }
          100% { filter: drop-shadow(0 0 8px #a855f7); }
        }
        .animate-spin-slow {
          animation: spin 12s linear infinite;
        }
        @keyframes spin {
          100% { transform: rotate(360deg); }
        }
        .animate-pulse-glow {
          animation: pulseGlow 2s infinite alternate;
        }
        @keyframes pulseGlow {
          0% { box-shadow: 0 0 8px 0 #a855f7, 0 0 0px 0 #ec4899; }
          100% { box-shadow: 0 0 24px 4px #a855f7, 0 0 12px 2px #ec4899; }
        }
        .animate-bounce {
          animation: bounce 1.2s infinite alternate;
        }
        @keyframes bounce {
          0% { transform: translateY(0); }
          100% { transform: translateY(-8px); }
        }
      `}</style>
    </div>
  );
} 