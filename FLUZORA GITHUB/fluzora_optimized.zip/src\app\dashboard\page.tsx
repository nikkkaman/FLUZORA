'use client';
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { allDatasets } from "@/data/datasets";
import { Skeleton } from "@/components/ui/skeleton";
import { showInfo } from "@/components/ui/sonner";
import { ArrowLeft } from "lucide-react";
import { useRouter } from "next/navigation";

export default function DashboardPage() {
  // Dummy user data (replace with real user data if available)
  const user = {
    name: "Demo User",
    email: "demo@fluzora.com",
    plan: "Ultimate",
    avatar: "/default-avatar.svg",
    credits: 120,
    datasets: 5,
  };

  // Downloaded datasets state (persisted in localStorage)
  const [downloaded, setDownloaded] = useState<string[]>([]);

  // Recent activity state
  const [recentActivity, setRecentActivity] = useState<any[]>([]);

  const [loading, setLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);

  const router = useRouter();

  // On mount, load downloaded datasets from localStorage
  useEffect(() => {
    setLoading(true);
    const timeout = setTimeout(() => setLoading(false), 1000);
    setShowOnboarding(localStorage.getItem('onboardingDismissed') !== 'true');
    const dl = localStorage.getItem("downloadedDatasets");
    setDownloaded(dl ? JSON.parse(dl) : []);
    const act = localStorage.getItem("recentActivity");
    setRecentActivity(act ? JSON.parse(act) : []);
    return () => clearTimeout(timeout);
  }, []);

  // Listen for new downloads (other tabs/windows)
  useEffect(() => {
    const handler = () => {
      const dl = localStorage.getItem("downloadedDatasets");
      setDownloaded(dl ? JSON.parse(dl) : []);
      const act = localStorage.getItem("recentActivity");
      setRecentActivity(act ? JSON.parse(act) : []);
    };
    window.addEventListener("storage", handler);
    return () => window.removeEventListener("storage", handler);
  }, []);

  const handleDismissOnboarding = () => {
    setShowOnboarding(false);
    localStorage.setItem('onboardingDismissed', 'true');
    showInfo('You can always revisit the tour from the Help menu!');
  };

  // Helper: get dataset info by id
  const getDataset = (id: string) => allDatasets.find(ds => ds.id === id);

  // Example recommended datasets (top 3 by price for demo)
  const recommended = allDatasets.slice(0, 3);

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-900 p-8 flex flex-col items-center">
      <button
        onClick={() => router.back()}
        className="absolute left-8 top-8 flex items-center gap-2 px-3 py-2 rounded-full bg-transparent border border-white/30 hover:bg-white/10 hover:border-white/80 text-white transition shadow"
        style={{ zIndex: 10 }}
        aria-label="Back"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="hidden md:inline">Back</span>
      </button>
      {loading ? (
        <>
          <Skeleton className="w-full max-w-4xl h-32 rounded-xl mb-8" />
          <div className="flex flex-col md:flex-row gap-6 w-full max-w-4xl mb-8">
            <Skeleton className="h-40 w-full md:w-1/3" />
            <Skeleton className="h-40 w-full md:w-1/3" />
            <Skeleton className="h-40 w-full md:w-1/3" />
          </div>
          <Skeleton className="w-full max-w-4xl h-40 rounded-xl mb-8" />
        </>
      ) : (
      <div className="w-full max-w-4xl bg-gray-800/80 rounded-xl p-8 shadow-xl">
        {/* Onboarding Banner */}
        {showOnboarding && (
          <div className="mb-6 p-4 bg-gradient-to-r from-purple-700 to-purple-500 rounded-xl flex items-center justify-between shadow-lg text-white">
            <div>
              <span className="font-bold">Welcome to FLUZORA!</span> Explore datasets, manage your account, and get started with your first download. Need help? Check out the Help menu.
            </div>
            <button
              onClick={handleDismissOnboarding}
              className="ml-6 px-4 py-2 rounded bg-white/20 hover:bg-white/40 text-white font-semibold shadow"
            >
              Dismiss
            </button>
          </div>
        )}
        {/* Welcome Header */}
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Welcome back, {user.name}!</h1>
        <p className="text-gray-300 mb-8">Here's your personalized dashboard. All your activity and downloads in one place.</p>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {/* User Info Card */}
          <div className="col-span-1 bg-gray-800 rounded-xl p-6 flex flex-col items-center shadow-lg">
            <img src={user.avatar} alt="avatar" className="w-20 h-20 rounded-full mb-4 border-4 border-purple-500" />
            <div className="text-white text-lg font-semibold mb-1">{user.name}</div>
            <div className="text-purple-300 text-sm mb-2">{user.email}</div>
            <span className="bg-purple-700/60 text-purple-200 px-3 py-1 rounded-full text-xs font-bold">{user.plan} Plan</span>
          </div>
          {/* Stats Cards */}
          <div className="col-span-1 bg-gradient-to-r from-purple-700 to-purple-500 rounded-xl p-6 flex flex-col items-center justify-center shadow-lg">
            <div className="text-3xl font-bold text-white mb-1">{user.datasets}</div>
            <div className="text-purple-100 text-sm">Datasets Owned</div>
          </div>
          <div className="col-span-1 bg-gradient-to-r from-green-600 to-blue-500 rounded-xl p-6 flex flex-col items-center justify-center shadow-lg">
            <div className="text-3xl font-bold text-white mb-1">{user.credits}</div>
            <div className="text-green-100 text-sm">Credits</div>
          </div>
          <div className="col-span-1 bg-gradient-to-r from-gray-700 to-gray-900 rounded-xl p-6 flex flex-col items-center justify-center shadow-lg">
            <div className="text-2xl font-bold text-white mb-1">{user.plan}</div>
            <div className="text-gray-200 text-sm">Current Plan</div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="flex flex-wrap gap-4 mb-8">
          <Link href="/datasets" className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold shadow transition">Browse Datasets</Link>
          <Link href="/billing" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold shadow transition">Billing</Link>
          <Link href="/settings" className="bg-gray-700 hover:bg-gray-800 text-white px-6 py-3 rounded-lg font-semibold shadow transition">Settings</Link>
        </div>

        {/* Downloaded Datasets */}
        <div className="bg-gray-800 rounded-xl p-6 shadow-lg mb-8">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <span>Downloaded Datasets</span>
            <span className="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">{downloaded.length}</span>
          </h2>
          {loading ? (
            <ul className="divide-y divide-gray-700">
              {[...Array(3)].map((_, i) => (
                <li key={i} className="py-3 flex justify-between items-center text-gray-200">
                  <Skeleton className="h-8 w-1/2" />
                  <Skeleton className="h-8 w-32" />
                </li>
              ))}
            </ul>
          ) : downloaded.length === 0 ? (
            <div className="text-gray-400">No datasets downloaded yet. Buy or download a dataset to see it here!</div>
          ) : (
            <ul className="divide-y divide-gray-700">
              {downloaded.map((id, idx) => {
                const ds = getDataset(id);
                if (!ds) return null;
                return (
                  <li key={id} className="py-3 flex justify-between items-center text-gray-200">
                    <div>
                      <span className="font-semibold text-purple-300">{ds.name}</span>
                      <span className="ml-2 text-xs bg-purple-900/60 text-purple-200 px-2 py-0.5 rounded">{ds.domain}</span>
                    </div>
                    <a
                      href={"#"}
                      className="bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white px-4 py-2 rounded-lg font-semibold text-sm shadow transition"
                      download
                    >
                      Download Again
                    </a>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {/* Recent Activity */}
        <div className="bg-gray-800 rounded-xl p-6 shadow-lg">
          <h2 className="text-xl font-bold text-white mb-4">Recent Activity</h2>
          {loading ? (
            <ul className="divide-y divide-gray-700">
              {[...Array(3)].map((_, i) => (
                <li key={i} className="py-3 flex justify-between items-center text-gray-200">
                  <Skeleton className="h-6 w-1/2" />
                  <Skeleton className="h-6 w-24" />
                </li>
              ))}
            </ul>
          ) : recentActivity.length === 0 ? (
            <div className="text-gray-400">No recent activity yet.</div>
          ) : (
            <ul className="divide-y divide-gray-700">
              {recentActivity.map((activity, idx) => (
                <li key={idx} className="py-3 flex justify-between items-center text-gray-200">
                  <span>
                    <span className="font-semibold text-purple-300">{activity.action}</span> {activity.item}
                  </span>
                  <span className="text-gray-400 text-sm">{activity.date}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Recommendations */}
        {!loading && (
          <div className="mb-8">
            <h2 className="text-xl font-bold text-white mb-4">Recommended for you</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {recommended.map(ds => (
                <div key={ds.id} className="bg-gray-800 rounded-xl p-6 flex flex-col shadow-lg">
                  <div className="text-lg font-bold text-purple-300 mb-2">{ds.name}</div>
                  <div className="text-gray-400 mb-2">{ds.domain}</div>
                  <div className="text-gray-300 mb-4">{ds.description}</div>
                  <Link href="/datasets" className="mt-auto px-4 py-2 rounded bg-purple-600 text-white hover:bg-purple-700 font-semibold shadow text-center">View Dataset</Link>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      )}
    </main>
  );
} 