"use client";
import React from "react";
import { motion } from "framer-motion";
import { FaUserAstronaut, FaCoins, FaCheck, FaShoppingCart } from "react-icons/fa";

const avatars = [
  { id: 1, src: "/default-avatar.svg", price: 200, owned: true },
  { id: 2, src: "/default-avatar.svg", price: 300, owned: false },
  { id: 3, src: "/default-avatar.svg", price: 400, owned: false },
  { id: 4, src: "/default-avatar.svg", price: 500, owned: false },
];

export default function AvatarsPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg">Avatars</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">Unlock and equip unique avatars with your FLZ tokens. Stand out on the leaderboard and in the community!</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full max-w-4xl grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8"
      >
        {avatars.map((a, i) => (
          <motion.div
            key={a.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i, duration: 0.5 }}
            className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col items-center gap-3 border border-pink-400"
          >
            <img src={a.src} alt="Avatar" className="w-20 h-20 rounded-full border-2 border-neon mb-2" />
            <div className="flex items-center gap-2 text-yellow-400 font-bold font-orbitron mb-2">
              <FaCoins /> {a.price} FLZ
            </div>
            {a.owned ? (
              <button className="mt-auto px-4 py-2 rounded-lg bg-gradient-to-r from-green-500 to-blue-500 text-white font-orbitron font-bold shadow-lg flex items-center gap-2"><FaCheck /> Equipped</button>
            ) : (
              <button className="mt-auto px-4 py-2 rounded-lg bg-gradient-to-r from-pink-500 to-purple-600 text-white font-orbitron font-bold shadow-lg flex items-center gap-2"><FaShoppingCart /> Buy</button>
            )}
          </motion.div>
        ))}
      </motion.div>
    </main>
  );
} 