export const subscriptionDatasets = [
  // Starter Pack
  {
    id: "sub-1",
    name: "Budget Master Pack",
    domain: "Finance",
    description: "SIP planning, expense control, and wealth blueprinting.",
    size: "180MB",
    price: null,
    pack: "starter" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "How can I start managing my money better?", a: "This pack gives you simple records of expenses, savings, and budgeting tips to help you take control of your finances." },
      { q: "Can I build a personal finance tracker?", a: "Absolutely—use this data to create your own budget and expense tracking app." },
      { q: "What insights can I gain from my spending habits?", a: "Spot trends, cut unnecessary costs, and boost your savings with real data." },
      { q: "Is this data beginner-friendly?", a: "Yes! It's perfect for anyone new to personal finance or app development." },
      { q: "How can I impress in a finance interview?", a: "Showcase your skills by building a budget analysis tool using this dataset!" }
    ]
  },
  {
    id: "sub-2",
    name: "Healthy Life Kit",
    domain: "Health",
    description: "Diet plans, workout systems, sleep tracking tools.",
    size: "160MB",
    price: null,
    pack: "starter" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "How can I improve my daily health habits?", a: "Use this kit's diet logs, exercise routines, and sleep patterns to build your own health and wellness app." },
      { q: "Can I track my fitness progress?", a: "Yes! Monitor your workouts and see your improvements over time." },
      { q: "What can I learn from my sleep data?", a: "Discover patterns and optimize your rest for better health." },
      { q: "Is this data suitable for health beginners?", a: "Absolutely—it's designed for anyone starting their wellness journey." },
      { q: "How can I impress in a health tech interview?", a: "Build a simple health dashboard or tracker using this dataset!" }
    ]
  },
  {
    id: "sub-3",
    name: "Basic E-commerce Pack",
    domain: "Retail",
    description: "Essential e-commerce metrics and basic customer insights.",
    size: "150MB",
    price: null,
    pack: "starter" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "What do customers think about products?", a: "Analyze sales records, reviews, and ratings to understand customer preferences and improve your e-commerce strategy." },
      { q: "Can I build a product recommendation engine?", a: "Yes! Use this data to create your own recommendation system." },
      { q: "How can I boost sales with data?", a: "Spot trends and optimize your product offerings for higher conversions." },
      { q: "Is this data good for e-commerce beginners?", a: "Definitely—it's perfect for learning the basics of online retail analytics." },
      { q: "How can I impress in a retail interview?", a: "Showcase your skills by building a sales dashboard using this dataset!" }
    ]
  },

  // Pro Pack
  {
    id: "pro-1",
    name: "Wealth Strategy Vault",
    domain: "Advanced Finance",
    description: "ETF mix models, retirement returns simulator, FIRE strategy.",
    size: "2.8GB",
    price: null,
    pack: "pro" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "How do advanced investors plan for the future?", a: "Explore investment portfolios, retirement simulations, and financial strategies for building complex finance tools." },
      { q: "Can I simulate my retirement plan?", a: "Absolutely—use this data to forecast your financial future and optimize your investments." },
      { q: "What is FIRE and how can I achieve it?", a: "Learn about Financial Independence, Retire Early (FIRE) strategies with real data." },
      { q: "Is this data suitable for advanced users?", a: "Yes! It's designed for those looking to deepen their financial knowledge." },
      { q: "How can I impress in a finance tech interview?", a: "Build a retirement simulator or portfolio optimizer using this dataset!" }
    ]
  },
  {
    id: "pro-2",
    name: "Full Health Tracker",
    domain: "Wellness",
    description: "Vitals logger, symptom checker, doctor follow-up planner.",
    size: "3.2GB",
    price: null,
    pack: "pro" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "How can I monitor my health over time?", a: "Use comprehensive health logs, symptom records, and doctor visit data for advanced health monitoring and analytics." },
      { q: "Can I track my fitness progress?", a: "Yes! Monitor your workouts and see your improvements over time." },
      { q: "What can I learn from my sleep data?", a: "Discover patterns and optimize your rest for better health." },
      { q: "Is this data suitable for health beginners?", a: "Absolutely—it's designed for anyone starting their wellness journey." },
      { q: "How can I impress in a health tech interview?", a: "Build a simple health dashboard or tracker using this dataset!" }
    ]
  },
  {
    id: "pro-3",
    name: "Market Intelligence Suite",
    domain: "Business",
    description: "Advanced market analysis and business intelligence tools.",
    size: "2.5GB",
    price: null,
    pack: "pro" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "How do businesses stay ahead of competitors?", a: "Dive into market trends, competitor analysis, and business metrics for powerful business intelligence." },
      { q: "Can I build a market analysis tool?", a: "Yes! Use this data to create your own market analysis tool." },
      { q: "How can I boost business growth with data?", a: "Spot trends and optimize your business strategy for higher growth." },
      { q: "Is this data good for business beginners?", a: "Definitely—it's perfect for learning the basics of business analytics." },
      { q: "How can I impress in a business interview?", a: "Showcase your skills by building a market analysis dashboard using this dataset!" }
    ]
  },

  // Premium Pack (Regular Premium, not Premium Vault)
  {
    id: "prem-sub-1",
    name: "Advanced Trading Suite",
    domain: "Finance",
    description: "Professional trading algorithms and market analysis tools.",
    size: "4.5GB",
    price: null,
    pack: "premium" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "How do pros trade in the financial markets?", a: "Access complex trading data, algorithmic strategies, and market signals for professional trading and modeling." },
      { q: "Can I simulate a trading strategy?", a: "Absolutely—use this data to test and optimize your trading algorithms." },
      { q: "What is the impact of market volatility?", a: "Analyze historical market data to understand the impact of market volatility on investment returns." },
      { q: "Is this data suitable for advanced traders?", a: "Yes! It's designed for those looking to deepen their trading knowledge." },
      { q: "How can I impress in a finance tech interview?", a: "Build a trading simulator or portfolio optimizer using this dataset!" }
    ]
  },
  {
    id: "prem-sub-2",
    name: "Medical Research Bundle",
    domain: "Healthcare",
    description: "Comprehensive medical research data and analysis tools.",
    size: "5.2GB",
    price: null,
    pack: "premium" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "What insights can I find in medical research?", a: "Explore patient records, clinical trial results, and research findings for advanced healthcare AI and research." },
      { q: "Can I build a medical research tool?", a: "Yes! Use this data to create your own medical research tool." },
      { q: "How can I improve patient care with data?", a: "Analyze medical data to identify trends and optimize patient care." },
      { q: "Is this data suitable for healthcare professionals?", a: "Absolutely—it's designed for those looking to apply data science in healthcare." },
      { q: "How can I impress in a healthcare interview?", a: "Build a medical research dashboard or tool using this dataset!" }
    ]
  },
  {
    id: "prem-sub-3",
    name: "AI Development Kit",
    domain: "Technology",
    description: "Advanced AI model training and development resources.",
    size: "4.8GB",
    price: null,
    pack: "premium" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "How do I train powerful AI models?", a: "Use large datasets for training, testing, and validating AI models—perfect for building and benchmarking advanced AI systems." },
      { q: "Can I build an AI model?", a: "Yes! Use this data to train your own AI model." },
      { q: "What is the impact of AI on society?", a: "Analyze historical data to understand the impact of AI on various aspects of society." },
      { q: "Is this data suitable for AI professionals?", a: "Yes! It's designed for those looking to deepen their AI knowledge." },
      { q: "How can I impress in an AI interview?", a: "Build an AI model or tool using this dataset!" }
    ]
  },
  {
    id: "prem-sub-4",
    name: "Enterprise Analytics Suite",
    domain: "Business Intelligence",
    description: "Complete enterprise-level analytics and reporting tools.",
    size: "5.5GB",
    price: null,
    pack: "premium" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "How do big companies make data-driven decisions?", a: "Access business data, dashboards, and reporting tools for enterprise analytics and smarter decision-making." },
      { q: "Can I build a business intelligence tool?", a: "Yes! Use this data to create your own business intelligence tool." },
      { q: "How can I improve business performance with data?", a: "Analyze business data to identify trends and optimize business operations." },
      { q: "Is this data suitable for business professionals?", a: "Absolutely—it's designed for those looking to apply data science in business." },
      { q: "How can I impress in a business interview?", a: "Build a business intelligence dashboard or tool using this dataset!" }
    ]
  },

  // Premium Vault (Special Premium Collections)
  {
    id: "vault-1",
    name: "Enterprise Finance Suite",
    domain: "Financial Technology",
    description: "Complete financial modeling, risk assessment, and market analysis toolkit with historical data spanning 20 years.",
    size: "9.8GB",
    price: 299,
    pack: "premium" as const,
    isPremiumVault: true,
    addToCart: true,
    previewText: [
      { q: "How do fintech leaders forecast the future?", a: "Use massive historical financial records, risk models, and analytics for high-end forecasting and innovation." },
      { q: "Can I build a financial modeling tool?", a: "Yes! Use this data to create your own financial modeling tool." },
      { q: "What is the impact of financial risk?", a: "Analyze historical financial data to understand the impact of financial risk on investment returns." },
      { q: "Is this data suitable for financial professionals?", a: "Yes! It's designed for those looking to deepen their financial knowledge." },
      { q: "How can I impress in a finance tech interview?", a: "Build a financial modeling tool or portfolio optimizer using this dataset!" }
    ]
  },
  {
    id: "vault-2",
    name: "Healthcare AI Bundle",
    domain: "Medical Technology",
    description: "Comprehensive medical imaging, diagnosis assistance, and patient care optimization with anonymized data from leading hospitals.",
    size: "10.2GB",
    price: 349,
    pack: "premium" as const,
    isPremiumVault: true,
    addToCart: true,
    previewText: [
      { q: "How can AI improve patient care?", a: "Access medical images, diagnostic results, and patient care data for building advanced healthcare AI and diagnostic tools." },
      { q: "Can I build a medical imaging tool?", a: "Yes! Use this data to create your own medical imaging tool." },
      { q: "What is the impact of AI on healthcare?", a: "Analyze historical medical data to understand the impact of AI on healthcare operations." },
      { q: "Is this data suitable for healthcare professionals?", a: "Absolutely—it's designed for those looking to apply data science in healthcare." },
      { q: "How can I impress in a healthcare interview?", a: "Build a medical imaging tool or diagnostic tool using this dataset!" }
    ]
  },
  {
    id: "vault-3",
    name: "Legal Intelligence Pack",
    domain: "Legal Tech",
    description: "Contract analysis, case law processing, and legal document automation with data from multiple jurisdictions.",
    size: "8.8GB",
    price: 279,
    pack: "premium" as const,
    isPremiumVault: true,
    addToCart: true,
    previewText: [
      { q: "How can AI help with legal research?", a: "Explore legal contracts, case law summaries, and document automation samples for legal research and AI-powered tools." },
      { q: "Can I build a legal research tool?", a: "Yes! Use this data to create your own legal research tool." },
      { q: "What is the impact of AI on law?", a: "Analyze historical legal data to understand the impact of AI on legal research and practice." },
      { q: "Is this data suitable for legal professionals?", a: "Yes! It's designed for those looking to deepen their legal knowledge." },
      { q: "How can I impress in a legal interview?", a: "Build a legal research tool or document automation tool using this dataset!" }
    ]
  },
  {
    id: "vault-4",
    name: "Enterprise Security Suite",
    domain: "Cybersecurity",
    description: "Advanced threat detection, network analysis, and security protocol datasets with real-world incident data.",
    size: "9.5GB",
    price: 329,
    pack: "premium" as const,
    isPremiumVault: true,
    addToCart: true,
    previewText: [
      { q: "How do experts defend against cyber threats?", a: "Analyze real-world security incidents, threat patterns, and network logs for cybersecurity research and defense." },
      { q: "Can I build a cybersecurity tool?", a: "Yes! Use this data to create your own cybersecurity tool." },
      { q: "What is the impact of cyber threats?", a: "Analyze historical cybersecurity data to understand the impact of cyber threats on organizations." },
      { q: "Is this data suitable for cybersecurity professionals?", a: "Yes! It's designed for those looking to deepen their cybersecurity knowledge." },
      { q: "How can I impress in a cybersecurity interview?", a: "Build a cybersecurity tool or threat detection tool using this dataset!" }
    ]
  },
  {
    id: "vault-5",
    name: "Research & Development Pack",
    domain: "Scientific Research",
    description: "Scientific paper analysis, research methodology, and experimental data from leading research institutions.",
    size: "9.2GB",
    price: 299,
    pack: "premium" as const,
    isPremiumVault: true,
    addToCart: true,
    previewText: [
      { q: "What drives innovation in science?", a: "Access research papers, experiment results, and methodologies for advanced R&D and academic projects." },
      { q: "Can I build a research methodology tool?", a: "Yes! Use this data to create your own research methodology tool." },
      { q: "What is the impact of scientific research?", a: "Analyze historical scientific data to understand the impact of scientific research on various fields." },
      { q: "Is this data suitable for scientific professionals?", a: "Yes! It's designed for those looking to deepen their scientific knowledge." },
      { q: "How can I impress in a research interview?", a: "Build a research methodology tool or experimental data analysis tool using this dataset!" }
    ]
  },
  {
    id: "sub-51",
    name: "AI Startup Launch Kit",
    domain: "Entrepreneurship",
    description: "Business plans, pitch decks, and growth metrics from 200+ successful AI startups for founders and accelerators.",
    size: "1.1GB",
    price: null,
    pack: "starter" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "What types of startups are included?", a: "AI SaaS, robotics, fintech, healthtech, and more." },
      { q: "Are pitch decks anonymized?", a: "Yes, all sensitive info is removed for privacy." },
      { q: "Can I use this for my accelerator?", a: "Perfect for demo days, founder bootcamps, and VC scouting." },
      { q: "What makes this kit unique?", a: "Real-world, up-to-date, and actionable for new founders." },
      { q: "Is this data beginner-friendly?", a: "Absolutely—great for first-time founders and students." }
    ]
  },
  {
    id: "sub-52",
    name: "Global Logistics Optimization Pack",
    domain: "Logistics",
    description: "Shipping routes, delivery times, and supply chain analytics for logistics AI and route optimization.",
    size: "2.2GB",
    price: null,
    pack: "pro" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "What regions are covered?", a: "North America, Europe, Asia, and emerging markets." },
      { q: "Can I use this for last-mile delivery?", a: "Yes, includes urban and rural delivery scenarios." },
      { q: "What makes this pack unique?", a: "Real-world data from top logistics companies." },
      { q: "Is this data suitable for optimization?", a: "Perfect for route planning and supply chain AI." },
      { q: "How is privacy handled?", a: "All company and customer data is anonymized." }
    ]
  },
  {
    id: "sub-53",
    name: "EdTech Learning Analytics Suite",
    domain: "Education",
    description: "Student engagement, course completion, and adaptive learning data from global EdTech platforms.",
    size: "1.5GB",
    price: null,
    pack: "starter" as const,
    isPremiumVault: false,
    addToCart: true,
    previewText: [
      { q: "What education levels are included?", a: "K-12, university, and professional learning." },
      { q: "Can I use this for adaptive learning?", a: "Yes, includes engagement and performance metrics." },
      { q: "What makes this suite unique?", a: "Diversity of platforms and actionable insights." },
      { q: "Is this data suitable for EdTech startups?", a: "Perfect for benchmarking and product development." },
      { q: "How is privacy handled?", a: "All student data is anonymized and compliant." }
    ]
  },
  // ... (continue with 46 more, covering health, AI, sports, legal, entertainment, agriculture, etc.) ...
];
