'use client';
import React, { useRef, useState } from 'react';
import GlassButton from './ui/GlassButton';
import GlassCard from './ui/GlassCard';

function parseCSV(content: string) {
  const rows = content.split('\n').map(r => r.split(','));
  return rows.slice(0, 5);
}

export default function UploadPanel() {
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string[][]>([]);
  const [agreed, setAgreed] = useState(false);
  const [underReview, setUnderReview] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      setPreview(parseCSV(text));
    };
    reader.readAsText(f);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setUnderReview(true);
  };

  return (
    <GlassCard>
      <form className="flex flex-col gap-4" onSubmit={handleSubmit}>
        <div>
          <label className="block font-orbitron text-neon mb-2">Title</label>
          <input type="text" className="w-full p-3 rounded-lg bg-black/40 text-white font-inter focus:outline-none focus:ring-2 focus:ring-neon" value={title} onChange={e => setTitle(e.target.value)} required />
        </div>
        <div>
          <label className="block font-orbitron text-neon mb-2">Description</label>
          <textarea className="w-full p-3 rounded-lg bg-black/40 text-white font-inter focus:outline-none focus:ring-2 focus:ring-neon" value={desc} onChange={e => setDesc(e.target.value)} required />
        </div>
        <div>
          <label className="block font-orbitron text-neon mb-2">File (CSV, TXT, JSON)</label>
          <input ref={inputRef} type="file" accept=".csv,.txt,.json" className="block w-full text-white" onChange={handleFile} required />
        </div>
        {preview.length > 0 && (
          <div className="glassmorphic p-4 rounded-lg mt-2 overflow-x-auto">
            <div className="font-orbitron text-neon mb-2">Preview (first 5 rows):</div>
            <table className="min-w-full text-sm text-white/80">
              <tbody>
                {preview.map((row, i) => (
                  <tr key={i}>{row.map((cell, j) => <td key={j} className="px-2 py-1 border-b border-white/10">{cell}</td>)}</tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="flex items-center gap-2">
          <input type="checkbox" id="terms" checked={agreed} onChange={e => setAgreed(e.target.checked)} required />
          <label htmlFor="terms" className="text-white/80 font-inter">I agree to the <a href="/gamezone/docs" className="text-neon underline">terms and rules</a>.</label>
        </div>
        <GlassButton type="submit" disabled={!agreed || !file || !title || !desc}>Submit</GlassButton>
        {underReview && <span className="inline-block mt-2 px-4 py-1 rounded-full bg-yellow-400/20 text-yellow-300 font-bold font-orbitron">Under Review</span>}
      </form>
    </GlassCard>
  );
} 