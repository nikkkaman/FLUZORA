'use client';
import React from 'react';
import { useGameZoneContext } from '../context/GameZoneContext';
import GlassCard from './ui/GlassCard';
import GlassButton from './ui/GlassButton';

export default function DatasetVault() {
  const { vault, user } = useGameZoneContext();
  return (
    <GlassCard>
      <div className="font-orbitron text-neon text-xl mb-4">Dataset Vault</div>
      <div className="flex flex-col gap-4">
        {vault.map((d: any) => (
          <div key={d.id} className="relative flex flex-col gap-2">
            <div className="font-orbitron text-lg text-neon mb-1">{d.title}</div>
            <div className="text-white/80 font-inter mb-1">Preview: <span className="underline">{d.preview}</span></div>
            <div className="flex items-center gap-2 mb-2">
              <span className="font-orbitron text-neon font-bold">{d.price} FLZ</span>
              <span className="text-white/60 font-inter">to redeem</span>
            </div>
            <GlassButton disabled={user.flz < d.price}>Redeem</GlassButton>
            {user.flz < d.price && (
              <div className="absolute inset-0 bg-black/70 flex items-center justify-center rounded-2xl">
                <span className="text-neon font-orbitron text-xl">Not Enough Tokens</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </GlassCard>
  );
} 