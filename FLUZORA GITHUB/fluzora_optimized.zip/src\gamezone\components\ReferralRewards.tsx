'use client';
import React, { useState } from 'react';
import GlassCard from './ui/GlassCard';
import GlassButton from './ui/GlassButton';

export default function ReferralRewards() {
  const [copied, setCopied] = useState(false);
  const referral = 'https://fluzora.com/invite/USER123';
  return (
    <GlassCard className="mb-8">
      <div className="font-orbitron text-neon text-2xl mb-4">Referral Rewards</div>
      <div className="flex items-center gap-4 mb-4">
        <input type="text" value={referral} readOnly className="w-full p-2 rounded-lg bg-black/40 text-white font-inter" />
        <GlassButton onClick={() => {navigator.clipboard.writeText(referral); setCopied(true); setTimeout(()=>setCopied(false), 1500);}}>{copied ? 'Copied!' : 'Copy'}</GlassButton>
      </div>
      <ul className="list-disc pl-6 text-white/80 font-inter">
        <li>Invite a friend: +100 FLZ</li>
        <li>Friend uploads a dataset: +200 FLZ</li>
        <li>Top referrers get exclusive avatars</li>
      </ul>
    </GlassCard>
  );
} 