"use client";

import React from "react";
import { motion } from "framer-motion";
import { Check, X, Database, Brain, Zap, Shield, Code, Crown } from "lucide-react";
import Link from "next/link";

const pricingPlans = [
  {
    name: "Starter",
    price: 19,
    period: "month",
    description: "Perfect for beginners and hobbyists",
    features: [
      { name: "10 datasets per month", included: true },
      { name: "Basic Assistant messages", included: true },
      { name: "Dataset download access", included: false },
      { name: "Basic Agent access", included: true },
      { name: "Community support", included: true },
      { name: "API access", included: false },
    ],
    buttonText: "Get Started",
    buttonLink: "/signup",
    highlighted: false
  },
  {
    name: "Pro",
    price: 79,
    period: "month",
    description: "For serious AI developers",
    features: [
      { name: "50 datasets per month", included: true },
      { name: "Unlimited Assistant messages", included: true },
      { name: "Dataset download access", included: true },
      { name: "Full Agent access", included: true },
      { name: "Priority support", included: true },
      { name: "API access", included: false },
    ],
    buttonText: "Upgrade to Pro",
    buttonLink: "/signup",
    highlighted: true
  },
  {
    name: "Ultimate",
    price: 199,
    period: "month",
    description: "For enterprises and power users",
    features: [
      { name: "Unlimited datasets", included: true },
      { name: "Unlimited Assistant messages", included: true },
      { name: "Dataset download access + Vault", included: true },
      { name: "Full Agent access + memory/planner", included: true },
      { name: "24/7 dedicated support", included: true },
      { name: "Full API access", included: true },
    ],
    buttonText: "Get Ultimate",
    buttonLink: "/signup",
    highlighted: false
  }
];

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-black text-white">
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 mb-4">
            Choose Your Plan
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Select the perfect plan for your AI development needs
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {pricingPlans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`rounded-lg overflow-hidden ${
                plan.highlighted
                  ? "border-2 border-purple-500 transform scale-105 relative z-10 bg-purple-900/30 backdrop-blur-sm"
                  : "border border-purple-500/20 bg-purple-900/20 backdrop-blur-sm"
              }`}
            >
              {plan.highlighted && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-purple-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-2 flex items-center gap-2">
                  {plan.name === "Ultimate" && <Crown className="text-yellow-400" size={20} />}
                  {plan.name}
                </h3>
                <div className="flex items-baseline mb-4">
                  <span className="text-4xl font-bold">${plan.price}</span>
                  <span className="text-gray-400 ml-2">/{plan.period}</span>
                </div>
                <p className="text-gray-400 mb-6">{plan.description}</p>
                
                <ul className="space-y-4 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-3">
                      {feature.included ? (
                        <Check className="text-green-400 flex-shrink-0" size={18} />
                      ) : (
                        <X className="text-red-400 flex-shrink-0" size={18} />
                      )}
                      <span className={feature.included ? "text-gray-200" : "text-gray-400"}>
                        {feature.name}
                      </span>
                    </li>
                  ))}
                </ul>
                
                <Link href={plan.buttonLink}>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`w-full py-3 rounded-lg font-semibold ${
                      plan.highlighted
                        ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                        : "bg-purple-900/50 text-white border border-purple-500/30"
                    }`}
                  >
                    {plan.buttonText}
                  </motion.button>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-16 text-center max-w-3xl mx-auto"
        >
          <p className="text-gray-300 text-lg">
            FLUZORA plans give you access to curated datasets, our intelligent agent demo, and a full education system to help you build AI agents using real data.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-16 bg-purple-900/20 backdrop-blur-sm rounded-lg p-8 border border-purple-500/20 max-w-4xl mx-auto"
        >
          <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold text-purple-300 mb-2">What happens when I reach my dataset limit?</h3>
              <p className="text-gray-300">You can continue to use datasets you've already accessed, but you won't be able to access new ones until the next billing cycle or until you upgrade your plan.</p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-purple-300 mb-2">Can I cancel my subscription anytime?</h3>
              <p className="text-gray-300">Yes, you can cancel your subscription at any time. You'll continue to have access until the end of your current billing period.</p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-purple-300 mb-2">What's included in the Vault access?</h3>
              <p className="text-gray-300">The Vault includes our largest and most comprehensive datasets, typically 8GB+ in size, with the highest quality data for enterprise-grade AI development.</p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-purple-300 mb-2">Do you offer custom enterprise plans?</h3>
              <p className="text-gray-300">Yes, we offer custom enterprise plans for organizations with specific needs. Contact our sales team for more information.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}