"use client";

import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import Header from "@/components/Header";
import React from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";

const DESCRIPTION = "Here's a demo of how Fluzora dataset is.";

const BOT_PERSONAS = {
  financial: {
    name: "Financial Chatbot",
    welcome: "Hi! I'm your financial assistant. Ask me anything about stocks, budgeting, or markets.",
    sample: "What are the best ways to save money?",
    responses: [
      {
        user: "What are the best ways to save money?",
        bot: "Some of the best ways to save money include creating a budget, tracking your expenses, setting savings goals, and automating your savings. Would you like tips on budgeting or investment?"
      },
      {
        user: "Tell me about Apple stock.",
        bot: "Apple Inc. (AAPL) is currently trading at $175.23. Would you like a summary of its recent performance or analyst recommendations?"
      }
    ]
  },
  health: {
    name: "Health Chatbot",
    welcome: "Hi! I'm your health assistant. Ask me about nutrition, exercise, or wellness.",
    sample: "How can I improve my sleep?",
    responses: [
      {
        user: "How can I improve my sleep?",
        bot: "To improve sleep, try to maintain a consistent schedule, avoid screens before bed, and create a relaxing bedtime routine. Would you like tips on relaxation or sleep environment?"
      },
      {
        user: "What are healthy snacks?",
        bot: "Healthy snacks include fruits, nuts, yogurt, and vegetables. Would you like a list of easy snack recipes?"
      }
    ]
  }
};

// You can replace this with a real signed URL or get it from props/query
const signedUrl = "https://example.com/path/to/your/dataset.csv";

export default function MeetLoraPage() {
  const [mode, setMode] = useState<"financial" | "health">("financial");
  const [messages, setMessages] = useState([
    { sender: "bot", text: BOT_PERSONAS["financial"].welcome }
  ]);
  const [input, setInput] = useState("");
  const chatRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  useEffect(() => {
    // Reset chat when mode changes
    setMessages([{ sender: "bot", text: BOT_PERSONAS[mode].welcome }]);
    setInput("");
  }, [mode]);

  useEffect(() => {
    // Scroll to bottom on new message
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  function handleSend(e?: React.FormEvent) {
    if (e) e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;
    setMessages((msgs) => [...msgs, { sender: "user", text: trimmed }]);
    setInput("");
    // Simulate bot response
    setTimeout(() => {
      const persona = BOT_PERSONAS[mode];
      const found = persona.responses.find(r => r.user.toLowerCase() === trimmed.toLowerCase());
      setMessages((msgs) => [
        ...msgs,
        { sender: "bot", text: found ? found.bot : "That's a great question! Here's how Fluzora datasets can help: our data is structured, reliable, and ready for your needs. Would you like to see a sample dataset or ask something else?" }
      ]);
    }, 900);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-black flex flex-col">
      <Header 
        cartOpen={false}
        setCartOpen={() => {}}
        cartDatasets={[]}
        totalPrice={0}
        handleRemoveFromCart={() => {}}
        handleBuyNow={() => {}}
        cartCount={0}
      />
      <button
        onClick={() => router.back()}
        className="absolute left-8 top-20 flex items-center gap-2 px-3 py-2 rounded-full bg-transparent border border-white/30 hover:bg-white/10 hover:border-white/80 text-white transition shadow"
        style={{ zIndex: 10 }}
        aria-label="Back"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="hidden md:inline">Back</span>
      </button>
      {/* Hero Section */}
      <section className="w-full flex flex-col items-center justify-center pt-16 pb-8 px-2 bg-gradient-to-b from-purple-900/60 via-black/60 to-black/80 relative">
        <div className="absolute inset-0 pointer-events-none z-0">
          <div className="absolute top-[-10%] left-1/2 -translate-x-1/2 w-[60vw] h-[60vw] max-w-[600px] max-h-[600px] bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 rounded-full blur-[120px] opacity-20" />
          <div className="absolute bottom-[-10%] right-1/2 translate-x-1/2 w-[40vw] h-[40vw] max-w-[400px] max-h-[400px] bg-gradient-to-tr from-cyan-500 via-sky-400 to-indigo-600 rounded-full blur-[100px] opacity-20" />
        </div>
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10 text-5xl md:text-6xl font-extrabold text-center mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 drop-shadow-lg tracking-tight"
          style={{ fontFamily: 'Orbitron, Inter, sans-serif' }}
        >
          Meet Lora
        </motion.h1>
        <p className="relative z-10 text-center text-2xl text-gray-200 max-w-2xl mb-8 font-medium" style={{ fontFamily: 'Inter, sans-serif' }}>{DESCRIPTION}</p>
        <div className="relative z-10 flex justify-center items-center gap-6 mb-8">
          <span className={cn("font-semibold text-lg transition-colors duration-200", mode === "financial" ? "text-purple-400" : "text-gray-400")}>Financial Chatbot</span>
          <Switch 
            checked={mode === "health"} 
            onCheckedChange={(v: boolean) => setMode(v ? "health" : "financial")}
            className="scale-110 shadow-lg"
          />
          <span className={cn("font-semibold text-lg transition-colors duration-200", mode === "health" ? "text-pink-400" : "text-gray-400")}>Health Chatbot</span>
        </div>
      </section>
      {/* Chat Section */}
      <main className="flex-1 flex flex-col items-center justify-center px-2">
        <div className="w-full max-w-2xl mx-auto -mt-16">
          <div className="bg-black/60 rounded-3xl shadow-2xl border-2 border-purple-700/40 backdrop-blur-lg flex flex-col h-[60vh] md:h-[70vh] overflow-hidden relative">
            <div className="absolute inset-0 pointer-events-none rounded-3xl border-2 border-purple-400/10 shadow-[0_0_40px_10px_rgba(168,85,247,0.15)]" />
            <div ref={chatRef} className="flex-1 overflow-y-auto px-6 py-8 space-y-6">
              {messages.map((msg, i) => (
                <div key={i} className={msg.sender === "bot" ? "flex" : "flex justify-end"}>
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={cn(
                      "px-6 py-4 rounded-2xl max-w-[80%] text-lg font-medium",
                      msg.sender === "bot"
                        ? "bg-gradient-to-r from-purple-800 to-pink-900 text-white shadow-md"
                        : "bg-white text-black shadow"
                    )}
                    style={{ fontFamily: 'Inter, sans-serif' }}
                  >
                    {msg.text}
                  </motion.div>
                </div>
              ))}
            </div>
            <form onSubmit={handleSend} className="flex items-center gap-3 p-6 border-t border-purple-900/30 bg-black/80">
              <input
                className="flex-1 bg-transparent outline-none text-white placeholder-gray-400 px-5 py-4 rounded-xl border border-purple-900/40 focus:ring-2 focus:ring-purple-500 transition text-lg font-medium"
                placeholder={BOT_PERSONAS[mode].sample}
                value={input}
                onChange={e => setInput(e.target.value)}
                autoFocus
                style={{ fontFamily: 'Inter, sans-serif' }}
              />
              <button
                type="submit"
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-xl font-bold text-lg shadow hover:from-purple-700 hover:to-pink-700 transition-all disabled:opacity-60"
                disabled={!input.trim()}
                style={{ fontFamily: 'Inter, sans-serif' }}
              >
                Send
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}

export function DownloadPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white">
      <div className="bg-gray-800 p-8 rounded-xl shadow-lg flex flex-col items-center">
        <p className="text-2xl font-bold mb-4">Your dataset is ready!</p>
        <a href={signedUrl} download>
          <button className="download-button bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white px-6 py-3 rounded-lg font-semibold text-lg shadow-md transition-all">
            Download Now
          </button>
        </a>
      </div>
    </div>
  );
}
