'use client';
import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { showSuccess } from "@/components/ui/sonner";
import { Skeleton } from "@/components/ui/skeleton";

export default function EditProfilePage() {
  const router = useRouter();
  const [name, setName] = useState("Demo User");
  const [email, setEmail] = useState("demo@fluzora.com");
  const [avatar, setAvatar] = useState("/default-avatar.svg");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    const timeout = setTimeout(() => setLoading(false), 1000);
    return () => clearTimeout(timeout);
  }, []);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccess(true);
    showSuccess("Profile updated successfully!");
    setTimeout(() => {
      setSuccess(false);
      router.push("/settings");
    }, 1200);
  };

  return (
    <main className="min-h-screen bg-gradient-to-br from-gray-900 to-purple-900 p-8 flex flex-col items-center">
      <button
        onClick={() => router.back()}
        className="absolute left-8 top-8 flex items-center gap-2 px-3 py-2 rounded-full bg-transparent border border-white/30 hover:bg-white/10 hover:border-white/80 text-white transition shadow"
        style={{ zIndex: 10 }}
        aria-label="Back"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="hidden md:inline">Back</span>
      </button>
      {loading ? (
        <Skeleton className="w-full max-w-xl h-[500px] rounded-xl mb-8" />
      ) : (
      <div className="w-full max-w-xl bg-gray-800/80 rounded-xl p-8 shadow-xl">
        <h1 className="text-3xl font-bold text-white mb-8">Edit Profile</h1>
        <form onSubmit={handleSave} className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <label className="text-white font-semibold">Name</label>
            <input
              type="text"
              className="rounded px-4 py-2 bg-gray-900 text-white border border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-400"
              value={name}
              onChange={e => setName(e.target.value)}
              required
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-white font-semibold">Email</label>
            <input
              type="email"
              className="rounded px-4 py-2 bg-gray-900 text-white border border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-400"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-white font-semibold">Avatar URL</label>
            <input
              type="text"
              className="rounded px-4 py-2 bg-gray-900 text-white border border-purple-500 focus:outline-none focus:ring-2 focus:ring-purple-400"
              value={avatar}
              onChange={e => setAvatar(e.target.value)}
            />
            <img src={avatar} alt="avatar preview" className="w-16 h-16 rounded-full border-2 border-purple-500 mt-2" />
          </div>
          <div className="flex gap-4 mt-4">
            <button type="submit" className="px-6 py-2 rounded bg-purple-600 text-white hover:bg-purple-700 font-semibold shadow">Save</button>
            <button type="button" className="px-6 py-2 rounded bg-gray-600 text-white hover:bg-gray-700 font-semibold shadow" onClick={() => router.push('/settings')}>Cancel</button>
          </div>
          {success && <div className="text-green-400 font-semibold mt-2">Profile updated successfully!</div>}
        </form>
      </div>
      )}
    </main>
  );
} 