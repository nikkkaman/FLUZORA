import React from 'react';
import GameZoneLayout from '../layout/GameZoneLayout';
import { useGameZoneContext } from '../context/GameZoneContext';

export default function GameZoneDashboard() {
  const { user } = useGameZoneContext();
  return (
    <GameZoneLayout>
      <div className="mb-6">
        <a href="/gamezone" className="inline-block px-4 py-2 rounded-lg bg-neon text-black font-bold font-orbitron shadow-lg hover:scale-105 transition-transform">Back</a>
      </div>
      <h1 className="text-3xl font-orbitron text-neon mb-8">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col gap-4">
          <div className="text-lg font-orbitron text-white/80">FLZ Balance</div>
          <div className="text-4xl font-orbitron text-neon font-bold drop-shadow-neon">{user.flz} FLZ</div>
          <div className="text-white/60 font-inter">Earnings graph coming soon...</div>
        </div>
        <div className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col gap-4">
          <div className="text-lg font-orbitron text-white/80">Milestones</div>
          <ul className="list-disc pl-6 text-white/90 font-inter">
            {user.milestones.map((m: string, i: number) => <li key={i}>{m}</li>)}
          </ul>
          <div className="text-lg font-orbitron text-white/80 mt-4">Streak</div>
          <div className="text-2xl font-orbitron text-neon font-bold">🔥 {user.streak} days</div>
        </div>
      </div>
      <div className="mt-10 glassmorphic p-6 rounded-2xl shadow-lg">
        <div className="text-lg font-orbitron text-white/80 mb-2">Uploaded Datasets</div>
        <div className="text-white/60 font-inter">(Mock) List of uploaded datasets coming soon...</div>
      </div>
      <div className="mt-8 glassmorphic p-6 rounded-2xl shadow-lg">
        <div className="text-lg font-orbitron text-white/80 mb-2">Redemptions</div>
        <div className="text-white/60 font-inter">(Mock) List of redemptions coming soon...</div>
      </div>
    </GameZoneLayout>
  );
} 