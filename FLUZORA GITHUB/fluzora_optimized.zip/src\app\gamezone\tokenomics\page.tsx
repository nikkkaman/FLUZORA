"use client";
import React from "react";
import { motion } from "framer-motion";
import { FaCoins, FaChartPie } from "react-icons/fa";

const stats = [
  { label: "Minted", value: "1,200,000" },
  { label: "Burnt", value: "350,000" },
  { label: "In Circulation", value: "850,000" },
];

export default function TokenomicsPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-black via-gray-900 to-gray-950 text-white px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="max-w-2xl w-full text-center mb-12"
      >
        <h1 className="font-orbitron text-4xl md:text-5xl font-bold mb-4 text-neon drop-shadow-lg">Tokenomics</h1>
        <p className="font-inter text-lg md:text-xl text-white/80 mb-6">See how FLZ tokens are minted, burnt, and used in the GameZone economy. Track live stats and learn how to earn more!</p>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="w-full max-w-3xl grid grid-cols-1 sm:grid-cols-3 gap-8 mb-12"
      >
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i, duration: 0.5 }}
            className="glassmorphic p-6 rounded-2xl shadow-lg flex flex-col items-center gap-3 border border-yellow-400"
          >
            <FaCoins className="text-yellow-400 text-2xl" />
            <div className="font-orbitron text-2xl text-neon mb-1">{s.value}</div>
            <div className="font-inter text-white/80 text-center text-sm">{s.label}</div>
          </motion.div>
        ))}
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="glassmorphic p-8 rounded-2xl shadow-lg flex flex-col items-center gap-6 border border-purple-400 max-w-2xl mx-auto mb-12"
      >
        <FaChartPie className="text-purple-400 text-4xl mb-2" />
        <div className="font-orbitron text-xl text-neon mb-1">FLZ Distribution (Mock Pie Chart)</div>
        <div className="w-full h-32 bg-gradient-to-r from-yellow-400/30 to-purple-400/30 rounded-full flex items-center justify-center text-purple-200 font-inter">[Pie Chart Placeholder]</div>
        <div className="font-inter text-white/80 text-center text-sm">Uploads: 60% | Referrals: 25% | Events: 10% | Other: 5%</div>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.5 }}
        className="glassmorphic p-8 rounded-2xl shadow-lg flex flex-col items-center gap-6 border border-blue-400 max-w-2xl mx-auto"
      >
        <div className="font-orbitron text-xl text-neon mb-1">How to Earn & Use FLZ</div>
        <ul className="font-inter text-white/80 text-left list-disc list-inside space-y-2">
          <li>Earn FLZ by uploading high-quality datasets, voting, referrals, and live events.</li>
          <li>Use FLZ to redeem premium datasets, buy avatars, and enter tournaments.</li>
          <li>FLZ is burnt on redemption and for special events, keeping the economy balanced.</li>
        </ul>
      </motion.div>
    </main>
  );
} 