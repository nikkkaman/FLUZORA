"use client";

import React from "react";
import { motion } from "framer-motion";
import { BarChart, Users, Database, Zap, Check, Star, Brain, Globe, Eye, LayoutDashboard, Crown, Shield, Code } from "lucide-react";
import { subscriptionDatasets } from "../../data/subscription";
import Link from "next/link";
import { HomeHeader } from "../../components/Header";
import { Button } from "../../components/ui/button";

// Hero Content
const heroContent = {
  title: "BUILD SMARTER AND FASTER",
  subtitle: "FLUZORA's clean datasets work out of the box. Focus on innovation, not formatting."
};

// Analytics data
const analyticsData = [
  {
    title: "Active Users",
    value: "2000+",
    icon: Users,
    description: "Growing community of AI developers"
  },
  {
    title: "Datasets Available",
    value: "1,000+",
    icon: Database,
    description: "Curated high-quality datasets"
  },
  {
    title: "Success Rate",
    value: "98%",
    icon: BarChart,
    description: "Model training success rate"
  },
  {
    title: "Processing Speed",
    value: "10x Faster",
    icon: Zap,
    description: "Than traditional platforms"
  }
];

// Key Features
const keyFeatures = [
  {
    title: "Next-Gen AI Power",
    icon: Brain,
    description: "Designed to power the next generation of intelligent agents and assistants."
  },
  
  {
    title: "Global Access",
    icon: Globe,
    description: "Accessible to developers, researchers, and AI builders across the globe."
  },
  {
    title: "Advanced Curation",
    icon: Star,
    description: "Advanced data curation ensuring the highest quality standards."
  },
  {
    title: "Smart Preview",
    icon: Eye,
    description: "Smart preview systems to evaluate datasets before purchase."
  },
  {
    title: "Seamless Interface",
    icon: LayoutDashboard,
    description: "Seamless user interface to select, download, and apply data instantly."
  },
  {
    title: "Learn to Build AI Agents",
    description: "Step-by-step guides and roadmaps to help you create real agents and agentic tools — no fluff, no coding required.",
    link: "/learn-agents"
  }
];

// Enhanced Fluzora advantages
const fluzoraAdvantages = [
  {
    title: "Premium Data Quality",
    description: "Meticulously curated datasets ensuring the highest quality for AI training.",
    icon: Star
  },
  {
    title: "Instant Access",
    description: "Download and integrate datasets immediately after purchase.",
    icon: Zap
  },
  {
    title: "Enterprise Security",
    description: "Bank-grade encryption protecting your valuable data assets.",
    icon: Shield
  },
  {
    title: "Smart Preview System",
    description: "Preview dataset contents before purchase to ensure perfect fit.",
    icon: Brain
  },
  {
    title: "Domain Expertise",
    description: "Datasets curated by industry experts across multiple domains.",
    icon: Code
  },
  {
    title: "Premium Vault Access",
    description: "Exclusive access to our largest and most comprehensive datasets.",
    icon: Crown
  }
];

// Subscription plan pricing
const subscriptionPricing = {
  starter: {
    price: 19,
    period: "month",
    features: [
      "Access to 20+ starter datasets",
      "Basic API access",
      "Community support",
      "Monthly updates",
      "Basic analytics"
    ]
  },
  pro: {
    price: 79,
    period: "month",
    originalPrice: 87,
    features: [
      "Access to 50+ professional datasets",
      "Advanced API access",
      "Priority support",
      "Weekly updates",
      "Advanced analytics",
      "Custom data formats",
      "10% Professional Discount"
    ]
  },
  premium: {
    price: 199,
    period: "month",
    features: [
      "Access to Premium Vault (8GB+ datasets)",
      "Enterprise API access",
      "24/7 dedicated support",
      "Daily updates",
      "Real-time analytics",
      "Custom data formats",
      "Dedicated account manager",
      "Custom dataset requests"
    ]
  }
};

// Get subscription datasets by pack
const getSubscriptionsByPack = (pack: 'starter' | 'pro' | 'premium') => {
  return subscriptionDatasets.filter(dataset => dataset.pack === pack).slice(0, 3);
};

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-black text-white flex flex-col">
      <HomeHeader />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-24 px-4 flex-grow flex flex-col justify-center items-center text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 max-w-4xl drop-shadow-lg tracking-tight"
          >
            {heroContent.title}
          </motion.h1>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-2xl md:text-3xl font-medium mb-12 text-purple-200/90 max-w-2xl mx-auto tracking-normal"
          >
            {heroContent.subtitle}
          </motion.h2>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-col md:flex-row gap-6 justify-center mt-8"
          >
            <Link href="/datasets" className="group">
              <button
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-4 rounded-lg text-lg font-semibold shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-all duration-300 flex items-center gap-2 hover:scale-105"
              >
                <Database className="w-5 h-5" />
                Explore Datasets
              </button>
            </Link>
            <Link href="/lora" className="group">
              <button
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-10 py-4 rounded-lg text-lg font-semibold shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-all duration-300 flex items-center gap-2 hover:scale-105"
              >
                <Brain className="w-5 h-5" />
                MEET LORA
              </button>
            </Link>
          </motion.div>
        </section>

        {/* Key Features Section */}
        <section className="py-16 bg-gradient-to-b from-black/50 to-purple-900/20 backdrop-blur-sm">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-10 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 drop-shadow">Powering Next-Gen AI Development</h2>
            <div className="grid md:grid-cols-3 gap-8 text-center justify-center items-center">
              {keyFeatures.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -5 }}
                  className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-6 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 shadow-lg shadow-purple-500/10 hover:shadow-purple-500/20 h-full flex flex-col justify-center items-center"
                >
                  <motion.div 
                    className="flex items-center gap-4 mb-4"
                    whileHover={{ x: 5 }}
                    transition={{ duration: 0.2 }}
                  >
                    {feature.icon && typeof feature.icon === 'function' ? <feature.icon size={24} className="text-purple-400" /> : null}
                    <h3 className="text-xl md:text-2xl font-semibold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">{feature.title}</h3>
                  </motion.div>
                  <p className="text-gray-300">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Analytics Section */}
        <section className="py-16 bg-gradient-to-b from-purple-900/20 to-black/50 backdrop-blur-sm">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-10 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 drop-shadow">Platform Analytics</h2>
            <div className="grid md:grid-cols-4 gap-6">
              {analyticsData.map((item: typeof analyticsData[0], index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-6 text-center border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 shadow-lg shadow-purple-500/10 hover:shadow-purple-500/20"
                >
                  <motion.div 
                    className="flex justify-center mb-4"
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.8 }}
                  >
                    <item.icon size={32} className="text-purple-400" />
                  </motion.div>
                  <h3 className="text-3xl md:text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500 mb-2 tracking-tight">{item.value}</h3>
                  <p className="text-lg md:text-xl font-medium text-purple-200 mb-2">{item.title}</p>
                  <p className="text-gray-400">{item.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Subscription Plans Section */}
        <section className="py-16 px-4 bg-gradient-to-b from-purple-900/20 to-black/50 backdrop-blur-sm">
          <div className="container mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600 drop-shadow">Subscription Plans</h2>
              <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto">
                Choose the perfect plan for your AI development needs. All plans include access to our curated datasets and professional tools.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mb-16">
              {/* Starter Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ y: -5 }}
                className="bg-purple-900/20 backdrop-blur-sm rounded-lg p-8 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 shadow-lg shadow-purple-500/10 hover:shadow-purple-500/20"
              >
                <div className="text-center mb-6">
                  <h3 className="text-xl md:text-2xl font-semibold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">Starter</h3>
                  <div className="text-lg md:text-xl font-bold text-purple-400 mb-2">
                    ${subscriptionPricing.starter.price}
                    <span className="text-sm text-gray-400">/month</span>
                  </div>
                  <p className="text-gray-400">Perfect for beginners</p>
                </div>
                <ul className="space-y-4 mb-8">
                  {subscriptionPricing.starter.features.map((feature: string, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Check className="text-green-400 flex-shrink-0" size={18} />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                <div className="space-y-4">
                  <Button className="w-full" size="lg" variant="glass">
                    Buy Now
                  </Button>
                  {/* Preview Datasets */}
                  <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/10 hover:border-purple-500/30 transition-all duration-300">
                    <h4 className="text-sm font-semibold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500 mb-3">Preview Datasets</h4>
                    {getSubscriptionsByPack('starter').map((dataset: typeof subscriptionDatasets[0]) => (
                      <motion.div 
                        key={dataset.id} 
                        className="mb-2 text-sm text-gray-300 flex items-center justify-between"
                        whileHover={{ x: 5 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-purple-400">•</span>
                          {dataset.name}
                        </div>
                        <span className="text-gray-400">{dataset.size}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* Pro Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-purple-900/30 backdrop-blur-sm rounded-lg p-8 border-2 border-purple-500 transform scale-105 relative shadow-xl shadow-purple-500/30 z-10"
              >
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-purple-600 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                    <Star size={14} /> Most Popular
                  </span>
                </div>
                <div className="text-center mb-6">
                  <h3 className="text-xl md:text-2xl font-semibold mb-2">Professional</h3>
                  <div className="text-lg md:text-xl font-bold text-purple-400 mb-2">
                    <span className="text-2xl line-through text-gray-500">${subscriptionPricing.pro.originalPrice}</span>
                    <span className="ml-2">${subscriptionPricing.pro.price}</span>
                    <span className="text-sm text-gray-400">/month</span>
                  </div>
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <Star className="text-yellow-400" size={16} />
                    <span className="text-yellow-400 text-sm">10% Professional Discount</span>
                  </div>
                  <p className="text-gray-400">For serious AI developers</p>
                </div>
                <ul className="space-y-4 mb-8">
                  {subscriptionPricing.pro.features.map((feature: string, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Check className="text-green-400 flex-shrink-0" size={18} />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                <div className="space-y-4">
                  <Button className="w-full" size="lg" variant="glass">
                    Buy Now
                  </Button>
                  {/* Preview Datasets */}
                  <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/10 hover:border-purple-500/30 transition-all duration-300">
                    <h4 className="text-sm font-semibold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500 mb-3">Preview Datasets</h4>
                    {getSubscriptionsByPack('pro').map((dataset: typeof subscriptionDatasets[0]) => (
                      <motion.div 
                        key={dataset.id} 
                        className="mb-2 text-sm text-gray-300 flex items-center justify-between"
                        whileHover={{ x: 5 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-purple-400">•</span>
                          {dataset.name}
                        </div>
                        <span className="text-gray-400">{dataset.size}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* Premium Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                whileHover={{ y: -5 }}
                className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 backdrop-blur-sm rounded-lg p-8 border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 shadow-lg shadow-purple-500/10 hover:shadow-purple-500/20"
              >
                <div className="absolute -top-4 right-4">
                  <span className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                    <Crown size={14} /> Premium Vault Access
                  </span>
                </div>
                <div className="text-center mb-6">
                  <h3 className="text-xl md:text-2xl font-semibold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">Premium</h3>
                  <div className="text-lg md:text-xl font-bold text-purple-400 mb-2">
                    ${subscriptionPricing.premium.price}
                    <span className="text-sm text-gray-400">/month</span>
                  </div>
                  <p className="text-gray-400">Enterprise-grade solution</p>
                </div>
                <ul className="space-y-4 mb-8">
                  {subscriptionPricing.premium.features.map((feature: string, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Check className="text-green-400 flex-shrink-0" size={18} />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                <div className="space-y-4">
                  <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700" size="lg" variant="glass">
                    Buy Now
                  </Button>
                  {/* Preview Premium Vault Datasets */}
                  <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-500/10 hover:border-purple-500/30 transition-all duration-300">
                    <h4 className="text-sm font-semibold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500 mb-3">Premium Vault Preview</h4>
                    {getSubscriptionsByPack('premium').map((dataset: typeof subscriptionDatasets[0]) => (
                      <motion.div 
                        key={dataset.id} 
                        className="mb-2 text-sm text-gray-300 flex items-center justify-between"
                        whileHover={{ x: 5 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="flex items-center gap-2">
                          <Crown className="text-purple-400" size={14} />
                          {dataset.name}
                        </div>
                        <span className="text-gray-400">{dataset.size}</span>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
