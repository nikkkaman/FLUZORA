import React, { useState } from 'react';

export default function GlassTooltip({ children, content }: { children: React.ReactNode; content: string }) {
  const [show, setShow] = useState(false);
  return (
    <span className="relative inline-block" onMouseEnter={() => setShow(true)} onMouseLeave={() => setShow(false)} onFocus={() => setShow(true)} onBlur={() => setShow(false)} tabIndex={0}>
      {children}
      {show && (
        <span className="absolute z-50 left-1/2 -translate-x-1/2 bottom-full mb-2 px-4 py-2 rounded-lg glassmorphic font-orbitron text-sm whitespace-nowrap">
          {content}
        </span>
      )}
    </span>
  );
} 