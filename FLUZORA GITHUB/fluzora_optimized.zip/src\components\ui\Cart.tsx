import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { Dataset } from '@/hooks/useDatasets';

type CartProps = {
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  cartDatasets: Dataset[];
  totalPrice: number;
  handleRemoveFromCart: (id: string) => void;
  handleBuyNow: () => void;
  cartCount: number;
};

export function Cart({
  cartOpen,
  setCartOpen,
  cartDatasets,
  totalPrice,
  handleRemoveFromCart,
  handleBuyNow,
  cartCount,
}: CartProps) {
  return (
    <div className="fixed top-0 right-0 z-50 p-6">
      <div className="relative">
        <button
          className="relative p-2 rounded-full bg-purple-800 hover:bg-purple-700 transition-colors"
          onClick={() => setCartOpen(!cartOpen)}
          aria-label="View Cart"
        >
          <ShoppingCart className="w-6 h-6 text-white" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 border-2 border-black">
              {cartCount}
            </span>
          )}
        </button>
        {cartOpen && (
          <div className="absolute right-0 mt-2 w-80 bg-black border border-purple-800 rounded-xl shadow-lg py-4 px-4 animate-fade-in">
            <h3 className="text-lg font-semibold text-white mb-2">Cart</h3>
            {cartDatasets.length === 0 ? (
              <div className="text-gray-400">No datasets in cart.</div>
            ) : (
              <ul className="mb-4 max-h-56 overflow-y-auto">
                {cartDatasets.map((d) => (
                  <li key={d.id} className="flex justify-between items-center py-2 border-b border-gray-800 last:border-b-0">
                    <span className="text-white text-sm">{d.name}</span>
                    <span className="text-gray-300 text-sm">${d.price?.toFixed(2) || 0}</span>
                    <button className="ml-2 text-xs text-red-400 hover:underline" onClick={() => handleRemoveFromCart(d.id)}>Remove</button>
                  </li>
                ))}
              </ul>
            )}
            <div className="flex justify-between items-center mb-4">
              <span className="text-white font-semibold">Total:</span>
              <span className="text-pink-400 font-bold text-lg">${totalPrice.toFixed(2)}</span>
            </div>
            <button
              className="w-full py-2 rounded-md bg-pink-600 hover:bg-pink-700 text-white font-semibold text-lg transition-colors"
              onClick={handleBuyNow}
              disabled={cartDatasets.length === 0}
            >
              Buy Now
            </button>
          </div>
        )}
      </div>
    </div>
  );
} 